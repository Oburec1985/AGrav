firebase конфиг
google-services.json

Web client id
843242825865-ml3ikgp1t7290mk3vav7hp5h824a1qqr.apps.googleusercontent.com
