# Руководство разработчика CoachPay (Android)

Настоящий документ содержит описание архитектуры, стека технологий, логики работы и структуры проекта CoachPay для программистов.

---

## 1. Стек технологий

*   **Язык**: Kotlin 1.9.x
*   **UI-фреймворк**: Jetpack Compose (Material 3) — декларативный интерфейс
*   **Архитектурный паттерн**: MVVM (Model-View-ViewModel) с использованием UDF (Unidirectional Data Flow)
*   **Управление состоянием**: `StateFlow` из Kotlin Coroutines
*   **Сериализация данных**: `kotlinx.serialization` (JSON-сериализатор)
*   **Локальное хранилище**: Атомарная запись в JSON-файлы во внутреннем каталоге приложения (`Context.filesDir`) с автосозданием резервных копий (`.bak`)
*   **Удаленная база данных**: Firebase Realtime Database (REST API)
*   **Аутентификация**: Google Sign-In + Firebase Auth
*   **Система сборки**: Gradle (Kotlin DSL / Groovy)

---

## 2. Точка входа в приложение

Точкой входа является класс `MainActivity` в файле [MainActivity.kt](file:///c:/Oburec/Antigravity/Projects/CoachPay/app/src/main/java/ru/oburec/coachpay/MainActivity.kt).

### Инициализация и запуск (`onCreate`)
При запуске приложения выполняются следующие шаги:
1. Создается экземпляр `StorageManager`, указывающий на локальную директорию файлов приложения `filesDir`.
2. Создается `AppStateViewModel`, принимающий `StorageManager` в качестве зависимости.
3. Из строковых ресурсов загружаются конфигурационные ключи Firebase (`default_web_client_id` и `google_api_key`).
4. Вызывается `viewModel.loadState(...)`, который асинхронно считывает сохраненное состояние из JSON (или создает дефолтное) и подготавливает данные.
5. Устанавливается Compose-контент с помощью функции `setContent {}`, оборачивая интерфейс в тему `CoachPayTheme` и вызывая главный компонент `CoachPayApp(viewModel)`.

```kotlin
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val storageManager = StorageManager(filesDir)
        val viewModel = AppStateViewModel(storageManager)

        // Загрузка ключей для Firebase и Google Auth
        val resIdClientId = resources.getIdentifier("default_web_client_id", "string", packageName)
        val defaultClientId = if (resIdClientId != 0) getString(resIdClientId) else "843242825865-..."
        
        val resIdApiKey = resources.getIdentifier("google_api_key", "string", packageName)
        val defaultApiKey = if (resIdApiKey != 0) getString(resIdApiKey) else "AIzaSyCC..."

        viewModel.loadState(defaultClientId = defaultClientId, defaultApiKey = defaultApiKey)

        setContent {
            CoachPayTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    // Главный Compose-контейнер
                    CoachPayApp(viewModel)
                }
            }
        }
    }
}
```

---

## 3. Архитектура и управление состоянием

Проект построен по классической MVVM-схеме с однонаправленным потоком данных:
*   **Model**: Описана в пакете `ru.oburec.coachpay.model` (`AppState`, `CoachData`, `City`, `Group`, `Student`, `Payment`, `BookingSlot`). Это чистые структуры данных (Kotlin `data class`), аннотированные `@Serializable`.
*   **View**: Compose-функции в пакетах `ui.screens` и `ui.components`. Они подписываются на состояние `State` из `ViewModel` и вызывают методы-события.
*   **ViewModel**: `AppStateViewModel` содержит всю бизнес-логику, выполняет CRUD-операции над деревом данных и инициирует синхронизацию.

### Реализация UDF (Unidirectional Data Flow)
1. `AppStateViewModel` хранит состояние в приватном поле `_state` типа `MutableStateFlow<AppState>` и экспонирует публичный `state` типа `StateFlow<AppState>`.
2. В Compose-функциях состояние считывается с помощью `collectAsState()`:
   ```kotlin
   @Composable
   fun CoachPayApp(viewModel: AppStateViewModel) {
       val state by viewModel.state.collectAsState()
       // При изменении state этот компонент и его дочерние элементы автоматически перерисовываются
   }
   ```
3. Компоненты UI не изменяют состояние напрямую. При действиях пользователя (например, клик по кнопке оплаты) они вызывают функции во `ViewModel`:
   ```kotlin
   onTogglePayment = { paymentId, month ->
       viewModel.togglePaymentState(cityId, groupId, student.id, paymentId, month)
   }
   ```
4. `ViewModel` производит мутацию состояния, записывает изменения на диск через `StorageManager` и обновляет `StateFlow`, что приводит к автоматической перерисовке UI.

---

## 4. Локальное хранение данных (`StorageManager`)

Файл: [StorageManager.kt](file:///c:/Oburec/Antigravity/Projects/CoachPay/app/src/main/java/ru/oburec/coachpay/data/StorageManager.kt)

Локальная база данных представляет собой сериализованный в JSON объект `AppState`.
Запись реализована атомарно для предотвращения повреждения данных при внезапном закрытии приложения:
1. Новое состояние сериализуется в строку JSON.
2. Содержимое записывается во временный файл (`coachpay_state.json.tmp`).
3. Существующий файл состояния переименовывается в резервную копию (`coachpay_state.json.bak`).
4. Временный файл переименовывается в основной файл (`coachpay_state.json`).
5. В случае ошибки при чтении основного файла, менеджер пытается прочесть файл резервной копии `.bak`.

---

## 5. Облачная синхронизация (`SyncManager`)

Файл: [SyncManager.kt](file:///c:/Oburec/Antigravity/Projects/CoachPay/app/src/main/java/ru/oburec/coachpay/data/SyncManager.kt)

Синхронизация основана на REST API Firebase Realtime Database. Она работает в двух режимах: для тренера и для ученика (родителя).

### 5.1. Режим тренера (Синхронизация группы)
Синхронизация происходит методом **двусторонней сверки (Reconciliation)**:
1. Приложение считывает локальное состояние группы и запрашивает слепок этой же группы из Firebase.
2. Алгоритм сравнивает платежи локально и в облаке по их уникальным ID:
   *   Если платеж изменен локально (например, тренер оффлайн отметил `PAID`), он отправляется в облако.
   *   Если ученик в облаке перевел статус в `PENDING_APPROVAL` (нажал «Я оплатил»), этот статус скачивается и применяется локально.
   *   Если платеж отсутствует в облаке, но есть локально (новый групповой сбор), он загружается в Firebase.
3. По завершении сверки обновленное состояние сохраняется в локальный JSON и транслируется в UI.

### 5.2. Режим ученика (Личный кабинет)
Привязка к кабинету тренера происходит по **коду привязки** (Invite Code) или по номеру телефона:
1. При вводе кода привязки (`CP-XXXXXX`) приложение ищет в таблице `/invites/` соответствие.
2. Таблица `/invites/` содержит маппинг: `код привязки` -> `[coachId, cityId, groupId, studentId]`.
3. Ученик скачивает данные о своих платежах по указанному пути в ветке тренера: `/coaches/$coachId/cities/$cityId/groups/$groupId/students/$studentId`.
4. Когда ученик отмечает платеж как оплаченный, статус меняется на `PENDING_APPROVAL` (ожидает подтверждения) и отправляется в Firebase по пути платежа. Тренер увидит этот статус (желтая цветовая индикация) при следующей синхронизации и сможет подтвердить его (`PAID`).

---

## 6. Интерфейс пользователя (UI)

Весь интерфейс разработан декларативно на Jetpack Compose.

### 6.1. Навигация
Навигация реализована вручную через состояние `currentScreen` во внутреннем стейте `CoachPayApp`:
```kotlin
var currentScreen by remember { mutableStateOf<Screen>(Screen.RoleSelection) }
```
В зависимости от значения `currentScreen` отображается соответствующий экран:
```kotlin
when (val screen = currentScreen) {
    is Screen.RoleSelection -> RoleSelectionScreen(...)
    is Screen.Cities -> CitiesScreen(...)
    is Screen.Groups -> GroupsScreen(...)
    is Screen.Students -> StudentsScreen(...)
    is Screen.Bookings -> BookingsScreen(...)
    is Screen.StudentCabinet -> StudentCabinetScreen(...)
}
```

### 6.2. Ключевые экраны и диалоги
*   [BookingsScreen.kt](file:///c:/Oburec/Antigravity/Projects/CoachPay/app/src/main/java/ru/oburec/coachpay/ui/screens/BookingsScreen.kt) — Экран записи на тренировки. Содержит переключатель недель и сетку занятий. Использует `Icons.AutoMirrored.Filled.ArrowBack/Forward`.
*   [StudentsScreen.kt](file:///c:/Oburec/Antigravity/Projects/CoachPay/app/src/main/java/ru/oburec/coachpay/ui/screens/StudentsScreen.kt) — Список учеников группы с отображением их платежей за выбранный месяц.
*   [Dialogs.kt](file:///c:/Oburec/Antigravity/Projects/CoachPay/app/src/main/java/ru/oburec/coachpay/ui/components/Dialogs.kt) — Набор диалоговых окон: создание учеников, редактирование тарифов, расписания, групповые платежи.

---

## 7. Пример расширения функционала

Если вам нужно добавить новое поле к ученику (например, `email`):
1. Откройте [Student.kt](file:///c:/Oburec/Antigravity/Projects/CoachPay/app/src/main/java/ru/oburec/coachpay/model/Student.kt), добавьте поле и дефолтное значение:
   ```kotlin
   @Serializable
   data class Student(
       val id: String,
       val firstName: String,
       val lastName: String,
       val joinMonth: String,
       val monthlyFee: Double,
       val phone: String = "",
       val email: String = "" // Новое поле
   )
   ```
2. Обновите диалог добавления/редактирования в `Dialogs.kt`, добавив текстовое поле ввода для email.
3. Обновите вызов `viewModel.addStudent` и `viewModel.editStudent` в `AppStateViewModel.kt`, передав туда новый параметр `email`.
4. Сериализатор `kotlinx.serialization` автоматически обработает чтение и запись нового поля в локальный JSON и Firebase.
