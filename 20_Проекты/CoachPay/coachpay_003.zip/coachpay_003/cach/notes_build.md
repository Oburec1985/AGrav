# Заметки по сборке проекта CoachPay

**Дата**: 2026-06-10
**Промпт**: Сборка проекта CoachPay в Android Studio и исправление ошибок несовместимости JDK/Gradle и падения тестов.

## Выводы и решения:
1. **Несовместимость Gradle и JVM**:
   - Android Studio использовала Gradle JVM 21, в то время как проект был настроен на Gradle Wrapper 8.2 (несовместимый с Java 21).
   - Из-за отсутствия интернет-соединения скачать новые версии Gradle и плагинов напрямую из репозиториев Google/Maven было невозможно.
   - Были скопированы файлы Gradle Wrapper (`gradlew`, `gradlew.bat`, `gradle-wrapper.jar`) из соседнего проекта `test005_DNS changer`.
   - Проект CoachPay был переведен на Gradle Wrapper 9.3.1 и AGP 9.1.0 (с использованием закэшированных в системе дистрибутивов).
   - Был включен флаг `android.useAndroidX=true` в `gradle.properties`, так как проект использует AndroidX и Compose.

2. **Compose Compiler и Kotlin 2.2.21**:
   - При переходе на AGP 9.1.0/Kotlin 2.2.21 удалена устаревшая настройка `composeOptions.kotlinCompilerExtensionVersion`.
   - Подключен встроенный плагин Compose Compiler `org.jetbrains.kotlin.plugin.compose` версии `2.2.21`.
   - Удален плагин `org.jetbrains.kotlin.android` в `app/build.gradle.kts` (в AGP 9.0+ он не требуется).
   - Удален блок `kotlinOptions { jvmTarget = "17" }` из-за отказа от `kotlinOptions` в пользу автоопределения из `compileOptions`.

3. **Ошибки ресурсов**:
   - AAPT2 падал на сборке ресурсов, так как в `AndroidManifest.xml` были прописаны mipmap-иконки приложения (`@mipmap/ic_launcher` и `@mipmap/ic_launcher_round`), которых не существовало в директории `res/`.
   - Иконки временно заменены на стандартную системную иконку `@android:drawable/sym_def_app_icon`.

4. **Падение юнит-тестов**:
   - **`StorageManagerTest`**: тест ожидал, что бэкап при повреждении файла вернет актуальное новое состояние. Но по логике `StorageManager.saveState()`, бэкап делается *перед* записью нового состояния (хранит предыдущее успешное состояние). Ожидание исправлено с `TESTID2` на `TESTID1`.
   - **`AppStateViewModelTest`**: `AppStateViewModel` запускает чтение состояния асинхронно в корутине на `Dispatchers.IO` в блоке `init`. В тестовой среде асинхронный запуск приводил к перезаписи состояния дефолтным пустым значением уже после выполнения теста. Реализовано внедрение диспетчера `ioDispatcher` через конструктор `AppStateViewModel` (по умолчанию `Dispatchers.IO`). В тесте передан `Dispatchers.Unconfined` для синхронного и немедленного выполнения корутин.

5. **Ошибки OutOfMemory при дексировании**:
   - При сборке APK на задаче `:app:mergeExtDexDebug` или `:app:mergeLibDexDebug` возникала ошибка `java.lang.OutOfMemoryError: Java heap space` компилятора D8.
   - Решено добавлением лимита памяти JVM для Gradle Daemon в `gradle.properties`:
     `org.gradle.jvmargs=-Xmx2048m -XX:MaxMetaspaceSize=512m`
   - После этого остановлены старые демоны (`.\gradlew --stop`) и перезапущена сборка. Дехер успешно скомпилировал библиотеки с кучей 2 ГБ.

6. **Результат**:
   - Локальная сборка проекта полностью успешна (`BUILD SUCCESSFUL`).
   - Все юнит-тесты успешно пройдены (`Exit code: 0`).
   - Приложение успешно установлено и запущено на эмуляторе Android Studio (`emulator-5554`).
   - Полностью реализован графический интерфейс управления деревом данных Города -> Группы -> Ученики с поддержкой CRUD.
   - Настроена автоинициализация базы тестовыми данными: г. Мытищи, ученик Марк Скрипник.

## Следующий шаг:
- Реализация **Этапа 3**: Экран календаря оплат (помесячный учет, автоматический перенос долгов из прошлого месяца, поиск должников, копирование в буфер).

