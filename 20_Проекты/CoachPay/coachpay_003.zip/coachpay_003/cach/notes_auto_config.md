# Автонастройка и автосинхронизация по Google ID

## Промпт
> Автоматизировать настройку Firebase Web API Key и Client ID: скопировать google-services.json в проект, зашить дефолтные значения (API key) в код, реализовать автонастройку и восстановление структуры базы городов и учеников (CoachData) тренера из облака при входе через Google ID без ручного ввода ключей.

## Реализованные изменения

1. **Копирование и интеграция google-services.json**:
   - Файл `google-services.json` перенесен в директорию `app/` проекта.
   - Подключен плагин `com.google.gms.google-services` в корневом и модульном файлах `build.gradle.kts`.

2. **Автоматическое конфигурирование ключей**:
   - В `MainActivity.kt` добавлен динамический поиск идентификаторов ресурсов `default_web_client_id` и `google_api_key` с помощью `resources.getIdentifier`. Это защищает от ошибок сборки, если плагин Google Services еще не сгенерировал ресурсы.
   - Зашит дефолтный Firebase Web API Key: `AIzaSyCCy_iHK23qwNeH0J665RmbJ9OO0zwQZwI` (из проекта `coachpay-6307c`).
   - При старте `MainActivity.onCreate` автоматически передает найденные или дефолтные ключи во `viewModel.loadState()`.

3. **Синхронизация полной структуры тренера (CoachData)**:
   - В `SyncManager.kt` добавлены сетевые методы `pushCoachData` и `pullCoachData` для сохранения/загрузки полной структуры тренера (`cities`, `groups`, `students`) в Firebase RTDB по пути `/coaches/{coachId}/coachData.json`.
   - В `AppStateViewModel.kt` в методе `completeGoogleSignIn` для роли `COACH` реализовано:
     - Запрос существующей структуры `CoachData` из облака. Если она есть, она восстанавливается локально.
     - Если её нет (первый вход), создается стандартная структура (Мытищи, Основная группа, Марк Скрипник, Брюс Ли) и выгружается в облако.
   - В `AppStateViewModel.saveState` добавлена автоматическая фоновая выгрузка изменений `CoachData` в облако при любом редактировании.
   - В `AppStateViewModel.loadState` добавлена фоновая загрузка актуальной структуры из облака при старте (для тренера) или актуальных платежей/расписания/профиля (для ученика).

4. **Тестирование**:
   - Написан новый unit-тест `testGoogleSignInAutoConfiguresAndRestoresCoachData` в `AppStateViewModelTest.kt`, эмулирующий автоматическое восстановление структуры тренера из облака при первом входе.
   - Обновлен тест `testGoogleAuthFlow` с учетом предустановленного API ключа.
   - Все 14 тестов успешно проходят (`BUILD SUCCESSFUL`).
