package ru.oburec.coachpay.ui.utils

import ru.oburec.coachpay.model.PaymentState
import ru.oburec.coachpay.model.Student

/**
 * Класс данных (data class) для представления агрегированного финансового статуса ученика.
 * Собирает всю информацию об оплатах ученика, чтобы удобно отобразить её в карточке ученика.
 *
 * @property state Общий статус оплат: PAID (всё оплачено), UNPAID (есть долги), PENDING_APPROVAL (есть оплаты, ждущие подтверждения тренера).
 * @property pendingCount Количество платежей, которые ученик отметил как оплаченные, но тренер ещё не подтвердил.
 * @property unpaidCount Количество неоплаченных платежей за прошлые периоды и текущий месяц.
 * @property unpaidAmount Суммарный долг ученика в рублях.
 * @property unpaidMonths Список месяцев, за которые у ученика есть долги (например, ["2026-05", "2026-06"]).
 */
data class StudentPaymentStatus(
    val state: PaymentState,
    val pendingCount: Int,
    val unpaidCount: Int,
    val unpaidAmount: Double,
    val unpaidMonths: List<String>
)

/**
 * Объект PaymentStatusUtils предоставляет функции для расчета задолженностей и финансового статуса ученика.
 */
object PaymentStatusUtils {

    /**
     * Вычисляет агрегированный финансовый статус ученика на основе истории его платежей.
     * Учитывает только долги за прошлые периоды и за текущий системный месяц. Будущие начисления (если есть) долгом не считаются.
     *
     * Пример использования:
     * val status = PaymentStatusUtils.getStudentPaymentStatus(student, "2026-06")
     * when (status.state) {
     *     PaymentState.PAID -> { // Зеленый индикатор "Всё оплачено" }
     *     PaymentState.PENDING_APPROVAL -> { // Желтый индикатор "Ожидает подтверждения" }
     *     PaymentState.UNPAID -> { // Красный индикатор "Долг: 3000 ₽" }
     * }
     *
     * @param student Объект ученика [Student], чьи платежи нужно проанализировать.
     * @param currentRealMonth Текущий календарный месяц в формате "YYYY-MM" (например, "2026-06"), ограничивающий расчет долгов.
     * @return Объект [StudentPaymentStatus], содержащий результаты расчетов.
     */
    fun getStudentPaymentStatus(student: Student, currentRealMonth: String): StudentPaymentStatus {
        // Находим платежи, которые ученик отправил на подтверждение
        val pending = student.payments.filter { it.state == PaymentState.PENDING_APPROVAL }
        
        // Находим неоплаченные платежи, относящиеся к текущему или прошедшим месяцам
        val unpaid = student.payments.filter { it.state == PaymentState.UNPAID && (it.month.isEmpty() || it.month <= currentRealMonth) }
        
        // Определяем общий статус ученика:
        // 1. Если есть хоть один платеж на подтверждении — статус PENDING_APPROVAL (желтый)
        // 2. Если есть неоплаченные платежи — статус UNPAID (красный)
        // 3. Иначе — PAID (все оплачено, зеленый)
        val overallState = when {
            pending.isNotEmpty() -> PaymentState.PENDING_APPROVAL
            unpaid.isNotEmpty() -> PaymentState.UNPAID
            else -> PaymentState.PAID
        }
        
        return StudentPaymentStatus(
            state = overallState,
            pendingCount = pending.size,
            unpaidCount = unpaid.size,
            unpaidAmount = unpaid.sumOf { it.amount }, // Суммируем размеры всех задолженностей
            unpaidMonths = unpaid.map { it.month }
                .filter { it.isNotEmpty() }
                .distinct()
                .sorted() // Получаем отсортированный по возрастанию список месяцев с долгами
        )
    }
}
