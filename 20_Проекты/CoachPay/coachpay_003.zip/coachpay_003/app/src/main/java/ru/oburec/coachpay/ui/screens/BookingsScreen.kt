package ru.oburec.coachpay.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import ru.oburec.coachpay.model.*
import ru.oburec.coachpay.viewmodel.AppStateViewModel
import ru.oburec.coachpay.ui.utils.MonthUtils
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookingsScreen(
    cityId: String,
    groupId: String,
    groupName: String,
    viewModel: AppStateViewModel,
    isCoach: Boolean
) {
    val state by viewModel.state.collectAsState()
    
    // Получаем текущие данные
    val group = if (isCoach) {
        state.coachData?.cities?.flatMap { it.groups }?.find { g -> g.id == groupId }
    } else {
        if (state.studentConfig?.groupId == groupId) state.studentConfig else null
    }

    val bookings = remember(group) {
        if (isCoach) {
            (group as? StudentGroup)?.bookings ?: emptyList()
        } else {
            (group as? StudentConfig)?.bookings ?: emptyList()
        }
    }

    val allStudents = remember(state.coachData, groupId) {
        state.coachData?.cities?.flatMap { it.groups }?.find { g -> g.id == groupId }?.students ?: emptyList()
    }

    val currentStudentId = state.studentConfig?.studentId

    var showAddDialog by remember { mutableStateOf(false) }
    var selectedBookingForAddStudent by remember { mutableStateOf<BookingClass?>(null) }
    var showStudentDropdownForBookingId by remember { mutableStateOf<String?>(null) }

    // Состояния для перелистывания недель
    var weekDelta by remember { mutableIntStateOf(0) }
    val currentMonday = remember(weekDelta) { MonthUtils.getMondayOfWeek(weekDelta) }

    // Загрузка актуальных данных
    LaunchedEffect(cityId, groupId) {
        if (isCoach) {
            viewModel.syncBookings(cityId, groupId)
        } else {
            viewModel.pullBookingsForStudent()
        }
    }

    fun getDaysOfWeekWithDates(mondayStr: String): List<Pair<String, String>> {
        val daysNames = listOf("Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье")
        val result = mutableListOf<Pair<String, String>>()
        try {
            val sdfInput = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val date = sdfInput.parse(mondayStr) ?: return emptyList()
            val cal = Calendar.getInstance(Locale.US)
            
            val sdfDisplay = SimpleDateFormat("dd.MM", Locale("ru"))
            val sdfDate = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            
            for (i in 0 until 7) {
                cal.time = date
                cal.add(Calendar.DAY_OF_YEAR, i)
                val dayName = daysNames[i]
                val displayStr = "$dayName (${sdfDisplay.format(cal.time)})"
                val dateValue = sdfDate.format(cal.time)
                result.add(displayStr to dateValue)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return result
    }

    // Вычисляем дни недели с конкретными датами
    val daysWithDates = remember(currentMonday) {
        getDaysOfWeekWithDates(currentMonday)
    }

    val currentWeekDays = remember(daysWithDates) {
        daysWithDates.map { it.second }
    }

    // Безопасная проверка принадлежности даты выбранной неделе
    fun isDateInWeek(dateStr: String, currentWeekDaysList: List<String>): Boolean {
        if (dateStr in currentWeekDaysList) return true
        try {
            val cleanStr = dateStr.replace("/", ".")
            val parts = cleanStr.split(".")
            if (parts.size == 2) {
                val day = parts[0].toIntOrNull() ?: return false
                val month = parts[1].toIntOrNull() ?: return false
                val currentYear = Calendar.getInstance().get(Calendar.YEAR)
                val formattedDate = String.format("%04d-%02d-%02d", currentYear, month, day)
                return formattedDate in currentWeekDaysList
            }
        } catch (e: Exception) {}
        return false
    }

    // Форматирование даты для вывода
    fun formatDisplayDate(dateStr: String): String {
        try {
            val sdfInput = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val date = sdfInput.parse(dateStr) ?: return dateStr
            val cal = Calendar.getInstance(Locale.US)
            cal.time = date
            
            val daysNames = listOf("Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб")
            val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
            val dayName = daysNames[dayOfWeek - 1]
            
            val sdfDisplay = SimpleDateFormat("dd.MM", Locale("ru"))
            return "$dayName (${sdfDisplay.format(cal.time)})"
        } catch (e: Exception) {
            return dateStr
        }
    }

    // Фильтруем занятия по выбранной неделе
    val filteredBookings = remember(bookings, currentWeekDays) {
        bookings.filter { isDateInWeek(it.date, currentWeekDays) }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Листалка недель
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1E293B))
                .padding(vertical = 12.dp, horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { weekDelta-- },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Предыдущая неделя",
                    tint = Color.White
                )
            }
            val systemToday = remember { java.text.SimpleDateFormat("dd.MM", java.util.Locale("ru")).format(java.util.Date()) }
            Text(
                text = MonthUtils.formatWeekRange(currentMonday) + if (weekDelta == 0) " (Текущая, сегодня $systemToday)" else "",
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                color = Color(0xFF81C784),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier.weight(1f)
            )
            IconButton(
                onClick = { weekDelta++ },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Следующая неделя",
                    tint = Color.White
                )
            }
        }

        Box(modifier = Modifier.weight(1f)) {
            if (filteredBookings.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Text(
                            text = "Нет занятий с записью на этой неделе.",
                            color = Color.LightGray,
                            fontWeight = FontWeight.Medium,
                            fontSize = 16.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        if (isCoach) {
                            Text(
                                text = "Вы можете скопировать занятия с записью с предыдущей недели.",
                                color = Color.Gray,
                                fontSize = 13.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Button(
                                onClick = {
                                    val prevMonday = MonthUtils.getMondayOfWeek(weekDelta - 1)
                                    val prevWeekDays = getDaysOfWeekWithDates(prevMonday).map { it.second }
                                    val prevBookings = bookings.filter { isDateInWeek(it.date, prevWeekDays) }
                                    if (prevBookings.isNotEmpty()) {
                                        val cloned = prevBookings.map { old ->
                                            val oldDayIdx = prevWeekDays.indexOf(old.date)
                                            val newDate = if (oldDayIdx != -1) currentWeekDays[oldDayIdx] else currentWeekDays[0]
                                            BookingClass(
                                                id = java.util.UUID.randomUUID().toString(),
                                                title = old.title,
                                                date = newDate,
                                                time = old.time,
                                                maxCapacity = old.maxCapacity,
                                                attendees = emptyList(),
                                                priceRules = old.priceRules
                                            )
                                        }
                                        viewModel.addBookingClasses(cityId, groupId, cloned)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Скопировать с прошлой недели", color = Color.White)
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredBookings) { booking ->
                        val isFull = booking.attendees.size >= booking.maxCapacity
                        val currentPrice = remember(booking.attendees.size, booking.priceRules) {
                            val count = booking.attendees.size
                            if (count == 0) {
                                booking.priceRules.minByOrNull { it.attendeesCount }?.pricePerPerson ?: 0.0
                            } else {
                                val rule = booking.priceRules
                                    .filter { it.attendeesCount <= count }
                                    .maxByOrNull { it.attendeesCount }
                                    ?: booking.priceRules.minByOrNull { it.attendeesCount }
                                rule?.pricePerPerson ?: 0.0
                            }
                        }

                        var isExpanded by remember { mutableStateOf(false) }

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isExpanded = !isExpanded }
                                .border(
                                    width = 1.dp,
                                    color = if (isFull) Color(0xFFE57373) else Color(0xFF81C784),
                                    shape = RoundedCornerShape(12.dp)
                                ),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                // Заголовок карточки (свернутый вид)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = booking.title,
                                            color = Color.White,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "${formatDisplayDate(booking.date)} в ${booking.time}",
                                            color = Color.LightGray,
                                            fontSize = 13.sp
                                        )
                                    }
                                    
                                    // Статусы и индикаторы
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = "${booking.attendees.size}/${booking.maxCapacity}",
                                            color = Color.White,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        
                                        if (isCoach) {
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = if (isFull) Color(0x2FFF4444) else Color(0x2F44FF44)
                                            ) {
                                                Text(
                                                    text = if (isFull) "Закрыта" else "Открыта",
                                                    color = if (isFull) Color(0xFFFF8A80) else Color(0xFFB9F6CA),
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        } else {
                                            val isRegistered = currentStudentId != null && booking.attendees.contains(currentStudentId)
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = when {
                                                    isRegistered -> Color(0x2F44FF44)
                                                    isFull -> Color(0x2FFF4444)
                                                    else -> Color(0x2F334155)
                                                }
                                            ) {
                                                Text(
                                                    text = when {
                                                        isRegistered -> "Записан"
                                                        isFull -> "Мест нет"
                                                        else -> "Открыта"
                                                    },
                                                    color = when {
                                                        isRegistered -> Color(0xFFB9F6CA)
                                                        isFull -> Color(0xFFFF8A80)
                                                        else -> Color.LightGray
                                                    },
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                        
                                        Icon(
                                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                            contentDescription = if (isExpanded) "Свернуть" else "Развернуть",
                                            tint = Color.Gray
                                        )
                                    }
                                }

                                // Подробный развернутый вид
                                if (isExpanded) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    HorizontalDivider(color = Color.DarkGray)
                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Кнопка удаления для тренера
                                    if (isCoach) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End
                                        ) {
                                            IconButton(
                                                onClick = {
                                                    viewModel.deleteBookingClass(cityId, groupId, booking.id)
                                                },
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = "Удалить занятие",
                                                    tint = Color(0xFFE57373)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                    }

                                    // Вместимость & Статус
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Места: ${booking.attendees.size} / ${booking.maxCapacity}",
                                            color = Color.White,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )

                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = if (isFull) Color(0x2FFF4444) else Color(0x2F44FF44)
                                        ) {
                                            Text(
                                                text = if (isFull) "Запись закрыта" else "Запись открыта",
                                                color = if (isFull) Color(0xFFFF8A80) else Color(0xFFB9F6CA),
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    // Текущая стоимость
                                    Text(
                                        text = "Текущая стоимость: ${currentPrice.toInt()} ₽ / чел.",
                                        color = Color(0xFF81C784),
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    if (booking.priceRules.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = "Тарифы в зависимости от кол-ва:",
                                            color = Color.LightGray,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(top = 4.dp)
                                        ) {
                                            booking.priceRules.sortedBy { it.attendeesCount }.forEach { rule ->
                                                Text(
                                                    text = "• от ${rule.attendeesCount} чел.: ${rule.pricePerPerson.toInt()} ₽ с человека",
                                                    color = Color.Gray,
                                                    fontSize = 12.sp
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))
                                    HorizontalDivider(color = Color.DarkGray)
                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Список участников
                                    Text(
                                        text = "Записались (${booking.attendees.size}):",
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )

                                    if (booking.attendees.isEmpty()) {
                                        Text(
                                            text = "Никто пока не записался",
                                            color = Color.Gray,
                                            fontSize = 13.sp,
                                            modifier = Modifier.padding(vertical = 4.dp)
                                        )
                                    } else {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(top = 4.dp)
                                        ) {
                                            booking.attendees.forEach { attId ->
                                                val studentName = remember(allStudents, attId) {
                                                    allStudents.find { it.id == attId }?.let { "${it.lastName} ${it.firstName}" } ?: "Неизвестный ученик"
                                                }

                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(vertical = 2.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = studentName,
                                                        color = Color.LightGray,
                                                        fontSize = 14.sp
                                                    )
                                                    if (isCoach) {
                                                        IconButton(
                                                            onClick = {
                                                                viewModel.toggleStudentBooking(
                                                                    coachId = state.coachData?.coachId ?: "",
                                                                    groupId = groupId,
                                                                    bookingId = booking.id,
                                                                    studentId = attId,
                                                                    register = false
                                                                )
                                                            },
                                                            modifier = Modifier.size(24.dp)
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Default.Close,
                                                                contentDescription = "Убрать",
                                                                tint = Color(0xFFE57373),
                                                                modifier = Modifier.size(16.dp)
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))

                                    // Кнопки действий
                                    if (isCoach) {
                                        Box(modifier = Modifier.fillMaxWidth()) {
                                            Button(
                                                onClick = {
                                                    showStudentDropdownForBookingId = booking.id
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.fillMaxWidth(),
                                                enabled = !isFull
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Add,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(text = "Записать ученика", color = Color.White)
                                            }

                                            DropdownMenu(
                                                expanded = showStudentDropdownForBookingId == booking.id,
                                                onDismissRequest = { showStudentDropdownForBookingId = null },
                                                modifier = Modifier.background(Color(0xFF1E293B))
                                            ) {
                                                val nonRegisteredStudents = allStudents.filter { !booking.attendees.contains(it.id) }
                                                if (nonRegisteredStudents.isEmpty()) {
                                                    DropdownMenuItem(
                                                        text = { Text("Все ученики записаны", color = Color.Gray) },
                                                        onClick = {}
                                                    )
                                                } else {
                                                    nonRegisteredStudents.forEach { student ->
                                                        DropdownMenuItem(
                                                            text = { Text("${student.lastName} ${student.firstName}", color = Color.White) },
                                                            onClick = {
                                                                viewModel.toggleStudentBooking(
                                                                    coachId = state.coachData?.coachId ?: "",
                                                                    groupId = groupId,
                                                                    bookingId = booking.id,
                                                                    studentId = student.id,
                                                                    register = true
                                                                )
                                                                showStudentDropdownForBookingId = null
                                                            }
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    } else {
                                        val isRegistered = currentStudentId != null && booking.attendees.contains(currentStudentId)

                                        Button(
                                            onClick = {
                                                if (currentStudentId != null) {
                                                    viewModel.toggleStudentBooking(
                                                        coachId = state.studentConfig?.coachId ?: "",
                                                        groupId = groupId,
                                                        bookingId = booking.id,
                                                        studentId = currentStudentId,
                                                        register = !isRegistered
                                                    )
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (isRegistered) Color(0xFFE57373) else Color(0xFF81C784)
                                            ),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.fillMaxWidth(),
                                            enabled = isRegistered || !isFull
                                        ) {
                                            Text(
                                                text = if (isRegistered) "Отписаться от занятия" else "Записаться на занятие",
                                                color = Color.Black,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        // Кнопка добавления занятия для тренера
        if (isCoach) {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = Color(0xFF81C784),
                contentColor = Color.Black,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(24.dp)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Добавить занятие")
            }
        }
    }
}

    if (showAddDialog) {
        AddBookingClassDialog(
            daysWithDates = daysWithDates,
            onDismiss = { showAddDialog = false },
            onConfirm = { booking ->
                viewModel.addOrUpdateBookingClass(cityId, groupId, booking)
                showAddDialog = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddBookingClassDialog(
    daysWithDates: List<Pair<String, String>>,
    onDismiss: () -> Unit,
    onConfirm: (BookingClass) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var selectedDayPair by remember { mutableStateOf(daysWithDates.firstOrNull() ?: ("Понедельник" to "")) }
    var expandedDayDropdown by remember { mutableStateOf(false) }
    var time by remember { mutableStateOf("18:00") }
    var maxCapacity by remember { mutableStateOf("5") }

    // Таблица тарифов
    val priceRules = remember { mutableStateListOf<BookingPriceRule>() }

    var ruleCount by remember { mutableStateOf("") }
    var rulePrice by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth()
            ) {
                Text(
                    text = "Новое занятие с записью",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Название занятия") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF81C784)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Выбор дня недели с конкретной датой
                    Box(modifier = Modifier.weight(1.2f)) {
                        OutlinedButton(
                            onClick = { expandedDayDropdown = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp),
                            shape = RoundedCornerShape(4.dp),
                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                width = 1.dp,
                                brush = androidx.compose.ui.graphics.SolidColor(Color.Gray.copy(alpha = 0.5f))
                            ),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = selectedDayPair.first,
                                    fontSize = 13.sp,
                                    color = Color.White
                                )
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = null,
                                    tint = Color.Gray
                                )
                            }
                        }
                        DropdownMenu(
                            expanded = expandedDayDropdown,
                            onDismissRequest = { expandedDayDropdown = false },
                            modifier = Modifier.background(Color(0xFF1E293B))
                        ) {
                            daysWithDates.forEach { pair ->
                                DropdownMenuItem(
                                    text = { Text(pair.first, color = Color.White) },
                                    onClick = {
                                        selectedDayPair = pair
                                        expandedDayDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = time,
                        onValueChange = { time = it },
                        label = { Text("Время (ЧЧ:ММ)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF81C784)
                        ),
                        modifier = Modifier.weight(0.8f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = maxCapacity,
                    onValueChange = { maxCapacity = it },
                    label = { Text("Макс. мест") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF81C784)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = Color.DarkGray)
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Тарифная сетка стоимости:",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )

                // Список уже добавленных правил
                Column(modifier = Modifier.fillMaxWidth()) {
                    priceRules.sortedBy { it.attendeesCount }.forEach { rule ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "От ${rule.attendeesCount} человек: ${rule.pricePerPerson.toInt()} ₽ / чел.",
                                color = Color.LightGray,
                                fontSize = 13.sp
                            )
                            IconButton(onClick = { priceRules.remove(rule) }, modifier = Modifier.size(24.dp)) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Удалить правило",
                                    tint = Color(0xFFE57373),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Поля ввода для нового правила
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = ruleCount,
                        onValueChange = { ruleCount = it },
                        label = { Text("Кол-во чел.") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF81C784)
                        ),
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = rulePrice,
                        onValueChange = { rulePrice = it },
                        label = { Text("Цена, ₽") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF81C784)
                        ),
                        modifier = Modifier.weight(1.2f)
                    )

                    IconButton(
                        onClick = {
                            val count = ruleCount.toIntOrNull()
                            val price = rulePrice.toDoubleOrNull()
                            if (count != null && price != null) {
                                priceRules.removeAll { it.attendeesCount == count }
                                priceRules.add(BookingPriceRule(count, price))
                                ruleCount = ""
                                rulePrice = ""
                            }
                        },
                        modifier = Modifier
                            .background(Color(0xFF334155), RoundedCornerShape(8.dp))
                            .size(40.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Добавить правило", tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Кнопки Сохранить / Отмена
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Отмена", color = Color.LightGray)
                    }

                    Button(
                        onClick = {
                            val countVal = ruleCount.trim().toIntOrNull()
                            val priceVal = rulePrice.trim().toDoubleOrNull()
                            val finalRules = priceRules.toMutableList()
                            if (countVal != null && priceVal != null) {
                                finalRules.removeAll { it.attendeesCount == countVal }
                                finalRules.add(BookingPriceRule(countVal, priceVal))
                            }
                            onConfirm(
                                BookingClass(
                                    id = java.util.UUID.randomUUID().toString(),
                                    title = title.trim(),
                                    date = selectedDayPair.second,
                                    time = time.trim(),
                                    maxCapacity = maxCapacity.trim().toIntOrNull() ?: 5,
                                    attendees = emptyList(),
                                    priceRules = finalRules.sortedBy { it.attendeesCount }
                                )
                            )
                        },
                        enabled = title.trim().isNotEmpty() && selectedDayPair.second.isNotEmpty() && time.trim().isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF81C784)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Создать", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
