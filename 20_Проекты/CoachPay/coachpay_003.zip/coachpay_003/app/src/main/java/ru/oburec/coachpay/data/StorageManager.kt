package ru.oburec.coachpay.data

import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import ru.oburec.coachpay.model.AppState
import java.io.File
import java.io.IOException

/**
 * Класс StorageManager отвечает за сохранение и загрузку состояния всего приложения.
 * Он сохраняет состояние в виде текстового файла формата JSON во внутреннем хранилище устройства.
 * Данные сохраняются атомарно с автоматическим созданием резервной копии (.bak), 
 * чтобы избежать потери данных, если запись будет прервана (например, при разряде батареи).
 *
 * @property baseDir Базовая папка на устройстве, где будут храниться файлы данных (обычно Context.filesDir).
 */
class StorageManager(private val baseDir: File) {

    // Настройка парсера JSON из библиотеки kotlinx.serialization
    private val json = Json {
        prettyPrint = true          // Форматировать JSON с отступами и переносами для читаемости человеком
        ignoreUnknownKeys = true    // Игнорировать неизвестные поля при загрузке (полезно при миграциях структуры)
        coerceInputValues = true    // Использовать дефолтные значения из кода, если в JSON пришло null
    }

    // Имена файлов для основного сохранения и резервной копии
    private val fileName = "app_state.json"
    private val backupFileName = "app_state.json.bak"

    // Ссылка на основной файл сохранения
    private val stateFile: File
        get() = File(baseDir, fileName)

    // Ссылка на файл резервной копии
    private val backupFile: File
        get() = File(baseDir, backupFileName)

    /**
     * Сохраняет состояние приложения в файл.
     * Перед тем как записать новые данные, текущий рабочий файл копируется в резервную копию (.bak).
     *
     * Пример использования:
     * val saved = storageManager.saveState(currentAppState)
     *
     * @param state Объект [AppState], содержащий все текущие настройки, роли, города, группы, учеников и платежи.
     * @return Возвращает true, если сохранение прошло успешно, и false в случае ошибки.
     */
    @Synchronized
    fun saveState(state: AppState): Boolean {
        return try {
            val file = stateFile
            val backup = backupFile

            // 1. Если рабочий файл уже существует, делаем его копию в файл бэкапа
            if (file.exists()) {
                try {
                    file.copyTo(backup, overwrite = true)
                } catch (e: IOException) {
                    println("Не удалось создать бэкап перед записью: ${e.message}")
                }
            }

            // 2. Сериализуем (превращаем объект в строку) состояние приложения AppState
            val jsonString = json.encodeToString(state)

            // 3. Записываем полученную JSON-строку в основной файл в кодировке UTF-8
            file.writeText(jsonString, Charsets.UTF_8)
            true
        } catch (e: Exception) {
            println("Ошибка при сохранении состояния в файл: ${e.message}")
            false
        }
    }

    /**
     * Загружает состояние приложения с диска при запуске.
     * Если основной файл отсутствует или поврежден (вызывает ошибку парсинга), 
     * метод пробует загрузить данные из резервной копии (.bak).
     *
     * Пример использования:
     * val state = storageManager.loadState()
     *
     * @return Объект [AppState] с сохраненными данными. Если данных нет вообще, вернет новый чистый объект [AppState].
     */
    @Synchronized
    fun loadState(): AppState {
        val file = stateFile
        val backup = backupFile

        // Если нет ни основного файла, ни резервной копии — это первый запуск приложения, возвращаем пустой стейт
        if (!file.exists() && !backup.exists()) {
            return AppState()
        }

        // 1. Сначала пробуем загрузить и распарсить основной файл
        if (file.exists()) {
            try {
                val jsonString = file.readText(Charsets.UTF_8)
                // Декодируем строку JSON обратно в объект AppState
                return json.decodeFromString<AppState>(jsonString)
            } catch (e: Exception) {
                println("Основной файл состояния поврежден, пробуем бэкап: ${e.message}")
            }
        }

        // 2. Если основной файл не удалось прочесть, пробуем прочесть бэкап
        if (backup.exists()) {
            try {
                val jsonString = backup.readText(Charsets.UTF_8)
                val state = json.decodeFromString<AppState>(jsonString)
                
                // Если бэкап прочитался успешно, восстанавливаем основной файл из него
                try {
                    backup.copyTo(file, overwrite = true)
                } catch (e: IOException) {
                    println("Не удалось перезаписать основной файл из бэкапа: ${e.message}")
                }
                return state
            } catch (e: Exception) {
                println("Бэкап файл также поврежден: ${e.message}")
            }
        }

        // Если и основной файл, и бэкап повреждены — возвращаем новый чистый стейт
        return AppState()
    }

    /**
     * Принудительно восстанавливает состояние приложения из резервной копии.
     * Это может потребоваться при сбоях синхронизации или по выбору пользователя.
     *
     * Пример использования:
     * val restoredState = storageManager.restoreBackup()
     * if (restoredState != null) { // Успешно восстановлено }
     *
     * @return Восстановленный объект [AppState] или null, если файл бэкапа отсутствует или поврежден.
     */
    @Synchronized
    fun restoreBackup(): AppState? {
        val file = stateFile
        val backup = backupFile
        if (backup.exists()) {
            try {
                val jsonString = backup.readText(Charsets.UTF_8)
                val state = json.decodeFromString<AppState>(jsonString)
                // Перезаписываем основной файл восстановленными данными
                backup.copyTo(file, overwrite = true)
                return state
            } catch (e: Exception) {
                println("Ошибка при восстановлении из бэкапа: ${e.message}")
            }
        }
        return null
    }

    /**
     * Полностью очищает все локальные сохраненные файлы (основной и резервный).
     * Используется для сброса данных к заводским настройкам при выходе из аккаунта.
     *
     * Пример использования:
     * val cleared = storageManager.clearAllData()
     *
     * @return true, если очистка файлов выполнена успешно, иначе false.
     */
    @Synchronized
    fun clearAllData(): Boolean {
        var success = true
        if (stateFile.exists()) {
            success = success && stateFile.delete()
        }
        if (backupFile.exists()) {
            success = success && backupFile.delete()
        }
        return success
    }
}
