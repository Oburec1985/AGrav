package ru.oburec.coachpay.data

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter

/**
 * Объект QrCodeGenerator предоставляет утилиту для генерации QR-кодов.
 * Использует библиотеку ZXing для кодирования текста в матрицу QR-кода.
 */
object QrCodeGenerator {
    
    /**
     * Генерирует изображение (Bitmap) с QR-кодом, в котором зашифрован переданный текст.
     *
     * Пример использования:
     * val qrBitmap = QrCodeGenerator.generateQrCode("CP-123456", size = 300)
     * if (qrBitmap != null) {
     *     // Отображаем Bitmap в интерфейсе
     * }
     *
     * @param text Строка текста, которую нужно зашифровать в QR-код (например, инвайт-код или ссылка).
     * @param size Размер результирующего квадратного изображения в пикселях по ширине и высоте (по умолчанию 512).
     * @return Возвращает готовый [Bitmap] для отображения в UI или сохранения на диск, либо null в случае ошибки.
     */
    fun generateQrCode(text: String, size: Int = 512): Bitmap? {
        return try {
            // Создаем экземпляр кодировщика QR-кодов от ZXing
            val writer = QRCodeWriter()
            
            // Кодируем переданный текст в матрицу битов (черных и белых точек)
            val bitMatrix = writer.encode(text, BarcodeFormat.QR_CODE, size, size)
            
            val width = bitMatrix.width
            val height = bitMatrix.height
            
            // Создаем пустое Android Bitmap-изображение нужного размера в формате ARGB_8888 (каждый пиксель 4 байта)
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            
            // Проходим по каждому пикселю матрицы и закрашиваем Bitmap: черный цвет для бита 1, белый для 0
            for (x in 0 until width) {
                for (y in 0 until height) {
                    bitmap.setPixel(x, y, if (bitMatrix.get(x, y)) Color.BLACK else Color.WHITE)
                }
            }
            bitmap
        } catch (e: Exception) {
            e.printStackTrace() // Выводит стек ошибки в логгер Android для отладки
            null
        }
    }
}
