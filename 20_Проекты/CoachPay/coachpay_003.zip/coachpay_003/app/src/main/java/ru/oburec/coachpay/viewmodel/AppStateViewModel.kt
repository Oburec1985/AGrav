package ru.oburec.coachpay.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ru.oburec.coachpay.data.StorageManager
import ru.oburec.coachpay.data.SyncManager
import ru.oburec.coachpay.data.InviteInfo
import ru.oburec.coachpay.model.*
import ru.oburec.coachpay.ui.utils.MonthUtils

class AppStateViewModel(
    private val storageManager: StorageManager,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val mainDispatcher: CoroutineDispatcher = Dispatchers.Main
) : ViewModel() {

    private val _state = MutableStateFlow(AppState())
    val state: StateFlow<AppState> = _state.asStateFlow()

    init {
        loadState()
    }

    fun loadState(defaultClientId: String = "", defaultApiKey: String = "") {
        viewModelScope.launch(ioDispatcher) {
            val loadedState = storageManager.loadState()
            
            // Если сохраненный API Key пустой, используем дефолтный
            val fallbackApiKey = defaultApiKey.ifEmpty { "AIzaSyCCy_iHK23qwNeH0J665RmbJ9OO0zwQZwI" }
            val finalApiKey = loadedState.firebaseApiKey.ifEmpty { fallbackApiKey }
            val finalClientId = loadedState.googleClientId.ifEmpty { defaultClientId }
            
            var normalizedState = normalizeState(loadedState).copy(
                firebaseApiKey = finalApiKey,
                googleClientId = finalClientId
            )
            if (normalizedState.role == AppRole.COACH) {
                if (normalizedState.firebaseUid.isEmpty()) {
                    normalizedState = normalizedState.copy(
                        firebaseUid = "default_coach_owner",
                        googleEmail = "owner@coachpay.ru"
                    )
                }
                val coachData = normalizedState.coachData
                if (coachData != null && coachData.coachId != normalizedState.firebaseUid) {
                    normalizedState = normalizedState.copy(
                        coachData = coachData.copy(coachId = normalizedState.firebaseUid)
                    )
                }
            }
            if (normalizedState != loadedState) {
                storageManager.saveState(normalizedState)
            }
            SyncManager.currentAuthToken = normalizedState.firebaseToken.ifEmpty { null }
            _state.value = normalizedState

            // Если есть рефреш токен и он близок к истечению, обновляем в фоне
            if (normalizedState.refreshToken.isNotEmpty() && normalizedState.firebaseApiKey.isNotEmpty()) {
                val shouldRefresh = normalizedState.tokenExpiryTime <= System.currentTimeMillis() + 5 * 60 * 1000
                if (shouldRefresh) {
                    val resp = SyncManager.refreshFirebaseToken(normalizedState.firebaseApiKey, normalizedState.refreshToken)
                    if (resp != null) {
                        val expiryTime = System.currentTimeMillis() + (resp.expires_in.toLongOrNull() ?: 3600L) * 1000
                        val updated = normalizedState.copy(
                            firebaseToken = resp.id_token,
                            refreshToken = resp.refresh_token,
                            tokenExpiryTime = expiryTime
                        )
                        SyncManager.currentAuthToken = resp.id_token
                        saveState(updated)
                        normalizedState = updated
                    }
                }
            }

            // Фоновая синхронизация с облаком при старте приложения
            if (normalizedState.firebaseUid.isNotEmpty()) {
                try {
                    if (normalizedState.role == AppRole.COACH) {
                        val cloudCoachData = SyncManager.pullCoachData(normalizedState.firebaseUid)
                        if (cloudCoachData != null) {
                            val updatedState = normalizedState.copy(
                                coachData = cloudCoachData,
                                lastSyncTime = System.currentTimeMillis()
                            )
                            withContext(mainDispatcher) {
                                _state.value = updatedState
                                storageManager.saveState(updatedState)
                            }
                        }
                    } else if (normalizedState.role == AppRole.STUDENT && normalizedState.studentConfig != null && !normalizedState.studentConfig.studentId.isNullOrEmpty()) {
                        val config = normalizedState.studentConfig
                        val studentId = config.studentId!!
                        val cloudPayments = SyncManager.pullPayments(config.coachId, studentId)
                        val cloudProfile = SyncManager.pullProfile(config.coachId, studentId)
                        val cloudSchedule = if (config.groupId.isNotEmpty()) {
                            SyncManager.pullSchedule(config.coachId, config.groupId)
                        } else null

                        if (cloudPayments != null || cloudProfile != null || cloudSchedule != null) {
                            val updatedConfig = config.copy(
                                payments = cloudPayments ?: config.payments,
                                phone = cloudProfile?.phone ?: config.phone,
                                birthDate = cloudProfile?.birthDate ?: config.birthDate,
                                height = cloudProfile?.height ?: config.height,
                                weight = cloudProfile?.weight ?: config.weight,
                                weeklySchedule = cloudSchedule?.weeklySchedule ?: config.weeklySchedule,
                                oneOffEvents = cloudSchedule?.oneOffEvents ?: config.oneOffEvents
                            )
                            val updatedState = normalizedState.copy(
                                studentConfig = updatedConfig,
                                lastSyncTime = System.currentTimeMillis()
                            )
                            withContext(mainDispatcher) {
                                _state.value = updatedState
                                storageManager.saveState(updatedState)
                            }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    internal fun saveState(newState: AppState) {
        _state.value = newState
        SyncManager.currentAuthToken = newState.firebaseToken.ifEmpty { null }
        viewModelScope.launch(ioDispatcher) {
            storageManager.saveState(newState)
            
            // Автоматически выгружаем измененную структуру тренера в облако
            if (newState.role == AppRole.COACH && newState.firebaseUid.isNotEmpty() && newState.coachData != null) {
                try {
                    val success = SyncManager.pushCoachData(newState.firebaseUid, newState.coachData)
                    if (success) {
                        val stateWithSyncTime = newState.copy(lastSyncTime = System.currentTimeMillis())
                        storageManager.saveState(stateWithSyncTime)
                        withContext(mainDispatcher) {
                            _state.value = stateWithSyncTime
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    fun setRole(role: AppRole) {
        val current = _state.value
        var coachData = if (role == AppRole.COACH && current.coachData == null) CoachData() else current.coachData
        
        // Предзаполняем тестовые данные: Мытищи, Скрипник Марк
        if (role == AppRole.COACH && coachData != null && coachData.cities.isEmpty()) {
            coachData = coachData.copy(
                cities = listOf(
                    City(
                        name = "Мытищи",
                        groups = listOf(
                            StudentGroup(
                                name = "Основная группа",
                                defaultMonthlyFee = 3000.0,
                                students = listOf(
                                    Student(
                                        firstName = "Марк",
                                        lastName = "Скрипник",
                                        monthlyFee = 3000.0,
                                        joinMonth = "2026-05"
                                    ),
                                    Student(
                                        firstName = "Брюс",
                                        lastName = "Ли",
                                        monthlyFee = 3000.0,
                                        joinMonth = "2026-03"
                                     )
                                )
                            )
                        )
                    )
                )
            )
        }
        
        val studentConfig = if (role == AppRole.STUDENT && current.studentConfig == null) StudentConfig() else current.studentConfig
        
        // Корректируем firebaseUid и coachId для роли COACH в режиме байпаса
        var updatedUid = current.firebaseUid
        var updatedEmail = current.googleEmail
        if (role == AppRole.COACH) {
            if (updatedUid.isEmpty()) {
                updatedUid = "default_coach_owner"
                updatedEmail = "owner@coachpay.ru"
            }
            if (coachData != null) {
                coachData = coachData.copy(coachId = updatedUid)
            }
        }

        saveState(current.copy(role = role, coachData = coachData, studentConfig = studentConfig, firebaseUid = updatedUid, googleEmail = updatedEmail))

        if (updatedUid.isNotEmpty()) {
            viewModelScope.launch(ioDispatcher) {
                val existing = SyncManager.getUserProfile(updatedUid)
                val updatedProfile = UserProfile(
                    uid = updatedUid,
                    email = updatedEmail,
                    role = role.name,
                    coachId = existing?.coachId ?: if (role == AppRole.COACH) updatedUid else "",
                    cityId = existing?.cityId ?: "",
                    cityName = existing?.cityName ?: "",
                    groupId = existing?.groupId ?: "",
                    groupName = existing?.groupName ?: "",
                    studentId = existing?.studentId ?: "",
                    studentName = existing?.studentName ?: ""
                )
                SyncManager.saveUserProfile(updatedUid, updatedProfile)
            }
        }
    }


    // ==========================================
    // Управление Городами
    // ==========================================

    fun addCity(name: String) {
        val current = _state.value
        val coach = current.coachData ?: return
        val newCity = City(name = name)
        val updatedCities = coach.cities + newCity
        
        saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
    }

    fun editCity(cityId: String, newName: String) {
        val current = _state.value
        val coach = current.coachData ?: return
        val updatedCities = coach.cities.map {
            if (it.id == cityId) it.copy(name = newName) else it
        }
        
        saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
    }

    fun deleteCity(cityId: String) {
        val current = _state.value
        val coach = current.coachData ?: return
        val updatedCities = coach.cities.filterNot { it.id == cityId }
        
        saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
    }

    // ==========================================
    // Управление Группами / Классами
    // ==========================================

    fun addGroup(cityId: String, groupName: String, defaultMonthlyFee: Double = 3000.0) {
        val current = _state.value
        val coach = current.coachData ?: return
        val updatedCities = coach.cities.map { city ->
            if (city.id == cityId) {
                val newGroup = StudentGroup(name = groupName, defaultMonthlyFee = defaultMonthlyFee)
                city.copy(groups = city.groups + newGroup)
            } else {
                city
            }
        }
        
        saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
    }

    fun editGroup(cityId: String, groupId: String, newGroupName: String, defaultMonthlyFee: Double) {
        val current = _state.value
        val coach = current.coachData ?: return
        val updatedCities = coach.cities.map { city ->
            if (city.id == cityId) {
                val updatedGroups = city.groups.map { group ->
                    if (group.id == groupId) group.copy(name = newGroupName, defaultMonthlyFee = defaultMonthlyFee) else group
                }
                city.copy(groups = updatedGroups)
            } else {
                city
            }
        }
        
        saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
    }

    fun deleteGroup(cityId: String, groupId: String) {
        val current = _state.value
        val coach = current.coachData ?: return
        val updatedCities = coach.cities.map { city ->
            if (city.id == cityId) {
                city.copy(groups = city.groups.filterNot { it.id == groupId })
            } else {
                city
            }
        }
        
        saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
    }

    // ==========================================
    // Управление Учениками
    // ==========================================

    fun addStudent(cityId: String, groupId: String, firstName: String, lastName: String, joinMonth: String, phone: String = "") {
        val current = _state.value
        val coach = current.coachData ?: return
        var studentId = ""
        var cityName = ""
        var groupName = ""
        val updatedCities = coach.cities.map { city ->
            if (city.id == cityId) {
                cityName = city.name
                val updatedGroups = city.groups.map { group ->
                    if (group.id == groupId) {
                        groupName = group.name
                        val newStudent = Student(
                            firstName = firstName,
                            lastName = lastName,
                            monthlyFee = group.defaultMonthlyFee,
                            joinMonth = joinMonth,
                            phone = phone
                        )
                        studentId = newStudent.id
                        group.copy(students = group.students + newStudent)
                    } else {
                        group
                    }
                }
                city.copy(groups = updatedGroups)
            } else {
                city
            }
        }
        
        saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
        
        if (studentId.isNotEmpty()) {
            if (phone.isNotEmpty()) {
                pushPhoneLinkIfAny(phone, coach.coachId, cityId, cityName, groupId, groupName, studentId, "$lastName $firstName")
            }
            viewModelScope.launch(ioDispatcher) {
                SyncManager.pushProfile(coach.coachId, studentId, "", "", "", phone)
            }
        }
    }

    fun editStudent(cityId: String, groupId: String, studentId: String, firstName: String, lastName: String, joinMonth: String, phone: String = "") {
        val current = _state.value
        val coach = current.coachData ?: return
        var cityName = ""
        var groupName = ""
        val oldStudent = coach.cities.find { it.id == cityId }?.groups?.find { it.id == groupId }?.students?.find { it.id == studentId }
        val oldPhone = oldStudent?.phone ?: ""

        val updatedCities = coach.cities.map { city ->
            if (city.id == cityId) {
                cityName = city.name
                val updatedGroups = city.groups.map { group ->
                    if (group.id == groupId) {
                        groupName = group.name
                        val updatedStudents = group.students.map { student ->
                            if (student.id == studentId) {
                                val cleanPayments = if (joinMonth.isNotEmpty()) {
                                    student.payments.filterNot { it.title == "Абонемент" && it.month.isNotEmpty() && it.month < joinMonth }
                                } else {
                                    student.payments
                                }
                                student.copy(firstName = firstName, lastName = lastName, joinMonth = joinMonth, payments = cleanPayments, phone = phone)
                            } else {
                                student
                            }
                        }
                        group.copy(students = updatedStudents)
                    } else {
                        group
                    }
                }
                city.copy(groups = updatedGroups)
            } else {
                city
            }
        }
        
        saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
        
        val freshStudent = _state.value.coachData?.cities?.find { it.id == cityId }?.groups?.find { it.id == groupId }?.students?.find { it.id == studentId }
        if (freshStudent != null) {
            if (oldPhone.isNotEmpty() && cleanPhoneNumber(oldPhone) != cleanPhoneNumber(phone)) {
                deletePhoneLinkIfAny(oldPhone)
            }
            if (phone.isNotEmpty() && cleanPhoneNumber(oldPhone) != cleanPhoneNumber(phone)) {
                pushPhoneLinkIfAny(phone, coach.coachId, cityId, cityName, groupId, groupName, studentId, "$lastName $firstName")
            }
            viewModelScope.launch(ioDispatcher) {
                SyncManager.pushProfile(coach.coachId, studentId, freshStudent.birthDate, freshStudent.height, freshStudent.weight, phone)
            }
        }
    }

    fun deleteStudent(cityId: String, groupId: String, studentId: String) {
        val current = _state.value
        val coach = current.coachData ?: return
        val student = coach.cities.find { it.id == cityId }?.groups?.find { it.id == groupId }?.students?.find { it.id == studentId }
        val phone = student?.phone ?: ""

        val updatedCities = coach.cities.map { city ->
            if (city.id == cityId) {
                val updatedGroups = city.groups.map { group ->
                    if (group.id == groupId) {
                        group.copy(students = group.students.filterNot { it.id == studentId })
                    } else {
                        group
                    }
                }
                city.copy(groups = updatedGroups)
            } else {
                city
            }
        }
        
        saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
        
        if (phone.isNotEmpty()) {
            deletePhoneLinkIfAny(phone)
        }
    }

    // ==========================================
    // УПРАВЛЕНИЕ КАЛЕНДАРЕМ И ОПЛАТАМИ
    // ==========================================

    fun generateMonthlyPaymentsIfNeeded(cityId: String, groupId: String, month: String) {
        val current = _state.value
        val coach = current.coachData ?: return
        var changed = false
        val pushedPayments = mutableListOf<Pair<String, List<Payment>>>()
        val updatedCities = coach.cities.map { city ->
            if (city.id == cityId) {
                val updatedGroups = city.groups.map { group ->
                    if (group.id == groupId) {
                        val updatedStudents = group.students.map { student ->
                            val startMonth = student.joinMonth.ifEmpty { month }
                            val months = getMonthsBetween(startMonth, month)
                            val updatedPayments = student.payments.toMutableList()
                            var studentChanged = false
                            for (m in months) {
                                val hasSubscription = updatedPayments.any { it.month == m && it.title == "Абонемент" }
                                if (!hasSubscription) {
                                    changed = true
                                    studentChanged = true
                                    updatedPayments.add(
                                        Payment(
                                            amount = student.monthlyFee,
                                            month = m,
                                            state = PaymentState.UNPAID,
                                            title = "Абонемент"
                                        )
                                    )
                                }
                            }
                            if (studentChanged) {
                                pushedPayments.add(student.id to updatedPayments)
                                student.copy(payments = updatedPayments)
                            } else {
                                student
                            }
                        }
                        group.copy(students = updatedStudents)
                    } else {
                        group
                    }
                }
                city.copy(groups = updatedGroups)
            } else {
                city
            }
        }
        if (changed) {
            saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
            pushedPayments.forEach { (studentId, payments) ->
                pushStudentPaymentsToCloud(studentId, payments)
            }
        }
    }


    fun togglePaymentState(cityId: String, groupId: String, studentId: String, paymentId: String, currentSelectedMonth: String) {
        val current = _state.value
        val coach = current.coachData ?: return
        val updatedCities = coach.cities.map { city ->
            if (city.id == cityId) {
                val updatedGroups = city.groups.map { group ->
                    if (group.id == groupId) {
                        val updatedStudents = group.students.map { student ->
                            if (student.id == studentId) {
                                val updatedPayments = student.payments.map { payment ->
                                    if (payment.id == paymentId) {
                                        val nextState = when (payment.state) {
                                            PaymentState.PAID -> PaymentState.UNPAID
                                            PaymentState.UNPAID -> PaymentState.PAID
                                            PaymentState.PENDING_APPROVAL -> PaymentState.PAID
                                        }
                                        val confirmedTime = if (nextState == PaymentState.PAID) System.currentTimeMillis() else null
                                        
                                        // Если платеж внемесячный (пустой) и стал PAID, привязываем его к текущему выбранному месяцу.
                                        // Если стал UNPAID и это кастомный платеж, сбрасываем привязку к месяцу (чтобы снова отображался везде как долг).
                                        val newMonth = if (nextState == PaymentState.PAID && payment.month.isEmpty()) {
                                            currentSelectedMonth
                                        } else if (nextState == PaymentState.UNPAID && payment.month == currentSelectedMonth && payment.title != "Абонемент") {
                                            ""
                                        } else {
                                            payment.month
                                        }

                                        payment.copy(state = nextState, confirmedAt = confirmedTime, month = newMonth)
                                    } else {
                                        payment
                                    }
                                }
                                student.copy(payments = updatedPayments)
                            } else {
                                student
                            }
                        }
                        group.copy(students = updatedStudents)
                    } else {
                        group
                    }
                }
                city.copy(groups = updatedGroups)
            } else {
                city
            }
        }
        saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
        val freshStudent = _state.value.coachData?.cities?.find { it.id == cityId }?.groups?.find { it.id == groupId }?.students?.find { it.id == studentId }
        if (freshStudent != null) {
            pushStudentPaymentsToCloud(studentId, freshStudent.payments)
        }
    }

    fun approveAllPendingPayments(cityId: String, groupId: String, studentId: String) {
        val current = _state.value
        val coach = current.coachData ?: return
        val updatedCities = coach.cities.map { city ->
            if (city.id == cityId) {
                val updatedGroups = city.groups.map { group ->
                    if (group.id == groupId) {
                        val updatedStudents = group.students.map { student ->
                            if (student.id == studentId) {
                                val updatedPayments = student.payments.map { payment ->
                                    if (payment.state == PaymentState.PENDING_APPROVAL) {
                                        val currentRealMonth = java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.US).format(java.util.Date())
                                        val newMonth = if (payment.month.isEmpty()) currentRealMonth else payment.month
                                        payment.copy(state = PaymentState.PAID, confirmedAt = System.currentTimeMillis(), month = newMonth)
                                    } else {
                                        payment
                                    }
                                }
                                student.copy(payments = updatedPayments)
                            } else {
                                student
                            }
                        }
                        group.copy(students = updatedStudents)
                    } else {
                        group
                    }
                }
                city.copy(groups = updatedGroups)
            } else {
                city
            }
        }
        saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
        val freshStudent = _state.value.coachData?.cities?.find { it.id == cityId }?.groups?.find { it.id == groupId }?.students?.find { it.id == studentId }
        if (freshStudent != null) {
            pushStudentPaymentsToCloud(studentId, freshStudent.payments)
        }
    }

    fun addCustomPayment(cityId: String, groupId: String, studentId: String, title: String, amount: Double, month: String) {
        val current = _state.value
        val coach = current.coachData ?: return
        val updatedCities = coach.cities.map { city ->
            if (city.id == cityId) {
                val updatedGroups = city.groups.map { group ->
                    if (group.id == groupId) {
                        val updatedStudents = group.students.map { student ->
                            if (student.id == studentId) {
                                val newPayment = Payment(
                                    amount = amount,
                                    month = month,
                                    state = PaymentState.UNPAID,
                                    title = title
                                )
                                student.copy(payments = student.payments + newPayment)
                            } else {
                                student
                            }
                        }
                        group.copy(students = updatedStudents)
                    } else {
                        group
                    }
                }
                city.copy(groups = updatedGroups)
            } else {
                city
            }
        }
        saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
        val freshStudent = _state.value.coachData?.cities?.find { it.id == cityId }?.groups?.find { it.id == groupId }?.students?.find { it.id == studentId }
        if (freshStudent != null) {
            pushStudentPaymentsToCloud(studentId, freshStudent.payments)
        }
    }

    fun addGroupPayment(
        cityId: String,
        groupId: String,
        studentIds: List<String>,
        title: String,
        amount: Double,
        month: String
    ) {
        val current = _state.value
        val coach = current.coachData ?: return
        val updatedCities = coach.cities.map { city ->
            if (city.id == cityId) {
                val updatedGroups = city.groups.map { group ->
                    if (group.id == groupId) {
                        val updatedStudents = group.students.map { student ->
                            if (studentIds.contains(student.id)) {
                                val newPayment = Payment(
                                    amount = amount,
                                    month = month,
                                    state = PaymentState.UNPAID,
                                    title = title
                                )
                                student.copy(payments = student.payments + newPayment)
                            } else {
                                student
                            }
                        }
                        group.copy(students = updatedStudents)
                    } else {
                        group
                    }
                }
                city.copy(groups = updatedGroups)
            } else {
                city
            }
        }
        saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
        val freshGroup = _state.value.coachData?.cities?.find { it.id == cityId }?.groups?.find { it.id == groupId }
        if (freshGroup != null) {
            freshGroup.students.filter { studentIds.contains(it.id) }.forEach { student ->
                pushStudentPaymentsToCloud(student.id, student.payments)
            }
        }
    }

    fun changeMonthlyFee(cityId: String, groupId: String, studentId: String, newFee: Double) {
        val current = _state.value
        val coach = current.coachData ?: return
        val updatedCities = coach.cities.map { city ->
            if (city.id == cityId) {
                val updatedGroups = city.groups.map { group ->
                    if (group.id == groupId) {
                        val updatedStudents = group.students.map { student ->
                            if (student.id == studentId) {
                                student.copy(monthlyFee = newFee)
                            } else {
                                student
                            }
                        }
                        group.copy(students = updatedStudents)
                    } else {
                        group
                    }
                }
                city.copy(groups = updatedGroups)
            } else {
                city
            }
        }
        saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
    }

    /**
     * Форматирует список должников группы для копирования в мессенджер.
     * Возвращает текст по шаблону:
     * Фамилия Имя: платеж 1 (мес) сумма, платеж 2 сумма
     */
    fun getGroupDebtsFormattedText(cityId: String, groupId: String, maxMonth: String = ""): String {
        val current = _state.value
        val coach = current.coachData ?: return ""
        val city = coach.cities.find { it.id == cityId } ?: return ""
        val group = city.groups.find { it.id == groupId } ?: return ""
        
        // Определяем граничный месяц для генерации и фильтрации долгов
        val limitMonth = if (maxMonth.isNotEmpty()) maxMonth else java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.US).format(java.util.Date())
        
        var changed = false
        val updatedCities = coach.cities.map { c ->
            if (c.id == cityId) {
                val updatedGroups = c.groups.map { g ->
                    if (g.id == groupId) {
                        val updatedStudents = g.students.map { student ->
                            if (student.joinMonth.isNotEmpty()) {
                                val months = getMonthsBetween(student.joinMonth, limitMonth)
                                var studentWithPayments = student
                                months.forEach { m ->
                                    val hasSubscription = studentWithPayments.payments.any { it.month == m && it.title == "Абонемент" }
                                    if (!hasSubscription) {
                                        changed = true
                                        val newPayment = Payment(
                                            amount = studentWithPayments.monthlyFee,
                                            month = m,
                                            state = PaymentState.UNPAID,
                                            title = "Абонемент"
                                        )
                                        studentWithPayments = studentWithPayments.copy(payments = studentWithPayments.payments + newPayment)
                                    }
                                }
                                studentWithPayments
                            } else {
                                student
                            }
                        }
                        g.copy(students = updatedStudents)
                    } else {
                        g
                    }
                }
                c.copy(groups = updatedGroups)
            } else {
                c
            }
        }
        
        if (changed) {
            saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
        }
        
        // Перечитываем актуальные данные после генерации
        val freshGroup = _state.value.coachData?.cities?.find { it.id == cityId }?.groups?.find { it.id == groupId } ?: group
        
        val debtLines = mutableListOf<String>()
        freshGroup.students.forEach { student ->
            // Отбираем только неоплаченные платежи, которые не привязаны к месяцу (разовые) или месяц которых не больше граничного месяца
            val unpaidPayments = student.payments.filter { 
                it.state != PaymentState.PAID && (it.month.isEmpty() || it.month <= limitMonth)
            }
            if (unpaidPayments.isNotEmpty()) {
                val paymentsText = unpaidPayments.joinToString("; ") { payment ->
                    val amountVal = payment.amount.toInt()
                    if (payment.month.isNotEmpty()) {
                        "${formatMonthOnly(payment.month)} $amountVal"
                    } else {
                        "${payment.title} $amountVal"
                    }
                } + ";"
                debtLines.add("${student.lastName} ${student.firstName}: $paymentsText")
            }
        }
        
        return if (debtLines.isNotEmpty()) {
            debtLines.joinToString("\n")
        } else {
            "В группе ${freshGroup.name} нет долгов!"
        }
    }

    private fun getMonthsBetween(startMonth: String, endMonth: String): List<String> {
        if (startMonth.isEmpty() || endMonth.isEmpty() || startMonth > endMonth) return emptyList()
        val result = mutableListOf<String>()
        var current = startMonth
        while (current <= endMonth) {
            result.add(current)
            val parts = current.split("-")
            val year = parts[0].toInt()
            val month = parts[1].toInt()
            val nextMonth = if (month == 12) 1 else month + 1
            val nextYear = if (month == 12) year + 1 else year
            current = String.format(java.util.Locale.US, "%04d-%02d", nextYear, nextMonth)
        }
        return result
    }

    private fun formatMonthOnly(monthStr: String): String {
        try {
            val sdfInput = java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.US)
            val sdfOutput = java.text.SimpleDateFormat("LLLL", java.util.Locale("ru"))
            val date = sdfInput.parse(monthStr) ?: return monthStr
            return sdfOutput.format(date).lowercase()
        } catch (e: Exception) {
            return monthStr
        }
    }

    private fun formatYearMonthToShort(yearMonth: String): String {
        if (yearMonth.length != 7 || yearMonth[4] != '-') return yearMonth
        val year2 = yearMonth.substring(2, 4)
        val month = yearMonth.substring(5, 7)
        return "$month.$year2"
    }

    // ==========================================
    // СИНХРОНИЗАЦИЯ С ОБЛАКОМ (FIREBASE REST API)
    // ==========================================

    // Хелпер для фонового обновления платежей в облаке
    private fun pushStudentPaymentsToCloud(studentId: String, payments: List<Payment>) {
        val coach = _state.value.coachData ?: return
        viewModelScope.launch(ioDispatcher) {
            SyncManager.pushPayments(coach.coachId, studentId, payments)
        }
    }

    // Генерация инвайт-кода для связывания устройств
    fun generateInviteCode(
        cityId: String,
        groupId: String,
        studentId: String,
        studentName: String,
        onComplete: (String) -> Unit
    ) {
        val coach = _state.value.coachData
        if (coach == null) {
            return
        }
        val city = coach.cities.find { it.id == cityId }
        val group = city?.groups?.find { it.id == groupId }
        val cityName = city?.name ?: ""
        val groupName = group?.name ?: ""
        
        val code = (100000 + kotlin.math.abs(studentId.hashCode() % 900000)).toString()
        
        // Отдаем сгенерированный код сразу для мгновенного показа в UI
        onComplete(code)
        
        // Заливаем код в облако в фоновом режиме
        viewModelScope.launch(ioDispatcher) {
            val success = SyncManager.createInvite(
                inviteCode = code,
                coachId = coach.coachId,
                cityId = cityId,
                cityName = cityName,
                groupId = groupId,
                groupName = groupName,
                studentId = studentId,
                studentName = studentName
            )
            if (success) {
                // Пушим также текущие платежи ученика, чтобы при первом входе ученик их увидел
                val student = group?.students?.find { it.id == studentId }
                if (student != null) {
                    SyncManager.pushPayments(coach.coachId, studentId, student.payments)
                }
            }
        }
    }

    // Привязка кабинета ученика по коду или по телефону
    fun linkStudentByInviteCode(codeOrPhone: String, onComplete: (Boolean, String?) -> Unit) {
        viewModelScope.launch(ioDispatcher) {
            val cleanedInput = codeOrPhone.filter { it.isDigit() }
            var info: InviteInfo? = null
            
            // 1. Попробуем найти как 6-значный инвайт-код
            if (cleanedInput.length == 6) {
                info = SyncManager.getInvite(cleanedInput)
            }
            
            // 2. Если не нашли, попробуем как номер телефона
            if (info == null) {
                val cleanedPhone = cleanPhoneNumber(codeOrPhone)
                if (cleanedPhone.isNotEmpty()) {
                    info = SyncManager.getPhoneLink(cleanedPhone)
                }
            }
            
            val linkedInfo = info
            if (linkedInfo != null) {
                val payments = SyncManager.pullPayments(linkedInfo.coachId, linkedInfo.studentId) ?: emptyList()
                val profile = SyncManager.pullProfile(linkedInfo.coachId, linkedInfo.studentId)
                val currentMonday = MonthUtils.getMondayOfWeek(0)
                val schedule = if (linkedInfo.groupId.isNotEmpty()) {
                    val weekSchedule = SyncManager.pullSchedule(linkedInfo.coachId, linkedInfo.groupId, currentMonday)
                    if (weekSchedule != null && (weekSchedule.weeklySchedule.isNotEmpty() || weekSchedule.oneOffEvents.isNotEmpty())) {
                        weekSchedule
                    } else {
                        SyncManager.pullSchedule(linkedInfo.coachId, linkedInfo.groupId)
                    }
                } else null
                val nameParts = linkedInfo.studentName.split(" ")
                val lastName = nameParts.getOrNull(0) ?: ""
                val firstName = nameParts.getOrNull(1) ?: ""
                
                val newConfig = StudentConfig(
                    coachId = linkedInfo.coachId,
                    cityName = linkedInfo.cityName,
                    groupName = linkedInfo.groupName,
                    firstName = firstName,
                    lastName = lastName,
                    studentId = linkedInfo.studentId,
                    payments = payments,
                    inviteCode = if (cleanedInput.length == 6) cleanedInput else "",
                    phone = profile?.phone ?: "",
                    birthDate = profile?.birthDate ?: "",
                    height = profile?.height ?: "",
                    weight = profile?.weight ?: "",
                    cityId = linkedInfo.cityId,
                    groupId = linkedInfo.groupId,
                    weeklySchedule = schedule?.weeklySchedule ?: emptyList(),
                    oneOffEvents = schedule?.oneOffEvents ?: emptyList()
                )
                // Если авторизован через Google, привязываем на сервере
                val curState = _state.value
                if (curState.firebaseUid.isNotEmpty()) {
                    val userProfile = UserProfile(
                        uid = curState.firebaseUid,
                        email = curState.googleEmail,
                        role = "STUDENT",
                        coachId = linkedInfo.coachId,
                        cityId = linkedInfo.cityId,
                        cityName = linkedInfo.cityName,
                        groupId = linkedInfo.groupId,
                        groupName = linkedInfo.groupName,
                        studentId = linkedInfo.studentId,
                        studentName = linkedInfo.studentName
                    )
                    SyncManager.saveUserProfile(curState.firebaseUid, userProfile)
                }
                withContext(mainDispatcher) {
                    saveState(_state.value.copy(role = AppRole.STUDENT, studentConfig = newConfig))
                    onComplete(true, linkedInfo.studentName)
                }
            } else {
                withContext(mainDispatcher) {
                    onComplete(false, null)
                }
            }
        }
    }

    // Скачать платежи для ученика с поддержкой оффлайн-сверки
    fun pullPaymentsForStudent(onComplete: (Boolean) -> Unit = {}) {
        val config = _state.value.studentConfig
        if (config == null) {
            onComplete(false)
            return
        }
        val studentId = config.studentId
        if (studentId == null) {
            onComplete(false)
            return
        }
        viewModelScope.launch(ioDispatcher) {
            val cloudPayments = SyncManager.pullPayments(config.coachId, studentId)
            val profile = SyncManager.pullProfile(config.coachId, studentId)
            val currentMonday = MonthUtils.getMondayOfWeek(0)
            val schedule = if (config.groupId.isNotEmpty()) {
                val weekSchedule = SyncManager.pullSchedule(config.coachId, config.groupId, currentMonday)
                if (weekSchedule != null && (weekSchedule.weeklySchedule.isNotEmpty() || weekSchedule.oneOffEvents.isNotEmpty())) {
                    weekSchedule
                } else {
                    SyncManager.pullSchedule(config.coachId, config.groupId)
                }
            } else null
            
            val current = _state.value
            val localPayments = config.payments
            var needsPush = false
            
            val mergedPayments = if (cloudPayments != null) {
                cloudPayments.map { cloud ->
                    val local = localPayments.find { it.id == cloud.id }
                    if (local != null) {
                        // Если локально помечено как PENDING_APPROVAL, а в облаке еще UNPAID (оффлайн отметка), сохраняем локальный статус
                        if (local.state == PaymentState.PENDING_APPROVAL && cloud.state == PaymentState.UNPAID) {
                            needsPush = true
                            local
                        } else {
                            cloud
                        }
                    } else {
                        cloud
                    }
                }
            } else {
                localPayments
            }
            
            val mergedBirthDate = if (profile?.birthDate?.isNotEmpty() == true) profile.birthDate else config.birthDate
            val mergedHeight = if (profile?.height?.isNotEmpty() == true) profile.height else config.height
            val mergedWeight = if (profile?.weight?.isNotEmpty() == true) profile.weight else config.weight
            val mergedPhone = if (profile?.phone?.isNotEmpty() == true) profile.phone else config.phone

            val updatedConfig = config.copy(
                payments = mergedPayments,
                birthDate = mergedBirthDate,
                height = mergedHeight,
                weight = mergedWeight,
                phone = mergedPhone,
                weeklySchedule = schedule?.weeklySchedule ?: config.weeklySchedule,
                oneOffEvents = schedule?.oneOffEvents ?: config.oneOffEvents
            )
            saveState(current.copy(studentConfig = updatedConfig))
            
            if (needsPush && cloudPayments != null) {
                SyncManager.pushPayments(config.coachId, studentId, mergedPayments)
            }
            withContext(mainDispatcher) {
                onComplete(true)
            }
        }
    }

    // Обновить профильные данные ученика (дата рождения, рост, вес, телефон)
    fun updateStudentProfile(birthDate: String, height: String, weight: String, phone: String = "", onComplete: (Boolean) -> Unit = {}) {
        val config = _state.value.studentConfig ?: return
        val studentId = config.studentId ?: return
        val updatedConfig = config.copy(birthDate = birthDate, height = height, weight = weight, phone = phone)
        val current = _state.value
        saveState(current.copy(studentConfig = updatedConfig))
        
        viewModelScope.launch(ioDispatcher) {
            val success = SyncManager.pushProfile(config.coachId, studentId, birthDate, height, weight, phone)
            
            // Заливаем также телефонную связку, если номер не пустой
            val cleanedPhone = cleanPhoneNumber(phone)
            if (success && cleanedPhone.isNotEmpty()) {
                SyncManager.createPhoneLink(
                    cleanedPhone,
                    config.coachId,
                    config.cityId,
                    config.cityName,
                    config.groupId,
                    config.groupName,
                    studentId,
                    "${config.lastName} ${config.firstName}"
                )
            }
            withContext(mainDispatcher) {
                onComplete(success)
            }
        }
    }

    // Обновить расписание и мероприятия группы тренером
    fun updateGroupSchedule(
        cityId: String,
        groupId: String,
        weeklySchedule: List<WeeklyClass>,
        oneOffEvents: List<GroupEvent>,
        weekMonday: String? = null,
        onComplete: (Boolean) -> Unit = {}
    ) {
        val current = _state.value
        val coach = current.coachData ?: return
        val sortedSchedule = weeklySchedule.sortedBy { it.startTime }
        
        val updatedCities = coach.cities.map { c ->
            if (c.id == cityId) {
                val updatedGroups = c.groups.map { g ->
                    if (g.id == groupId) {
                        if (weekMonday == null) {
                            g.copy(
                                weeklySchedule = sortedSchedule,
                                oneOffEvents = oneOffEvents
                            )
                        } else {
                            val newSchedules = g.schedulesByWeek.toMutableMap()
                            newSchedules[weekMonday] = GroupSchedule(sortedSchedule, oneOffEvents)
                            g.copy(schedulesByWeek = newSchedules)
                        }
                    } else {
                        g
                    }
                }
                c.copy(groups = updatedGroups)
            } else {
                c
            }
        }
        
        saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
        
        // Push to cloud
        viewModelScope.launch(ioDispatcher) {
            val success = SyncManager.pushSchedule(
                coach.coachId,
                groupId,
                GroupSchedule(sortedSchedule, oneOffEvents),
                weekMonday
            )
            withContext(mainDispatcher) {
                onComplete(success)
            }
        }
    }

    // Загрузка занятий с записью из облака (для тренера)
    fun syncBookings(cityId: String, groupId: String, onComplete: (Boolean) -> Unit = {}) {
        val current = _state.value
        val coach = current.coachData ?: return
        
        viewModelScope.launch(ioDispatcher) {
            val bookings = SyncManager.pullBookings(coach.coachId, groupId)
            if (bookings != null) {
                withContext(mainDispatcher) {
                    val updatedCities = coach.cities.map { c ->
                        if (c.id == cityId) {
                            val updatedGroups = c.groups.map { g ->
                                if (g.id == groupId) {
                                    g.copy(bookings = bookings)
                                } else g
                            }
                            c.copy(groups = updatedGroups)
                        } else c
                    }
                    saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
                    onComplete(true)
                }
            } else {
                withContext(mainDispatcher) {
                    onComplete(false)
                }
            }
        }
    }

    // Добавление/обновление занятия с записью (тренер)
    fun addOrUpdateBookingClass(
        cityId: String,
        groupId: String,
        booking: BookingClass,
        onComplete: (Boolean) -> Unit = {}
    ) {
        val current = _state.value
        val coach = current.coachData ?: return
        val city = coach.cities.find { it.id == cityId } ?: return
        val group = city.groups.find { it.id == groupId } ?: return
        
        val newBookings = group.bookings.filter { it.id != booking.id }.toMutableList()
        newBookings.add(booking)
        val sortedBookings = newBookings.sortedWith(compareBy({ it.date }, { it.time }))
        
        val updatedCities = coach.cities.map { c ->
            if (c.id == cityId) {
                val updatedGroups = c.groups.map { g ->
                    if (g.id == groupId) {
                        g.copy(bookings = sortedBookings)
                    } else g
                }
                c.copy(groups = updatedGroups)
            } else c
        }
        saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
        
        viewModelScope.launch(ioDispatcher) {
            val success = SyncManager.pushBookings(coach.coachId, groupId, sortedBookings)
            withContext(mainDispatcher) {
                onComplete(success)
            }
        }
    }

    // Добавление списка занятий с записью (пакетное добавление при клонировании)
    fun addBookingClasses(
        cityId: String,
        groupId: String,
        newClasses: List<BookingClass>,
        onComplete: (Boolean) -> Unit = {}
    ) {
        val current = _state.value
        val coach = current.coachData ?: return
        val city = coach.cities.find { it.id == cityId } ?: return
        val group = city.groups.find { it.id == groupId } ?: return
        
        val newBookings = group.bookings.filter { old -> newClasses.none { it.id == old.id } }.toMutableList()
        newBookings.addAll(newClasses)
        val sortedBookings = newBookings.sortedWith(compareBy({ it.date }, { it.time }))
        
        val updatedCities = coach.cities.map { c ->
            if (c.id == cityId) {
                val updatedGroups = c.groups.map { g ->
                    if (g.id == groupId) {
                        g.copy(bookings = sortedBookings)
                    } else g
                }
                c.copy(groups = updatedGroups)
            } else c
        }
        saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
        
        viewModelScope.launch(ioDispatcher) {
            val success = SyncManager.pushBookings(coach.coachId, groupId, sortedBookings)
            withContext(mainDispatcher) {
                onComplete(success)
            }
        }
    }

    // Удаление занятия с записью (тренер)
    fun deleteBookingClass(
        cityId: String,
        groupId: String,
        bookingId: String,
        onComplete: (Boolean) -> Unit = {}
    ) {
        val current = _state.value
        val coach = current.coachData ?: return
        val city = coach.cities.find { it.id == cityId } ?: return
        val group = city.groups.find { it.id == groupId } ?: return
        
        val sortedBookings = group.bookings.filter { it.id != bookingId }
        
        val updatedCities = coach.cities.map { c ->
            if (c.id == cityId) {
                val updatedGroups = c.groups.map { g ->
                    if (g.id == groupId) {
                        g.copy(bookings = sortedBookings)
                    } else g
                }
                c.copy(groups = updatedGroups)
            } else c
        }
        saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
        
        viewModelScope.launch(ioDispatcher) {
            val success = SyncManager.pushBookings(coach.coachId, groupId, sortedBookings)
            withContext(mainDispatcher) {
                onComplete(success)
            }
        }
    }

    // Загрузка занятий с записью для ученика
    fun pullBookingsForStudent(onComplete: (Boolean) -> Unit = {}) {
        val config = _state.value.studentConfig ?: return
        viewModelScope.launch(ioDispatcher) {
            val bookings = SyncManager.pullBookings(config.coachId, config.groupId)
            if (bookings != null) {
                withContext(mainDispatcher) {
                    saveState(_state.value.copy(studentConfig = config.copy(bookings = bookings)))
                    onComplete(true)
                }
            } else {
                withContext(mainDispatcher) {
                    onComplete(false)
                }
            }
        }
    }

    // Запись / Отмена записи для ученика (вызывается из кабинета ученика или тренером)
    fun toggleStudentBooking(
        coachId: String,
        groupId: String,
        bookingId: String,
        studentId: String,
        register: Boolean,
        onComplete: (Boolean) -> Unit = {}
    ) {
        viewModelScope.launch(ioDispatcher) {
            val currentBookings = SyncManager.pullBookings(coachId, groupId) ?: emptyList()
            val updated = currentBookings.map { booking ->
                if (booking.id == bookingId) {
                    val list = booking.attendees.toMutableList()
                    if (register) {
                        if (!list.contains(studentId) && list.size < booking.maxCapacity) {
                            list.add(studentId)
                        }
                    } else {
                        list.remove(studentId)
                    }
                    booking.copy(attendees = list)
                } else {
                    booking
                }
            }
            val success = SyncManager.pushBookings(coachId, groupId, updated)
            if (success) {
                withContext(mainDispatcher) {
                    val current = _state.value
                    if (current.role == AppRole.COACH && current.coachData != null) {
                        val coach = current.coachData
                        val updatedCities = coach.cities.map { c ->
                            val updatedGroups = c.groups.map { g ->
                                if (g.id == groupId) {
                                    g.copy(bookings = updated)
                                } else g
                            }
                            c.copy(groups = updatedGroups)
                        }
                        saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
                    } else if (current.role == AppRole.STUDENT && current.studentConfig != null) {
                        val config = current.studentConfig
                        if (config.groupId == groupId) {
                            saveState(current.copy(studentConfig = config.copy(bookings = updated)))
                        }
                    }
                    onComplete(true)
                }
            } else {
                withContext(mainDispatcher) {
                    onComplete(false)
                }
            }
        }
    }


    // Отметка платежа учеником (перевод в PENDING_APPROVAL - ожидает подтверждения)
    fun studentMarkAsPaid(paymentId: String, onComplete: (Boolean) -> Unit = {}) {
        val config = _state.value.studentConfig
        if (config == null) {
            onComplete(false)
            return
        }
        val studentId = config.studentId
        if (studentId == null) {
            onComplete(false)
            return
        }
        val updatedPayments = config.payments.map { payment ->
            if (payment.id == paymentId) {
                payment.copy(state = PaymentState.PENDING_APPROVAL)
            } else {
                payment
            }
        }
        val current = _state.value
        saveState(current.copy(studentConfig = config.copy(payments = updatedPayments)))
        
        viewModelScope.launch(ioDispatcher) {
            val success = SyncManager.pushPayments(config.coachId, studentId, updatedPayments)
            withContext(mainDispatcher) {
                onComplete(success)
            }
        }
    }

    // Синхронизация платежей группы с облаком тренером с поддержкой двусторонней оффлайн-сверки
    fun syncGroupPaymentsFromCloud(cityId: String, groupId: String, onComplete: () -> Unit = {}) {
        val current = _state.value
        val coach = current.coachData
        if (coach == null) {
            onComplete()
            return
        }
        val city = coach.cities.find { it.id == cityId }
        if (city == null) {
            onComplete()
            return
        }
        val group = city.groups.find { it.id == groupId }
        if (group == null) {
            onComplete()
            return
        }

        viewModelScope.launch(ioDispatcher) {
            var anyChanged = false
            val updatedStudents = group.students.map { student ->
                val cloudPayments = SyncManager.pullPayments(coach.coachId, student.id)
                val profile = SyncManager.pullProfile(coach.coachId, student.id)
                
                var studentUpdated = student
                if (profile != null) {
                    val mergedBirthDate = if (profile.birthDate.isNotEmpty()) profile.birthDate else student.birthDate
                    val mergedHeight = if (profile.height.isNotEmpty()) profile.height else student.height
                    val mergedWeight = if (profile.weight.isNotEmpty()) profile.weight else student.weight
                    val mergedPhone = if (profile.phone.isNotEmpty()) profile.phone else student.phone

                    if (mergedBirthDate != student.birthDate || 
                        mergedHeight != student.height || 
                        mergedWeight != student.weight ||
                        mergedPhone != student.phone
                    ) {
                        anyChanged = true
                        studentUpdated = student.copy(
                            birthDate = mergedBirthDate,
                            height = mergedHeight,
                            weight = mergedWeight,
                            phone = mergedPhone
                        )
                    }
                }

                if (cloudPayments != null) {
                    var studentNeedsPush = false
                    val mergedPayments = studentUpdated.payments.map { local ->
                        val cloud = cloudPayments.find { it.id == local.id }
                        if (cloud == null) {
                            // Платежа нет в облаке — создали оффлайн, надо отправить
                            studentNeedsPush = true
                            local
                        } else if (local.state == PaymentState.PAID && cloud.state != PaymentState.PAID) {
                            // Тренер оффлайн подтвердил платеж — отправляем в облако
                            studentNeedsPush = true
                            local
                        } else if (local.state == PaymentState.UNPAID && cloud.state == PaymentState.PENDING_APPROVAL) {
                            // Ученик отметил как оплаченный — обновляем локальный статус
                            anyChanged = true
                            local.copy(state = PaymentState.PENDING_APPROVAL)
                        } else if (cloud.state == PaymentState.PAID && local.state != PaymentState.PAID) {
                            // Оплачено в облаке (например, с другого устройства тренера) — обновляем локально
                            anyChanged = true
                            local.copy(state = PaymentState.PAID, confirmedAt = cloud.confirmedAt)
                        } else if (local.state == PaymentState.UNPAID && cloud.state == PaymentState.PENDING_APPROVAL) {
                            // Локально тренер сбросил подтверждение оффлайн — отправляем в облако
                            studentNeedsPush = true
                            local
                        } else {
                            local
                        }
                    }

                    // Также переносим в локальную БД новые платежи из облака, если они там есть (созданные с другого устройства)
                    val allMerged = mergedPayments.toMutableList()
                    cloudPayments.forEach { cloud ->
                        if (allMerged.none { it.id == cloud.id }) {
                            allMerged.add(cloud)
                            anyChanged = true
                        }
                    }

                    if (studentNeedsPush) {
                        SyncManager.pushPayments(coach.coachId, student.id, allMerged)
                    }
                    
                    studentUpdated.copy(payments = allMerged)
                } else {
                    studentUpdated
                }
            }

            if (anyChanged) {
                val updatedCities = coach.cities.map { c ->
                    if (c.id == cityId) {
                        val updatedGroups = c.groups.map { g ->
                            if (g.id == groupId) g.copy(students = updatedStudents) else g
                        }
                        c.copy(groups = updatedGroups)
                    } else {
                        c
                    }
                }
                saveState(current.copy(coachData = coach.copy(cities = updatedCities)))
            }
            withContext(Dispatchers.Main) {
                onComplete()
            }
        }
    }

    fun completeGoogleSignIn(
        googleIdToken: String,
        googleEmail: String,
        onComplete: (Boolean, String?) -> Unit
    ) {
        val current = _state.value
        val apiKey = current.firebaseApiKey
        if (apiKey.isEmpty()) {
            onComplete(false, "Firebase API Key не задан в настройках")
            return
        }
        
        viewModelScope.launch(ioDispatcher) {
            val resp = SyncManager.signInWithFirebaseOAuth(apiKey, googleIdToken)
            if (resp != null) {
                val expiryTime = System.currentTimeMillis() + (resp.expiresIn.toLongOrNull() ?: 3600L) * 1000
                val uid = resp.localId
                
                // Временно устанавливаем токен, чтобы последующие запросы к БД шли с ним
                SyncManager.currentAuthToken = resp.idToken

                // Запрашиваем профиль пользователя
                var profile = SyncManager.getUserProfile(uid)
                if (profile == null) {
                    // Первый вход: создаем профиль со статусом UNDEFINED
                    profile = UserProfile(uid = uid, email = googleEmail, role = "UNDEFINED")
                    SyncManager.saveUserProfile(uid, profile)
                }

                // В зависимости от роли в профиле настраиваем локальный AppState
                val role = when (profile.role) {
                    "COACH" -> AppRole.COACH
                    "STUDENT" -> AppRole.STUDENT
                    else -> AppRole.UNDEFINED
                }

                var coachData = current.coachData
                var studentConfig = current.studentConfig

                if (role == AppRole.COACH) {
                    val cloudCoachData = SyncManager.pullCoachData(uid)
                    if (cloudCoachData != null) {
                        coachData = cloudCoachData
                    } else {
                        val currentCoach = coachData ?: CoachData(coachId = uid)
                        if (currentCoach.cities.isEmpty()) {
                            val defaultCoach = CoachData(
                                coachId = uid,
                                cities = listOf(
                                    City(
                                        name = "Мытищи",
                                        groups = listOf(
                                            StudentGroup(
                                                name = "Основная группа",
                                                defaultMonthlyFee = 3000.0,
                                                students = listOf(
                                                    Student(
                                                        firstName = "Марк",
                                                        lastName = "Скрипник",
                                                        monthlyFee = 3000.0,
                                                        joinMonth = "2026-05"
                                                    ),
                                                    Student(
                                                        firstName = "Брюс",
                                                        lastName = "Ли",
                                                        monthlyFee = 3000.0,
                                                        joinMonth = "2026-03"
                                                    )
                                                )
                                            )
                                        )
                                    )
                                )
                            )
                            coachData = defaultCoach
                            SyncManager.pushCoachData(uid, defaultCoach)
                        } else {
                            coachData = currentCoach.copy(coachId = uid)
                            SyncManager.pushCoachData(uid, coachData)
                        }
                    }
                } else if (role == AppRole.STUDENT) {
                    if (profile.coachId.isNotEmpty() && profile.studentId.isNotEmpty()) {
                        // Подтягиваем данные ученика из облака, если они уже привязаны
                        val cloudPayments = SyncManager.pullPayments(profile.coachId, profile.studentId) ?: emptyList()
                        val cloudProfile = SyncManager.pullProfile(profile.coachId, profile.studentId)
                        val cloudSchedule = if (profile.groupId.isNotEmpty()) {
                            SyncManager.pullSchedule(profile.coachId, profile.groupId)
                        } else null
                        
                        val nameParts = profile.studentName.split(" ")
                        val lastName = nameParts.getOrNull(0) ?: ""
                        val firstName = nameParts.getOrNull(1) ?: ""

                        studentConfig = StudentConfig(
                            coachId = profile.coachId,
                            cityId = profile.cityId,
                            cityName = profile.cityName,
                            groupId = profile.groupId,
                            groupName = profile.groupName,
                            studentId = profile.studentId,
                            firstName = firstName,
                            lastName = lastName,
                            payments = cloudPayments,
                            phone = cloudProfile?.phone ?: "",
                            birthDate = cloudProfile?.birthDate ?: "",
                            height = cloudProfile?.height ?: "",
                            weight = cloudProfile?.weight ?: "",
                            weeklySchedule = cloudSchedule?.weeklySchedule ?: emptyList(),
                            oneOffEvents = cloudSchedule?.oneOffEvents ?: emptyList()
                        )
                    } else {
                        // Роль STUDENT, но привязки еще нет
                        studentConfig = studentConfig ?: StudentConfig()
                    }
                }

                val updatedState = current.copy(
                    role = role,
                    coachData = coachData,
                    studentConfig = studentConfig,
                    firebaseToken = resp.idToken,
                    refreshToken = resp.refreshToken,
                    tokenExpiryTime = expiryTime,
                    googleEmail = googleEmail,
                    firebaseUid = uid
                )

                withContext(mainDispatcher) {
                    saveState(updatedState)
                    onComplete(true, null)
                }
            } else {
                withContext(mainDispatcher) {
                    onComplete(false, "Ошибка авторизации в Firebase")
                }
            }
        }
    }

    
    fun signOutGoogle() {
        val current = _state.value
        val updatedState = current.copy(
            firebaseToken = "",
            refreshToken = "",
            tokenExpiryTime = 0L,
            googleEmail = "",
            firebaseUid = ""
        )
        saveState(updatedState)
    }

    fun updateCloudSettings(apiKey: String, clientId: String) {
        val current = _state.value
        saveState(current.copy(
            firebaseApiKey = apiKey.trim(),
            googleClientId = clientId.trim()
        ))
    }

    fun restoreFromBackup(onComplete: (Boolean) -> Unit) {
        viewModelScope.launch(ioDispatcher) {
            val restoredState = storageManager.restoreBackup()
            if (restoredState != null) {
                SyncManager.currentAuthToken = restoredState.firebaseToken.ifEmpty { null }
                withContext(mainDispatcher) {
                    _state.value = restoredState
                    onComplete(true)
                }
                // Также сразу выгружаем восстановленное состояние в облако, если это роль тренера с UID
                if (restoredState.role == AppRole.COACH && restoredState.firebaseUid.isNotEmpty() && restoredState.coachData != null) {
                    try {
                        SyncManager.pushCoachData(restoredState.firebaseUid, restoredState.coachData)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            } else {
                withContext(mainDispatcher) {
                    onComplete(false)
                }
            }
        }
    }

    private fun normalizeState(state: AppState): AppState {
        val coachData = state.coachData ?: return state
        var changed = false
        val normalizedCities = coachData.cities.map { city ->
            var cityChanged = false
            val normalizedGroups = city.groups.map { group ->
                var groupChanged = false
                val normalizedStudents = group.students.map { student ->
                    if (student.joinMonth.isNotEmpty()) {
                        val invalidPayments = student.payments.filter { 
                            it.title == "Абонемент" && it.month.isNotEmpty() && it.month < student.joinMonth 
                        }
                        if (invalidPayments.isNotEmpty()) {
                            groupChanged = true
                            student.copy(payments = student.payments.filterNot { it in invalidPayments })
                        } else {
                            student
                        }
                    } else {
                        student
                    }
                }
                if (groupChanged) {
                    cityChanged = true
                    group.copy(students = normalizedStudents)
                } else {
                    group
                }
            }
            if (cityChanged) {
                changed = true
                city.copy(groups = normalizedGroups)
            } else {
                city
            }
        }
        return if (changed) {
            state.copy(coachData = coachData.copy(cities = normalizedCities))
        } else {
            state
        }
    }

    fun cleanPhoneNumber(phone: String): String {
        val digits = phone.filter { it.isDigit() }
        if (digits.length == 11 && digits.startsWith("8")) {
            return "7" + digits.substring(1)
        }
        return digits
    }

    private fun pushPhoneLinkIfAny(
        phone: String,
        coachId: String,
        cityId: String,
        cityName: String,
        groupId: String,
        groupName: String,
        studentId: String,
        studentName: String
    ) {
        val cleaned = cleanPhoneNumber(phone)
        if (cleaned.isNotEmpty()) {
            viewModelScope.launch(ioDispatcher) {
                SyncManager.createPhoneLink(cleaned, coachId, cityId, cityName, groupId, groupName, studentId, studentName)
            }
        }
    }

    private fun deletePhoneLinkIfAny(phone: String) {
        val cleaned = cleanPhoneNumber(phone)
        if (cleaned.isNotEmpty()) {
            viewModelScope.launch(ioDispatcher) {
                SyncManager.deletePhoneLink(cleaned)
            }
        }
    }

    // Генерация группового инвайт-кода
    fun generateGroupInviteCode(
        cityId: String,
        groupId: String,
        onComplete: (String) -> Unit
    ) {
        val coach = _state.value.coachData
        if (coach == null) {
            return
        }
        val city = coach.cities.find { it.id == cityId }
        val group = city?.groups?.find { it.id == groupId }
        val cityName = city?.name ?: ""
        val groupName = group?.name ?: ""
        
        val code = (100000 + kotlin.math.abs(groupId.hashCode() % 900000)).toString()
        
        onComplete(code)
        
        viewModelScope.launch(ioDispatcher) {
            SyncManager.createInvite(
                inviteCode = code,
                coachId = coach.coachId,
                cityId = cityId,
                cityName = cityName,
                groupId = groupId,
                groupName = groupName,
                studentId = "",
                studentName = ""
            )
        }
    }

    // Проверка инвайт-кода или телефона
    fun checkInviteCode(codeOrPhone: String, onComplete: (InviteInfo?, String?) -> Unit) {
        viewModelScope.launch(ioDispatcher) {
            val cleanedInput = codeOrPhone.filter { it.isDigit() }
            var info: InviteInfo? = null
            
            if (cleanedInput.length == 6) {
                info = SyncManager.getInvite(cleanedInput)
            }
            
            if (info == null) {
                val cleanedPhone = cleanPhoneNumber(codeOrPhone)
                if (cleanedPhone.isNotEmpty()) {
                    info = SyncManager.getPhoneLink(cleanedPhone)
                }
            }
            
            withContext(mainDispatcher) {
                if (info != null) {
                    onComplete(info, null)
                } else {
                    onComplete(null, "Неверный код или номер телефона")
                }
            }
        }
    }

    // Привязка выбранного ученика к родителю
    fun linkStudentToParent(
        coachId: String,
        cityId: String,
        cityName: String,
        groupId: String,
        groupName: String,
        studentId: String,
        studentName: String,
        inviteCode: String,
        onComplete: (Boolean) -> Unit
    ) {
        viewModelScope.launch(ioDispatcher) {
            val payments = SyncManager.pullPayments(coachId, studentId) ?: emptyList()
            val profile = SyncManager.pullProfile(coachId, studentId)
            val schedule = SyncManager.pullSchedule(coachId, groupId)
            val nameParts = studentName.split(" ")
            val lastName = nameParts.getOrNull(0) ?: ""
            val firstName = nameParts.getOrNull(1) ?: ""
            
            val newConfig = StudentConfig(
                coachId = coachId,
                cityName = cityName,
                groupName = groupName,
                firstName = firstName,
                lastName = lastName,
                studentId = studentId,
                payments = payments,
                inviteCode = inviteCode,
                phone = profile?.phone ?: "",
                birthDate = profile?.birthDate ?: "",
                height = profile?.height ?: "",
                weight = profile?.weight ?: "",
                cityId = cityId,
                groupId = groupId,
                weeklySchedule = schedule?.weeklySchedule ?: emptyList(),
                oneOffEvents = schedule?.oneOffEvents ?: emptyList()
            )
            
            val curState = _state.value
            if (curState.firebaseUid.isNotEmpty()) {
                val userProfile = UserProfile(
                    uid = curState.firebaseUid,
                    email = curState.googleEmail,
                    role = "STUDENT",
                    coachId = coachId,
                    cityId = cityId,
                    cityName = cityName,
                    groupId = groupId,
                    groupName = groupName,
                    studentId = studentId,
                    studentName = studentName
                )
                SyncManager.saveUserProfile(curState.firebaseUid, userProfile)
            }
            withContext(mainDispatcher) {
                saveState(_state.value.copy(role = AppRole.STUDENT, studentConfig = newConfig))
                onComplete(true)
            }
        }
    }

    // Загрузка учеников группы
    fun fetchGroupStudents(coachId: String, cityId: String, groupId: String, onComplete: (List<Student>) -> Unit) {
        viewModelScope.launch(ioDispatcher) {
            val cloudCoachData = SyncManager.pullCoachData(coachId)
            val students = cloudCoachData?.cities?.find { it.id == cityId }
                ?.groups?.find { it.id == groupId }
                ?.students ?: emptyList()
            withContext(mainDispatcher) {
                onComplete(students)
            }
        }
    }

    // Добавление нового ученика родителем и автоматический пуш в облако тренера
    fun addNewStudentFromParent(
        coachId: String,
        cityId: String,
        groupId: String,
        firstName: String,
        lastName: String,
        onComplete: (Boolean, Student?) -> Unit
    ) {
        viewModelScope.launch(ioDispatcher) {
            val cloudCoachData = SyncManager.pullCoachData(coachId)
            if (cloudCoachData == null) {
                withContext(mainDispatcher) { onComplete(false, null) }
                return@launch
            }
            
            var newStudent: Student? = null
            val updatedCities = cloudCoachData.cities.map { city ->
                if (city.id == cityId) {
                    val updatedGroups = city.groups.map { group ->
                        if (group.id == groupId) {
                            val generatedId = "student_${System.currentTimeMillis()}"
                            val student = Student(
                                id = generatedId,
                                firstName = firstName,
                                lastName = lastName,
                                monthlyFee = group.defaultMonthlyFee,
                                joinMonth = java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.US).format(java.util.Date())
                            )
                            newStudent = student
                            group.copy(students = group.students + student)
                        } else {
                            group
                        }
                    }
                    city.copy(groups = updatedGroups)
                } else {
                    city
                }
            }
            
            val finalStudent = newStudent
            if (finalStudent != null) {
                val updatedCoachData = cloudCoachData.copy(cities = updatedCities)
                val success = SyncManager.pushCoachData(coachId, updatedCoachData)
                if (success) {
                    withContext(mainDispatcher) {
                        onComplete(true, finalStudent)
                    }
                } else {
                    withContext(mainDispatcher) {
                        onComplete(false, null)
                    }
                }
            } else {
                withContext(mainDispatcher) {
                    onComplete(false, null)
                }
            }
        }
    }

    // Синхронизация coachData + платежей группы для тренера
    fun syncCoachDataAndGroup(cityId: String, groupId: String, onComplete: (success: Boolean, errorMsg: String?) -> Unit = { _, _ -> }) {
        viewModelScope.launch(ioDispatcher) {
            val coachId = _state.value.firebaseUid.ifEmpty { "default_coach_owner" }
            val cloudCoachData = SyncManager.pullCoachData(coachId)
            val pullError = SyncManager.lastError
            if (pullError != null) {
                withContext(mainDispatcher) {
                    onComplete(false, pullError)
                }
                return@launch
            }
            if (cloudCoachData != null) {
                withContext(mainDispatcher) {
                    val current = _state.value
                    val merged = current.copy(coachData = cloudCoachData)
                    saveState(merged)
                }
            }
            syncGroupPaymentsFromCloud(cityId, groupId) {
                val finalError = SyncManager.lastError
                onComplete(finalError == null, finalError)
            }
        }
    }
}
