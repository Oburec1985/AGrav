package ru.oburec.coachpay.ui.components

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.oburec.coachpay.model.PaymentState
import ru.oburec.coachpay.model.Student
import ru.oburec.coachpay.ui.utils.MonthUtils
import ru.oburec.coachpay.ui.utils.StudentPaymentStatus

/**
 * Разворачиваемая карточка ученика, содержащая личные данные, статус оплаты,
 * интерактивный календарь платежей и панель действий.
 */
@Composable
fun ExpandableStudentPaymentCard(
    student: Student,
    isExpanded: Boolean,
    paymentStatus: StudentPaymentStatus,
    currentRealMonth: String,
    onCardClick: () -> Unit,
    onApproveAllPending: () -> Unit,
    onTogglePayment: (String, String) -> Unit,
    onChangeFeeClick: () -> Unit,
    onAddCustomPaymentClick: () -> Unit,
    onEditStudentClick: () -> Unit,
    onDeleteStudentClick: () -> Unit,
    onLinkDeviceClick: () -> Unit
) {
    // Выбор цвета фона карточки в зависимости от финансового статуса ученика
    val cardBgColor = when (paymentStatus.state) {
        PaymentState.PAID -> Color(0xFF064E3B) // Приглушенный темно-зеленый
        PaymentState.PENDING_APPROVAL -> Color(0xFF78350F) // Приглушенный темно-оранжевый
        PaymentState.UNPAID -> Color(0xFF5C1D24) // Приглушенный темно-красный
    }
    
    // Выбор цвета границы карточки
    val cardBorderColor = when (paymentStatus.state) {
        PaymentState.PAID -> Color(0xFF10B981).copy(alpha = 0.4f)
        PaymentState.PENDING_APPROVAL -> Color(0xFFF59E0B).copy(alpha = 0.6f)
        PaymentState.UNPAID -> Color(0xFFF43F5E).copy(alpha = 0.4f)
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cardBgColor),
        border = BorderStroke(1.dp, cardBorderColor),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCardClick() }
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .animateContentSize()
        ) {
            // Заголовок карточки: ФИО ученика и статус (всегда виден)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${student.lastName} ${student.firstName}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    // Формирование текстового описания и иконки статуса
                    val statusText = when (paymentStatus.state) {
                        PaymentState.PAID -> "Всё оплачено"
                        PaymentState.PENDING_APPROVAL -> "Ожидает подтверждения (${paymentStatus.pendingCount})"
                        PaymentState.UNPAID -> "Долг: ${paymentStatus.unpaidAmount.toInt()} ₽ (${paymentStatus.unpaidCount} мес.)"
                    }
                    val statusIcon = when (paymentStatus.state) {
                        PaymentState.PAID -> Icons.Default.CheckCircle
                        PaymentState.PENDING_APPROVAL -> Icons.Default.Schedule
                        PaymentState.UNPAID -> Icons.Default.Warning
                    }
                    val statusColor = when (paymentStatus.state) {
                        PaymentState.PAID -> Color(0xFF34D399)
                        PaymentState.PENDING_APPROVAL -> Color(0xFFFBBF24)
                        PaymentState.UNPAID -> Color(0xFFF87171)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = statusIcon,
                            contentDescription = null,
                            tint = statusColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = statusText,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = statusColor
                        )
                    }
                }
                
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Кнопка быстрого подтверждения ожидающих оплат (только для статуса PENDING_APPROVAL)
                    if (paymentStatus.state == PaymentState.PENDING_APPROVAL) {
                        Button(
                            onClick = {
                                onApproveAllPending()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Подтвердить всё",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ОК", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    
                    // Иконка разворачивания карточки
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (isExpanded) "Свернуть" else "Развернуть",
                        tint = Color.LightGray
                    )
                }
            }

            // Дополнительная информация, если карточка свернута
            if (!isExpanded) {
                if (student.phone.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Тел: ${student.phone}",
                        fontSize = 12.sp,
                        color = Color.LightGray
                    )
                }
            }

            // Развернутое содержимое карточки
            if (isExpanded) {
                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
                Spacer(modifier = Modifier.height(12.dp))

                // Личные данные ученика (телефон, день рождения, рост, вес)
                if (student.birthDate.isNotEmpty() || student.height.isNotEmpty() || student.weight.isNotEmpty() || student.phone.isNotEmpty()) {
                    Text(
                        text = "Профиль ученика",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.LightGray
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (student.phone.isNotEmpty()) {
                            Text(text = "Телефон: ${student.phone}", fontSize = 13.sp, color = Color.White)
                        }
                        if (student.birthDate.isNotEmpty()) {
                            Text(text = "День рождения: ${student.birthDate}", fontSize = 13.sp, color = Color.White)
                        }
                        if (student.height.isNotEmpty() || student.weight.isNotEmpty()) {
                            val stats = buildString {
                                if (student.height.isNotEmpty()) append("Рост: ${student.height} см")
                                if (student.weight.isNotEmpty()) {
                                    if (isNotEmpty()) append("  •  ")
                                    append("Вес: ${student.weight} кг")
                                }
                            }
                            Text(text = stats, fontSize = 13.sp, color = Color.White)
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Тариф базового абонемента
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onChangeFeeClick() }
                ) {
                    Text(
                        text = "Базовый абонемент: ${student.monthlyFee.toInt()} ₽/мес",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Изменить тариф",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(14.dp)
                    )
                }
                
                val isRecentPayment = remember {
                    { payment: ru.oburec.coachpay.model.Payment ->
                        val confirmedTime = payment.confirmedAt
                        confirmedTime != null && (System.currentTimeMillis() - confirmedTime) < 24 * 60 * 60 * 1000L
                    }
                }

                val archivedPayments = remember(student.payments) {
                    student.payments.filter { it.state == PaymentState.PAID && !isRecentPayment(it) }
                }

                var selectedSubTab by remember { mutableStateOf(0) }

                Spacer(modifier = Modifier.height(16.dp))
                TabRow(
                    selectedTabIndex = selectedSubTab,
                    containerColor = Color.Transparent,
                    contentColor = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Tab(
                        selected = selectedSubTab == 0,
                        onClick = { selectedSubTab = 0 },
                        text = { Text("Начисления", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White) }
                    )
                    Tab(
                        selected = selectedSubTab == 1,
                        onClick = { selectedSubTab = 1 },
                        text = { Text("Архив оплат (${archivedPayments.size})", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White) }
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))

                if (selectedSubTab == 0) {
                    // НАЧИСЛЕНИЯ (Только неоплаченные, ожидающие подтверждения или оплаченные за сегодня)
                    Text(
                        text = "Календарь оплат (Абонементы)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Генерация месяцев с момента вступления по текущий месяц
                    val startMonth = student.joinMonth.ifEmpty { currentRealMonth }
                    val monthsList = remember(startMonth, currentRealMonth) {
                        val list = mutableListOf<String>()
                        var temp = startMonth
                        val limit = currentRealMonth
                        while (temp <= limit) {
                            list.add(temp)
                            temp = MonthUtils.adjustMonth(temp, 1)
                        }
                        list
                    }

                    val monthsListFiltered = remember(monthsList, student.payments) {
                        monthsList.filter { m ->
                            val subPayment = student.payments.find { it.month == m && it.title == "Абонемент" }
                            subPayment == null || subPayment.state != PaymentState.PAID || isRecentPayment(subPayment)
                        }
                    }

                    if (monthsListFiltered.isEmpty()) {
                        Text("Нет активных абонементных начислений.", fontSize = 13.sp, color = Color.LightGray, modifier = Modifier.padding(vertical = 8.dp))
                    } else {
                        // Таблица/сетка месяцев
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            monthsListFiltered.chunked(2).forEach { rowMonths ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    rowMonths.forEach { m ->
                                        val subPayment = student.payments.find { it.month == m && it.title == "Абонемент" }
                                        val pState = subPayment?.state ?: PaymentState.UNPAID
                                        
                                        val btnBg = when (pState) {
                                            PaymentState.PAID -> Color(0xFF1B4332)
                                            PaymentState.PENDING_APPROVAL -> Color(0xFF78350F)
                                            PaymentState.UNPAID -> Color(0xFF450A0A)
                                        }
                                        val btnBorder = when (pState) {
                                            PaymentState.PAID -> Color(0xFF40916C)
                                            PaymentState.PENDING_APPROVAL -> Color(0xFFD97706)
                                            PaymentState.UNPAID -> Color(0xFF991B1B)
                                        }
                                        val btnText = when (pState) {
                                            PaymentState.PAID -> "Оплачено"
                                            PaymentState.PENDING_APPROVAL -> "Подтвердить"
                                            PaymentState.UNPAID -> "Не оплачен"
                                        }
                                        
                                        Card(
                                            shape = RoundedCornerShape(8.dp),
                                            colors = CardDefaults.cardColors(containerColor = btnBg),
                                            border = BorderStroke(1.dp, btnBorder),
                                            modifier = Modifier
                                                .weight(1f)
                                                .clickable {
                                                    if (subPayment != null) {
                                                        onTogglePayment(subPayment.id, m)
                                                    }
                                                }
                                                .padding(vertical = 4.dp)
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(8.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally
                                            ) {
                                                Text(
                                                    text = MonthUtils.formatMonthDisplay(m),
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White,
                                                    textAlign = TextAlign.Center
                                                )
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = btnText,
                                                    fontSize = 11.sp,
                                                    color = when (pState) {
                                                        PaymentState.PAID -> Color(0xFF52B788)
                                                        PaymentState.PENDING_APPROVAL -> Color(0xFFFBBF24)
                                                        PaymentState.UNPAID -> Color(0xFFFCA5A5)
                                                    },
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                    if (rowMonths.size == 1) {
                                        Spacer(modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }

                    // Разовые/целевые платежи (только активные)
                    val customPaymentsFiltered = remember(student.payments) {
                        student.payments.filter { it.title != "Абонемент" && (it.state != PaymentState.PAID || isRecentPayment(it)) }
                    }
                    if (customPaymentsFiltered.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Разовые платежи",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            customPaymentsFiltered.forEach { cp ->
                                val cpPaid = cp.state == PaymentState.PAID
                                val cpPending = cp.state == PaymentState.PENDING_APPROVAL
                                val cpColor = when {
                                    cpPaid -> Color(0xFF1B4332)
                                    cpPending -> Color(0xFF78350F)
                                    else -> Color(0xFF450A0A)
                                }
                                val cpBorder = when {
                                    cpPaid -> Color(0xFF40916C)
                                    cpPending -> Color(0xFFD97706)
                                    else -> Color(0xFF991B1B)
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(cpColor, shape = RoundedCornerShape(8.dp))
                                        .border(1.dp, cpBorder, RoundedCornerShape(8.dp))
                                        .clickable { onTogglePayment(cp.id, cp.month) }
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(text = cp.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                        Text(
                                            text = "${cp.amount.toInt()} ₽" + if (cp.month.isNotEmpty()) " (${MonthUtils.formatMonthShort(cp.month)})" else "",
                                            fontSize = 11.sp,
                                            color = Color.LightGray
                                        )
                                    }
                                    Text(
                                        text = when {
                                            cpPaid -> "Оплачено"
                                            cpPending -> "Проверить"
                                            else -> "Долг"
                                        },
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = when {
                                            cpPaid -> Color(0xFF52B788)
                                            cpPending -> Color(0xFFFBBF24)
                                            else -> Color(0xFFFCA5A5)
                                        }
                                    )
                                }
                            }
                        }
                    }
                } else {
                    // АРХИВ ОПЛАТ (Оплаченные ранее платежи)
                    if (archivedPayments.isEmpty()) {
                        Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                            Text("Архив пуст", color = Color.LightGray, fontSize = 14.sp)
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            archivedPayments.forEach { cp ->
                                val displayTitle = if (cp.title == "Абонемент") {
                                    "Абонемент за ${MonthUtils.formatMonthDisplay(cp.month)}"
                                } else {
                                    cp.title + if (cp.month.isNotEmpty()) " (${MonthUtils.formatMonthShort(cp.month)})" else ""
                                }
                                
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF1E293B).copy(alpha = 0.5f), shape = RoundedCornerShape(8.dp))
                                        .border(1.dp, Color(0xFF475569), RoundedCornerShape(8.dp))
                                        .clickable { onTogglePayment(cp.id, cp.month) }
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(text = displayTitle, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                        Text(text = "${cp.amount.toInt()} ₽", fontSize = 11.sp, color = Color.LightGray)
                                    }
                                    Text(
                                        text = "Оплачено (в архиве)",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF10B981)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
                Spacer(modifier = Modifier.height(8.dp))

                // Нижняя панель действий ученика
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onAddCustomPaymentClick) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(imageVector = Icons.Default.AddCard, contentDescription = "Добавить платеж", tint = Color.White)
                            Text("Платеж", fontSize = 9.sp, color = Color.LightGray)
                        }
                    }
                    IconButton(onClick = onLinkDeviceClick) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(imageVector = Icons.Default.QrCode, contentDescription = "Связать устройство", tint = Color.White)
                            Text("QR Связь", fontSize = 9.sp, color = Color.LightGray)
                        }
                    }
                    IconButton(onClick = onEditStudentClick) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(imageVector = Icons.Default.EditNote, contentDescription = "Редактировать профиль", tint = Color.White)
                            Text("Профиль", fontSize = 9.sp, color = Color.LightGray)
                        }
                    }
                    IconButton(onClick = onDeleteStudentClick) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Удалить ученика", tint = Color.Red)
                            Text("Удалить", fontSize = 9.sp, color = Color.Red)
                        }
                    }
                }
            }
        }
    }
}
