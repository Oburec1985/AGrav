package ru.oburec.coachpay.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ru.oburec.coachpay.ui.components.EmptyStatePlaceholder
import ru.oburec.coachpay.ui.components.ItemCard
import ru.oburec.coachpay.viewmodel.AppStateViewModel

/**
 * Экран списка тренировочных групп в рамках конкретного города.
 */
@Composable
fun GroupsScreen(
    cityId: String,
    cityName: String,
    viewModel: AppStateViewModel,
    onGroupSelected: (groupId: String, groupName: String) -> Unit,
    onEditGroupClick: (groupId: String, groupName: String, currentFee: Double) -> Unit
) {
    val state by viewModel.state.collectAsState()
    val city = state.coachData?.cities?.find { it.id == cityId }
    val groups = city?.groups ?: emptyList()
    val actualCityName = city?.name ?: cityName

    if (groups.isEmpty()) {
        EmptyStatePlaceholder("В г. $actualCityName нет групп.\nНажмите '+' чтобы добавить.")
    } else {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(groups) { group ->
                ItemCard(
                    title = group.name,
                    subtitle = "Учеников: ${group.students.size}",
                    onCardClick = {
                        onGroupSelected(group.id, group.name)
                    },
                    onEditClick = {
                        onEditGroupClick(group.id, group.name, group.defaultMonthlyFee)
                    },
                    onDeleteClick = {
                        viewModel.deleteGroup(cityId, group.id)
                    }
                )
            }
        }
    }
}
