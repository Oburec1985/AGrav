package ru.oburec.coachpay.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ru.oburec.coachpay.model.Student
import ru.oburec.coachpay.ui.components.EmptyStatePlaceholder
import ru.oburec.coachpay.ui.components.ExpandableStudentPaymentCard
import ru.oburec.coachpay.ui.components.ChangeFeeDialog
import ru.oburec.coachpay.ui.components.AddCustomPaymentDialog
import ru.oburec.coachpay.ui.components.EditStudentDialog
import ru.oburec.coachpay.ui.components.LinkCodeDialog
import ru.oburec.coachpay.ui.utils.MonthUtils
import ru.oburec.coachpay.ui.utils.PaymentStatusUtils
import ru.oburec.coachpay.viewmodel.AppStateViewModel
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Date

/**
 * StudentsScreen — основной экран управления учениками конкретной группы.
 * Он отображает список всех учеников группы в виде вертикального списка (LazyColumn) с карточками.
 *
 * Экран позволяет:
 * - Видеть статусы оплат учеников за текущий месяц (цветовая индикация: зеленый, желтый, красный).
 * - Разворачивать карточку ученика для отметки оплат в один тап.
 * - Вызывать диалоги изменения абонемента, добавления индивидуального начисления, редактирования или привязки аккаунта ученика.
 * - Автоматически генерировать ежемесячный абонентский платеж при первом открытии группы за новый месяц.
 *
 * @param cityId Идентификатор текущего города.
 * @param groupId Идентификатор текущей группы.
 * @param groupName Название текущей группы.
 * @param viewModel Модель представления [AppStateViewModel] для бизнес-логики и работы с данными.
 * @param selectedMonth Текущий выбранный месяц в шапке (календаре) в формате "YYYY-MM".
 */
@Composable
fun StudentsScreen(
    cityId: String,
    groupId: String,
    groupName: String,
    viewModel: AppStateViewModel,
    selectedMonth: String
) {
    // Подписываемся на изменения глобального состояния приложения
    val state by viewModel.state.collectAsState()
    
    // Ищем в состоянии город и группу по их идентификаторам
    val city = state.coachData?.cities?.find { it.id == cityId }
    val group = city?.groups?.find { it.id == groupId }
    val allStudents = group?.students ?: emptyList()
    val actualGroupName = group?.name ?: groupName

    // Вычисляем текущий реальный месяц для автогенерации платежей (в формате "YYYY-MM")
    val currentRealMonth = remember {
        SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
    }

    // Автоматическая генерация абонентских платежей за текущий месяц для всех учеников группы,
    // если они ещё не были сгенерированы. Запускается при открытии экрана.
    LaunchedEffect(cityId, groupId, allStudents.size) {
        viewModel.generateMonthlyPaymentsIfNeeded(cityId, groupId, currentRealMonth)
    }

    // Хранит ID ученика, карточка которого сейчас раскрыта (может быть раскрыта только одна карточка)
    var expandedStudentId by remember { mutableStateOf<String?>(null) }

    // Состояния для показа диалогов (хранят данные выбранного ученика, либо null, если диалог закрыт)
    var studentForFeeChange by remember { mutableStateOf<Student?>(null) }       // Диалог смены тарифа
    var studentForCustomPayment by remember { mutableStateOf<Student?>(null) }   // Диалог создания разового сбора
    var studentToEdit by remember { mutableStateOf<Student?>(null) }             // Диалог редактирования профиля
    var studentForLinkCode by remember { mutableStateOf<Student?>(null) }        // Диалог показа QR-кода привязки

    Column(modifier = Modifier.fillMaxSize()) {
        if (allStudents.isEmpty()) {
            // Если в группе нет учеников — показываем заглушку
            EmptyStatePlaceholder("В группе $actualGroupName нет учеников.\nНажмите '+' чтобы добавить.")
        } else {
            // Вертикальный прокручиваемый список карточек учеников
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(allStudents) { student ->
                    val isExpanded = expandedStudentId == student.id
                    
                    // Вычисляем статус оплат ученика (просрочки, переплаты) на основе текущего системного месяца
                    val paymentStatus = remember(student, currentRealMonth) {
                        PaymentStatusUtils.getStudentPaymentStatus(student, currentRealMonth)
                    }

                    // Компонент карточки ученика (ExpandableStudentPaymentCard)
                    ExpandableStudentPaymentCard(
                        student = student,
                        isExpanded = isExpanded,
                        paymentStatus = paymentStatus,
                        currentRealMonth = currentRealMonth,
                        onCardClick = {
                            // Клик по карточке разворачивает/сворачивает ее
                            expandedStudentId = if (isExpanded) null else student.id
                        },
                        onApproveAllPending = {
                            // Тренер подтверждает все присланные учеником оплаты
                            viewModel.approveAllPendingPayments(cityId, groupId, student.id)
                        },
                        onTogglePayment = { paymentId, month ->
                            // Переключение статуса конкретного платежа (Оплачено / Не оплачено) в один тап
                            viewModel.togglePaymentState(cityId, groupId, student.id, paymentId, month)
                        },
                        onChangeFeeClick = {
                            // Открытие диалога изменения размера абонемента
                            studentForFeeChange = student
                        },
                        onAddCustomPaymentClick = {
                            // Открытие диалога добавления разовой оплаты
                            studentForCustomPayment = student
                        },
                        onEditStudentClick = {
                            // Открытие диалога редактирования личных данных
                            studentToEdit = student
                        },
                        onDeleteStudentClick = {
                            // Удаление ученика из группы
                            viewModel.deleteStudent(cityId, groupId, student.id)
                        },
                        onLinkDeviceClick = {
                            // Генерация кода/QR для связывания телефона ученика (родителя)
                            studentForLinkCode = student
                        }
                    )
                }
            }
        }
    }

    // --- Отображение диалогов по условию (если стейт не равен null) ---

    // 1. Диалог изменения размера ежемесячного абонемента
    studentForFeeChange?.let { student ->
        ChangeFeeDialog(
            studentName = "${student.lastName} ${student.firstName}",
            currentFee = student.monthlyFee,
            onDismiss = { studentForFeeChange = null },
            onConfirm = { amount ->
                viewModel.changeMonthlyFee(cityId, groupId, student.id, amount)
                studentForFeeChange = null
            }
        )
    }

    // 2. Диалог добавления разового индивидуального платежа (например, форма или взнос)
    studentForCustomPayment?.let { student ->
        AddCustomPaymentDialog(
            studentName = "${student.lastName} ${student.firstName}",
            defaultMonth = selectedMonth,
            onDismiss = { studentForCustomPayment = null },
            onConfirm = { title, amount, parsedMonth ->
                viewModel.addCustomPayment(cityId, groupId, student.id, title, amount, parsedMonth)
                studentForCustomPayment = null
            }
        )
    }

    // 3. Диалог редактирования ученика (ФИО, дата начала, телефон)
    studentToEdit?.let { student ->
        EditStudentDialog(
            currentFirstName = student.firstName,
            currentLastName = student.lastName,
            currentJoinMonth = student.joinMonth,
            currentPhone = student.phone,
            defaultJoinMonth = selectedMonth,
            onDismiss = { studentToEdit = null },
            onConfirm = { firstName, lastName, joinMonth, phone ->
                viewModel.editStudent(cityId, groupId, student.id, firstName, lastName, joinMonth, phone)
                studentToEdit = null
            }
        )
    }

    // 4. Диалог QR-кода привязки устройства ученика (родителя)
    studentForLinkCode?.let { student ->
        // Генерируем временный инвайт-код на основе начала его UUID
        val linkCode = "CP-${student.id.take(6).uppercase()}"
        LinkCodeDialog(
            studentName = "${student.lastName} ${student.firstName}",
            linkCode = linkCode,
            onDismiss = { studentForLinkCode = null }
        )
    }
}
