package ru.oburec.coachpay.ui.components

import java.util.Locale

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.oburec.coachpay.data.QrCodeGenerator
import ru.oburec.coachpay.model.GroupEvent
import ru.oburec.coachpay.model.Student
import ru.oburec.coachpay.model.WeeklyClass
import ru.oburec.coachpay.ui.utils.MonthUtils
import ru.oburec.coachpay.viewmodel.AppStateViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ru.oburec.coachpay.data.SyncManager
import ru.oburec.coachpay.model.GroupSchedule

/**
 * Диалог настроек Firebase облака.
 */
@Composable
fun CloudSettingsDialog(
    currentApiKey: String,
    currentClientId: String,
    onSave: (String, String) -> Unit,
    onRestoreBackup: () -> Unit,
    onDismiss: () -> Unit
) {
    var apiKey by remember { mutableStateOf(currentApiKey) }
    var clientId by remember { mutableStateOf(currentClientId) }
    var showInstructions by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Настройки облака Firebase",
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Для интеграции с Google Auth и изоляции базы данных введите ключи вашего проекта Firebase:",
                    fontSize = 13.sp,
                    color = Color.Gray
                )

                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    label = { Text("Firebase Web API Key") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = Color.Gray
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = clientId,
                    onValueChange = { clientId = it },
                    label = { Text("Google Web Client ID") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = Color.Gray
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Button(
                    onClick = onRestoreBackup,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB45309)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Восстановить из резервной копии", color = Color.White)
                }

                Button(
                    onClick = { showInstructions = !showInstructions },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (showInstructions) "Скрыть инструкцию" else "Показать инструкцию")
                }

                if (showInstructions) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Как настроить проект в Firebase Console:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                            Text("1. Создайте проект на firebase.google.com.", fontSize = 11.sp, color = Color.LightGray)
                            Text("2. В разделе Authentication включите способ входа 'Google'.", fontSize = 11.sp, color = Color.LightGray)
                            Text("3. В настройках проекта (шестеренка -> Настройки проекта -> вкладка Общие) скопируйте 'Веб-API ключ' и вставьте в первое поле выше.", fontSize = 11.sp, color = Color.LightGray)
                            Text("4. В настройках способа входа Google разверните параметры и скопируйте 'Идентификатор веб-клиента' (Web Client ID) во второе поле.", fontSize = 11.sp, color = Color.LightGray)
                            Text("5. В разделе Realtime Database создайте БД и включите правила чтения/записи для безопасности.", fontSize = 11.sp, color = Color.LightGray)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(apiKey, clientId)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("Сохранить", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена", color = Color.LightGray)
            }
        },
        containerColor = Color(0xFF1E293B)
    )
}

/**
 * Диалог редактирования расписания группы.
 */
@Composable
fun ScheduleEditDialog(
    cityId: String,
    groupId: String,
    viewModel: AppStateViewModel,
    onDismiss: () -> Unit
) {
    val state by viewModel.state.collectAsState()
    val group = state.coachData?.cities
        ?.find { it.id == cityId }
        ?.groups?.find { it.id == groupId } ?: return

    val scope = rememberCoroutineScope()
    var weekDelta by remember { mutableIntStateOf(0) }
    val currentMonday = remember(weekDelta) { MonthUtils.getMondayOfWeek(weekDelta) }
    var isLoadingWeekSchedule by remember { mutableStateOf(false) }

    var weeklyList by remember { mutableStateOf<List<WeeklyClass>>(emptyList()) }
    var eventList by remember { mutableStateOf<List<GroupEvent>>(emptyList()) }

    LaunchedEffect(currentMonday, group.schedulesByWeek) {
        val localSched = group.schedulesByWeek[currentMonday]
        if (localSched != null) {
            weeklyList = localSched.weeklySchedule
            eventList = localSched.oneOffEvents
        } else {
            isLoadingWeekSchedule = true
            val coachId = state.firebaseUid.ifEmpty { "default_coach_owner" }
            val cloudSched = withContext(Dispatchers.IO) {
                SyncManager.pullSchedule(coachId, groupId, currentMonday)
            }
            if (cloudSched != null && (cloudSched.weeklySchedule.isNotEmpty() || cloudSched.oneOffEvents.isNotEmpty())) {
                weeklyList = cloudSched.weeklySchedule
                eventList = cloudSched.oneOffEvents
                // Обновим локально, чтобы не скачивать заново
                viewModel.updateGroupSchedule(
                    cityId = cityId,
                    groupId = groupId,
                    weeklySchedule = cloudSched.weeklySchedule,
                    oneOffEvents = cloudSched.oneOffEvents,
                    weekMonday = currentMonday
                )
            } else {
                if (weekDelta == 0) {
                    weeklyList = group.weeklySchedule
                    eventList = group.oneOffEvents
                } else {
                    weeklyList = emptyList()
                    eventList = emptyList()
                }
            }
            isLoadingWeekSchedule = false
        }
    }

    var newDayOfWeek by remember { mutableStateOf("Понедельник") }
    var newLocation by remember { mutableStateOf("") }
    var newStartTime by remember { mutableStateOf("18:00") }
    var newDurationHours by remember { mutableDoubleStateOf(1.0) }
    var newEndTime by remember { mutableStateOf("19:00") }

    var editingClass by remember { mutableStateOf<WeeklyClass?>(null) }
    var isAddingNewClass by remember { mutableStateOf(false) }

    var editingEvent by remember { mutableStateOf<GroupEvent?>(null) }
    var isAddingNewEvent by remember { mutableStateOf(false) }

    var newEventTitle by remember { mutableStateOf("") }
    var newEventDate by remember { mutableStateOf("") }
    var newEventTime by remember { mutableStateOf("12:00") }

    val daysOfWeek = listOf("Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Расписание группы ${group.name}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { weekDelta-- },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Предыдущая неделя",
                            tint = Color.White
                        )
                    }
                    val systemToday = remember { java.text.SimpleDateFormat("dd.MM", java.util.Locale("ru")).format(java.util.Date()) }
                    Text(
                        text = MonthUtils.formatWeekRange(currentMonday) + if (weekDelta == 0) " (Текущая, сегодня $systemToday)" else "",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = { weekDelta++ },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Следующая неделя",
                            tint = Color.White
                        )
                    }
                }
            }
        },
        text = {
            if (isLoadingWeekSchedule) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (weeklyList.isEmpty() && eventList.isEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "На эту неделю расписание пустое.\nВы можете скопировать расписание с предыдущей недели.",
                                color = Color.LightGray,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                            Button(
                                onClick = {
                                    scope.launch {
                                        isLoadingWeekSchedule = true
                                        val prevMonday = MonthUtils.getMondayOfWeek(weekDelta - 1)
                                        val prevSched = group.schedulesByWeek[prevMonday]
                                        if (prevSched != null) {
                                            weeklyList = prevSched.weeklySchedule
                                            eventList = prevSched.oneOffEvents
                                        } else {
                                            val coachId = state.firebaseUid.ifEmpty { "default_coach_owner" }
                                            val cloudSched = withContext(Dispatchers.IO) {
                                                SyncManager.pullSchedule(coachId, groupId, prevMonday)
                                            }
                                            if (cloudSched != null && (cloudSched.weeklySchedule.isNotEmpty() || cloudSched.oneOffEvents.isNotEmpty())) {
                                                weeklyList = cloudSched.weeklySchedule
                                                eventList = cloudSched.oneOffEvents
                                            } else {
                                                weeklyList = group.weeklySchedule
                                                eventList = group.oneOffEvents
                                            }
                                        }
                                        isLoadingWeekSchedule = false
                                    }
                                },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Скопировать расписание", color = Color.White)
                            }
                        }
                    }

                    val isFormOpen = editingClass != null || isAddingNewClass

                    if (isFormOpen) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = if (editingClass != null) "Редактирование занятия:" else "Новое постоянное занятие:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.primary
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            var expandedDayDropdown by remember { mutableStateOf(false) }
                            Box(modifier = Modifier.weight(1f)) {
                                OutlinedButton(
                                    onClick = { expandedDayDropdown = true },
                                    modifier = Modifier.fillMaxWidth(),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 12.dp)
                                ) {
                                    Text(newDayOfWeek, fontSize = 13.sp)
                                }
                                DropdownMenu(
                                    expanded = expandedDayDropdown,
                                    onDismissRequest = { expandedDayDropdown = false }
                                ) {
                                    daysOfWeek.forEach { day ->
                                        DropdownMenuItem(
                                            text = { Text(day) },
                                            onClick = {
                                                newDayOfWeek = day
                                                expandedDayDropdown = false
                                            }
                                        )
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = newLocation,
                                onValueChange = { newLocation = it },
                                label = { Text("Место (зал)") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = newStartTime,
                                onValueChange = { 
                                    val masked = MonthUtils.formatTimeWithMask(it)
                                    newStartTime = masked
                                    newEndTime = MonthUtils.calculateEndTime(masked, newDurationHours)
                                },
                                label = { Text("Начало (ЧЧ:ММ)") },
                                placeholder = { Text("18:00") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                modifier = Modifier.weight(1f)
                            )

                            OutlinedTextField(
                                value = newEndTime,
                                onValueChange = { 
                                    val masked = MonthUtils.formatTimeWithMask(it)
                                    newEndTime = masked
                                    newDurationHours = MonthUtils.calculateDuration(newStartTime, masked)
                                },
                                label = { Text("Окончание (ЧЧ:ММ)") },
                                placeholder = { Text("19:00") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Длительность (по 0.5 ч):", fontSize = 14.sp, color = Color.White)
                            
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = {
                                        if (newDurationHours > 0.5) {
                                            newDurationHours -= 0.5
                                            newEndTime = MonthUtils.calculateEndTime(newStartTime, newDurationHours)
                                        }
                                    },
                                    enabled = newDurationHours > 0.5
                                ) {
                                    Text(
                                        text = "-",
                                        color = if (newDurationHours > 0.5) Color.White else Color.Gray,
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                
                                Text(
                                    text = String.format(java.util.Locale.US, "%.1f ч", newDurationHours),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                )
                                
                                IconButton(
                                    onClick = {
                                        if (newDurationHours < 24.0) {
                                            newDurationHours += 0.5
                                            newEndTime = MonthUtils.calculateEndTime(newStartTime, newDurationHours)
                                        }
                                    },
                                    enabled = newDurationHours < 24.0
                                ) {
                                    Text(
                                        text = "+",
                                        color = if (newDurationHours < 24.0) Color.White else Color.Gray,
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    if (newStartTime.isNotBlank() && newEndTime.isNotBlank()) {
                                        val displayTime = if (newLocation.isNotEmpty()) {
                                            "$newStartTime - $newEndTime ($newLocation)"
                                        } else {
                                            "$newStartTime - $newEndTime"
                                        }
                                        val currentEditing = editingClass
                                        if (currentEditing != null) {
                                            weeklyList = weeklyList.map {
                                                if (it.id == currentEditing.id) {
                                                    it.copy(
                                                        dayOfWeek = newDayOfWeek,
                                                        time = displayTime,
                                                        location = newLocation.trim(),
                                                        startTime = newStartTime.trim(),
                                                        endTime = newEndTime.trim()
                                                    )
                                                } else it
                                            }
                                        } else {
                                            weeklyList = weeklyList + WeeklyClass(
                                                dayOfWeek = newDayOfWeek,
                                                time = displayTime,
                                                location = newLocation.trim(),
                                                startTime = newStartTime.trim(),
                                                endTime = newEndTime.trim()
                                            )
                                        }
                                        isAddingNewClass = false
                                        editingClass = null
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Применить", color = Color.White)
                            }

                            OutlinedButton(
                                onClick = {
                                    isAddingNewClass = false
                                    editingClass = null
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Назад", color = Color.White)
                            }
                        }
                    }
                } else {
                    Text(
                        text = "Постоянные занятия:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.primary
                    )

                    if (weeklyList.isEmpty()) {
                        Text("Постоянное расписание пока не заполнено.", fontSize = 14.sp, color = Color.Gray)
                    } else {
                        val daysOrder = listOf("Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье")
                        val groupedSchedule = weeklyList.groupBy { it.dayOfWeek }
                            .toList()
                            .sortedBy { (day, _) ->
                                val idx = daysOrder.indexOf(day)
                                if (idx != -1) idx else Int.MAX_VALUE
                            }

                        groupedSchedule.forEach { (day, classes) ->
                            Card(
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(
                                        text = day,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(bottom = 4.dp)
                                    )
                                    classes.forEach { weekly ->
                                        val timeStr = if (weekly.startTime.isNotEmpty() && weekly.endTime.isNotEmpty()) {
                                            "${weekly.startTime}..${weekly.endTime}"
                                        } else {
                                            weekly.time
                                        }
                                        val details = buildString {
                                            if (weekly.location.isNotEmpty()) {
                                                append("${weekly.location}; ")
                                            }
                                            append(timeStr)
                                        }
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = details,
                                                color = Color.White,
                                                fontSize = 13.sp,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Row {
                                                IconButton(
                                                    onClick = {
                                                        editingClass = weekly
                                                        newDayOfWeek = weekly.dayOfWeek
                                                        newLocation = weekly.location
                                                        newStartTime = weekly.startTime.ifEmpty { "18:00" }
                                                        newEndTime = weekly.endTime.ifEmpty { "19:00" }
                                                        newDurationHours = MonthUtils.calculateDuration(newStartTime, newEndTime)
                                                    },
                                                    modifier = Modifier.size(32.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Edit,
                                                        contentDescription = "Редактировать",
                                                        tint = Color.White,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                                IconButton(
                                                    onClick = {
                                                        weeklyList = weeklyList.filter { it.id != weekly.id }
                                                    },
                                                    modifier = Modifier.size(32.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Delete,
                                                        contentDescription = "Удалить",
                                                        tint = Color(0xFFEF4444),
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Button(
                        onClick = {
                            newDayOfWeek = "Понедельник"
                            newLocation = ""
                            newStartTime = "18:00"
                            newEndTime = "19:00"
                            newDurationHours = 1.0
                            isAddingNewClass = true
                            editingClass = null
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                }

                HorizontalDivider(color = Color.Gray.copy(alpha = 0.3f), thickness = 1.dp)

                Text(
                    text = "Разовые мероприятия:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                eventList.forEach { ev ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = ev.title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                            Text(text = "${ev.date} в ${ev.time}", color = Color.LightGray, fontSize = 12.sp)
                        }
                        Row {
                            IconButton(
                                onClick = {
                                    editingEvent = ev
                                    newEventTitle = ev.title
                                    newEventDate = ev.date
                                    newEventTime = ev.time
                                    isAddingNewEvent = false
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Редактировать",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            IconButton(
                                onClick = {
                                    eventList = eventList.filter { it.id != ev.id }
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Удалить",
                                    tint = Color(0xFFEF4444),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                if (isAddingNewEvent || editingEvent != null) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF1E293B), RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = if (editingEvent != null) "Редактирование мероприятия:" else "Новое разовое мероприятие:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.primary
                        )

                        OutlinedTextField(
                            value = newEventTitle,
                            onValueChange = { newEventTitle = it },
                            label = { Text("Название (например, Аттестация)") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = newEventDate,
                                onValueChange = { newEventDate = MonthUtils.formatDateWithMask(it) },
                                label = { Text("Дата (ДД.ММ.ГГ)") },
                                placeholder = { Text("01.06.26") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                modifier = Modifier.weight(1.2f)
                            )

                            OutlinedTextField(
                                value = newEventTime,
                                onValueChange = { newEventTime = MonthUtils.formatTimeWithMask(it) },
                                label = { Text("Время (ЧЧ:ММ)") },
                                placeholder = { Text("12:00") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                modifier = Modifier.weight(0.8f)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    if (newEventTitle.isNotBlank() && newEventDate.isNotBlank() && newEventTime.isNotBlank()) {
                                        val currentEditing = editingEvent
                                        if (currentEditing != null) {
                                            eventList = eventList.map {
                                                if (it.id == currentEditing.id) {
                                                    it.copy(
                                                        title = newEventTitle.trim(),
                                                        date = newEventDate.trim(),
                                                        time = newEventTime.trim()
                                                    )
                                                } else it
                                            }
                                        } else {
                                            eventList = eventList + GroupEvent(
                                                title = newEventTitle.trim(),
                                                date = newEventDate.trim(),
                                                time = newEventTime.trim()
                                            )
                                        }
                                        isAddingNewEvent = false
                                        editingEvent = null
                                        newEventTitle = ""
                                        newEventDate = ""
                                        newEventTime = "12:00"
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Применить", color = Color.White)
                            }

                            OutlinedButton(
                                onClick = {
                                    isAddingNewEvent = false
                                    editingEvent = null
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Назад", color = Color.White)
                            }
                        }
                    }
                } else {
                    Button(
                        onClick = {
                            newEventTitle = ""
                            newEventDate = ""
                            newEventTime = "12:00"
                            isAddingNewEvent = true
                            editingEvent = null
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                }
            }
        }
    },
        confirmButton = {
            Button(
                onClick = {
                    viewModel.updateGroupSchedule(cityId, groupId, weeklyList, eventList, currentMonday)
                    onDismiss()
                }
            ) {
                Text("Сохранить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена", color = Color.LightGray)
            }
        },
        containerColor = Color(0xFF1E293B)
    )
}

/**
 * Диалог добавления города.
 */
@Composable
fun AddCityDialog(
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Добавить город", fontWeight = FontWeight.Bold) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Название города") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(name.trim()) },
                enabled = name.isNotBlank()
            ) {
                Text("Добавить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}

/**
 * Диалог редактирования города.
 */
@Composable
fun EditCityDialog(
    currentName: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var name by remember { mutableStateOf(currentName) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Редактировать город", fontWeight = FontWeight.Bold) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Название города") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(name.trim()) },
                enabled = name.isNotBlank()
            ) {
                Text("Сохранить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}

/**
 * Диалог добавления тренировочной группы.
 */
@Composable
fun AddGroupDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, Double) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var defaultFee by remember { mutableStateOf("3000") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Добавить группу", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Название группы") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = defaultFee,
                    onValueChange = { defaultFee = it },
                    label = { Text("Абонемент по умолчанию (₽)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val fee = defaultFee.toDoubleOrNull() ?: 3000.0
                    onConfirm(name.trim(), fee)
                },
                enabled = name.isNotBlank()
            ) {
                Text("Добавить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}

/**
 * Диалог редактирования тренировочной группы.
 */
@Composable
fun EditGroupDialog(
    currentName: String,
    currentFee: Double,
    onDismiss: () -> Unit,
    onConfirm: (String, Double) -> Unit
) {
    var name by remember { mutableStateOf(currentName) }
    var defaultFee by remember { mutableStateOf(currentFee.toInt().toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Редактировать группу", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Название группы") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = defaultFee,
                    onValueChange = { defaultFee = it },
                    label = { Text("Абонемент по умолчанию (₽)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val fee = defaultFee.toDoubleOrNull() ?: 3000.0
                    onConfirm(name.trim(), fee)
                },
                enabled = name.isNotBlank()
            ) {
                Text("Сохранить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}

/**
 * Диалог добавления ученика.
 */
@Composable
fun AddStudentDialog(
    defaultJoinMonth: String,
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, String) -> Unit
) {
    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var joinMonth by remember { mutableStateOf(MonthUtils.formatYearMonthToMaskDate(defaultJoinMonth)) }
    var phone by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Добавить ученика", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = lastName,
                    onValueChange = { lastName = it },
                    label = { Text("Фамилия") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = firstName,
                    onValueChange = { firstName = it },
                    label = { Text("Имя") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = joinMonth,
                    onValueChange = { joinMonth = MonthUtils.formatInputDateWithMask(it) },
                    label = { Text("Месяц прихода (ММ.ГГ, например 05.26)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Телефон (например: +79991234567)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsedJoinMonth = MonthUtils.parseMaskDateToYearMonth(joinMonth, defaultJoinMonth)
                    onConfirm(firstName.trim(), lastName.trim(), parsedJoinMonth, phone.trim())
                },
                enabled = firstName.isNotBlank() && lastName.isNotBlank()
            ) {
                Text("Добавить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}

/**
 * Диалог редактирования личных данных и параметров ученика.
 */
@Composable
fun EditStudentDialog(
    currentFirstName: String,
    currentLastName: String,
    currentJoinMonth: String,
    currentPhone: String,
    defaultJoinMonth: String,
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, String) -> Unit
) {
    var firstName by remember { mutableStateOf(currentFirstName) }
    var lastName by remember { mutableStateOf(currentLastName) }
    var joinMonth by remember { mutableStateOf(MonthUtils.formatYearMonthToMaskDate(currentJoinMonth)) }
    var phone by remember { mutableStateOf(currentPhone) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Редактировать ученика", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = lastName,
                    onValueChange = { lastName = it },
                    label = { Text("Фамилия") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = firstName,
                    onValueChange = { firstName = it },
                    label = { Text("Имя") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = joinMonth,
                    onValueChange = { joinMonth = MonthUtils.formatInputDateWithMask(it) },
                    label = { Text("Месяц прихода (ММ.ГГ, например 05.26)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Телефон (например: +79991234567)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsedJoinMonth = MonthUtils.parseMaskDateToYearMonth(joinMonth, defaultJoinMonth)
                    onConfirm(firstName.trim(), lastName.trim(), parsedJoinMonth, phone.trim())
                },
                enabled = firstName.isNotBlank() && lastName.isNotBlank()
            ) {
                Text("Сохранить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}

/**
 * Диалог изменения стоимости базового ежемесячного абонемента ученика.
 */
@Composable
fun ChangeFeeDialog(
    studentName: String,
    currentFee: Double,
    onDismiss: () -> Unit,
    onConfirm: (Double) -> Unit
) {
    var feeInput by remember { mutableStateOf(currentFee.toInt().toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Размер абонемента", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(
                    text = "Новый размер периодической оплаты (абонемента) для ученика $studentName:",
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
                OutlinedTextField(
                    value = feeInput,
                    onValueChange = { feeInput = it },
                    label = { Text("Сумма (₽)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "*Изменение цены применится к будущим месяцам. Суммы в уже сгенерированных ранее месяцах не изменятся.",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = feeInput.toDoubleOrNull()
                    if (amount != null && amount >= 0) {
                        onConfirm(amount)
                    }
                },
                enabled = feeInput.toDoubleOrNull() != null
            ) {
                Text("Сохранить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}

/**
 * Диалог добавления индивидуального разового платежа за определенный месяц.
 */
@Composable
fun AddCustomPaymentDialog(
    studentName: String,
    defaultMonth: String,
    onDismiss: () -> Unit,
    onConfirm: (String, Double, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amountStr by remember { mutableStateOf("") }
    var customMonth by remember { mutableStateOf(MonthUtils.formatYearMonthToMaskDate(defaultMonth)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Добавить разовый платеж", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Добавить разовый платеж для ученика $studentName за ${MonthUtils.formatMonthDisplay(defaultMonth)}:",
                    fontSize = 14.sp
                )
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Название (например: Форма, Соревнования)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text("Сумма (₽)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = customMonth,
                    onValueChange = { customMonth = MonthUtils.formatInputDateWithMask(it) },
                    label = { Text("Месяц привязки (ММ.ГГ, например 05.26)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountStr.toDoubleOrNull()
                    if (title.isNotBlank() && amount != null && amount >= 0) {
                        val parsedMonth = MonthUtils.parseMaskDateToYearMonth(customMonth, defaultMonth)
                        onConfirm(title.trim(), amount, parsedMonth)
                    }
                },
                enabled = title.isNotBlank() && amountStr.toDoubleOrNull() != null
            ) {
                Text("Добавить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}

/**
 * Диалог создания группового сбора для группы учеников.
 */
@Composable
fun GroupPaymentDialog(
    students: List<Student>,
    defaultMonth: String,
    onDismiss: () -> Unit,
    onConfirm: (List<String>, String, Double, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amountStr by remember { mutableStateOf("") }
    var bindToMonth by remember { mutableStateOf(true) }
    var customMonth by remember { mutableStateOf(MonthUtils.formatYearMonthToMaskDate(defaultMonth)) }

    val selectedStudentIds = remember {
        mutableStateListOf<String>().apply {
            addAll(students.map { it.id })
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Создать групповой сбор", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Название (например: Сборы, Форма)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text("Сумма (₽)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { bindToMonth = !bindToMonth }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = bindToMonth,
                        onCheckedChange = { bindToMonth = it }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Привязать к месяцу", fontSize = 14.sp)
                }

                if (bindToMonth) {
                    OutlinedTextField(
                        value = customMonth,
                        onValueChange = { customMonth = MonthUtils.formatInputDateWithMask(it) },
                        label = { Text("Месяц привязки (ММ.ГГ, например 05.26)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                Text(
                    text = "Кому назначить сбор (${selectedStudentIds.size} из ${students.size}):",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            selectedStudentIds.clear()
                            selectedStudentIds.addAll(students.map { it.id })
                        },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(vertical = 4.dp)
                    ) {
                        Text("Все", fontSize = 13.sp)
                    }
                    OutlinedButton(
                        onClick = { selectedStudentIds.clear() },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(vertical = 4.dp)
                    ) {
                        Text("Снять выбор", fontSize = 13.sp)
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 180.dp)
                        .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                        .padding(4.dp)
                ) {
                    items(students) { student ->
                        val isSelected = selectedStudentIds.contains(student.id)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (isSelected) {
                                        selectedStudentIds.remove(student.id)
                                    } else {
                                        selectedStudentIds.add(student.id)
                                    }
                                }
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isSelected,
                                onCheckedChange = { checked ->
                                    if (checked == true) {
                                        selectedStudentIds.add(student.id)
                                    } else {
                                        selectedStudentIds.remove(student.id)
                                    }
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "${student.lastName} ${student.firstName}",
                                fontSize = 14.sp,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountStr.toDoubleOrNull()
                    if (title.isNotBlank() && amount != null && amount >= 0 && selectedStudentIds.isNotEmpty()) {
                        val monthParam = if (bindToMonth) {
                            MonthUtils.parseMaskDateToYearMonth(customMonth, defaultMonth)
                        } else {
                            ""
                        }
                        onConfirm(selectedStudentIds.toList(), title.trim(), amount, monthParam)
                    }
                },
                enabled = title.isNotBlank() && amountStr.toDoubleOrNull() != null && selectedStudentIds.isNotEmpty()
            ) {
                Text("Создать")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}

/**
 * Диалог отображения инвайт-кода и QR-кода для связывания родительского кабинета.
 */
@Composable
fun LinkCodeDialog(
    studentName: String,
    linkCode: String,
    onDismiss: () -> Unit
) {
    val qrBitmap = remember(linkCode) {
        QrCodeGenerator.generateQrCode(linkCode, 512)
    }
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Связывание устройства",
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Ученик: $studentName",
                    fontSize = 16.sp,
                    color = Color.LightGray,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))
                if (qrBitmap != null) {
                    Image(
                        bitmap = qrBitmap.asImageBitmap(),
                        contentDescription = "QR Code",
                        modifier = Modifier
                            .size(200.dp)
                            .background(Color.White, shape = RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Отсканируйте этот QR-код камерой на устройстве ученика для привязки к CoachPay.",
                    fontSize = 14.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Код для ввода вручную: $linkCode",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center
                )
            }
        },
        confirmButton = {
            Row {
                TextButton(onClick = {
                    val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    val clip = android.content.ClipData.newPlainText("Invite Code", linkCode)
                    clipboard.setPrimaryClip(clip)
                    android.widget.Toast.makeText(context, "Код скопирован в буфер обмена!", android.widget.Toast.LENGTH_SHORT).show()
                }) {
                    Text("Копировать", color = MaterialTheme.colorScheme.primary)
                }
                Spacer(modifier = Modifier.width(8.dp))
                TextButton(onClick = onDismiss) {
                    Text("Закрыть", color = MaterialTheme.colorScheme.primary)
                }
            }
        },
        containerColor = Color(0xFF1E293B)
    )
}
