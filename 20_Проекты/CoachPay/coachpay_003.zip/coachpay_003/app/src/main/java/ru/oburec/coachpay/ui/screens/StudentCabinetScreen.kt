package ru.oburec.coachpay.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.oburec.coachpay.model.AppRole
import ru.oburec.coachpay.model.PaymentState
import ru.oburec.coachpay.model.Student
import ru.oburec.coachpay.ui.utils.MonthUtils
import ru.oburec.coachpay.viewmodel.AppStateViewModel

/**
 * Экран личного кабинета ученика/родителя.
 * Позволяет связать устройство по инвайт-коду/телефону, просматривать расписание занятий,
 * изменять свои данные (рост, вес, дата рождения, телефон) и отмечать счета как оплаченные.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentCabinetScreen(viewModel: AppStateViewModel) {
    val state by viewModel.state.collectAsState()
    val config = state.studentConfig
    val context = LocalContext.current

    LaunchedEffect(config?.studentId) {
        if (config?.studentId != null) {
            viewModel.pullPaymentsForStudent()
        }
    }

    if (config == null || config.coachId.isEmpty() || config.groupId.isEmpty()) {
        // --- ЭКРАН ВВОДА ИНВАЙТ-КОДА ИЛИ ТЕЛЕФОНА ---
        var codeInput by remember { mutableStateOf("") }
        var isConnecting by remember { mutableStateOf(false) }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Привязка кабинета CoachPay",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Введите 6-значный код или номер телефона, привязанный к вашему профилю, для синхронизации расписания и оплат.",
                fontSize = 14.sp,
                color = Color.LightGray,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(24.dp))

            // Кнопка для сканирования QR-кода привязки
            Button(
                onClick = {
                    val scanner = com.google.mlkit.vision.codescanner.GmsBarcodeScanning.getClient(context)
                    scanner.startScan()
                        .addOnSuccessListener { barcode ->
                            val rawValue = barcode.rawValue
                            if (!rawValue.isNullOrBlank()) {
                                codeInput = rawValue
                                isConnecting = true
                                viewModel.linkStudentByInviteCode(rawValue) { success, name ->
                                    isConnecting = false
                                    if (success) {
                                        android.widget.Toast.makeText(
                                            context,
                                            "Успешно привязано: $name",
                                            android.widget.Toast.LENGTH_LONG
                                        ).show()
                                    } else {
                                        android.widget.Toast.makeText(
                                            context,
                                            "Неверный код/телефон или ошибка сети",
                                            android.widget.Toast.LENGTH_LONG
                                        ).show()
                                    }
                                }
                            }
                        }
                        .addOnFailureListener { e ->
                            android.widget.Toast.makeText(
                                context,
                                "Ошибка сканирования: ${e.message}",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF1E293B)
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .height(50.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.QrCodeScanner,
                    contentDescription = "Scan QR",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Сканировать QR-код", color = Color.White)
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Текстовое поле ввода кода/номера телефона
            OutlinedTextField(
                value = codeInput,
                onValueChange = { input ->
                    if (input.length <= 20) {
                        codeInput = input
                    }
                },
                label = { Text("Код или телефон") },
                placeholder = { Text("123456 или +79991234567") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = Color.Gray,
                    focusedLabelColor = MaterialTheme.colorScheme.primary,
                    unfocusedLabelColor = Color.Gray,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                modifier = Modifier.fillMaxWidth(0.8f)
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    if (codeInput.isNotBlank()) {
                        isConnecting = true
                        viewModel.linkStudentByInviteCode(codeInput) { success, name ->
                            isConnecting = false
                            if (success) {
                                android.widget.Toast.makeText(
                                    context,
                                    "Успешно привязано: $name",
                                    android.widget.Toast.LENGTH_LONG
                                ).show()
                            } else {
                                android.widget.Toast.makeText(
                                    context,
                                    "Неверный код/телефон или ошибка сети",
                                    android.widget.Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    } else {
                        android.widget.Toast.makeText(
                            context,
                            "Введите код или телефон",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    }
                },
                enabled = !isConnecting,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth(0.8f).height(50.dp)
            ) {
                if (isConnecting) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                } else {
                    Text("Связать устройство", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    } else if (config.studentId.isNullOrEmpty()) {
        // --- ЭКРАН ВЫБОРА РЕБЕНКА ИЛИ ДОБАВЛЕНИЯ НОВОГО ---
        var groupStudents by remember { mutableStateOf<List<Student>?>(null) }
        var isLoading by remember { mutableStateOf(true) }
        var showAddStudentDialog by remember { mutableStateOf(false) }
        var newStudentFirstName by remember { mutableStateOf("") }
        var newStudentLastName by remember { mutableStateOf("") }
        var isLinking by remember { mutableStateOf(false) }

        LaunchedEffect(config.groupId) {
            isLoading = true
            viewModel.fetchGroupStudents(config.coachId, config.cityId, config.groupId) { list ->
                groupStudents = list
                isLoading = false
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "Выберите ученика",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Группа: ${config.groupName} (${config.cityName})",
                fontSize = 14.sp,
                color = Color.LightGray,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(24.dp))

            if (isLoading) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            } else {
                val list = groupStudents ?: emptyList()
                if (list.isEmpty()) {
                    Text(
                        text = "В этой группе пока нет зарегистрированных учеников.",
                        fontSize = 14.sp,
                        color = Color.LightGray,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f)
                    )
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        items(list) { student ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                                border = BorderStroke(1.dp, Color.Gray.copy(alpha = 0.3f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable(enabled = !isLinking) {
                                        isLinking = true
                                        viewModel.linkStudentToParent(
                                            coachId = config.coachId,
                                            cityId = config.cityId,
                                            cityName = config.cityName,
                                            groupId = config.groupId,
                                            groupName = config.groupName,
                                            studentId = student.id,
                                            studentName = "${student.lastName} ${student.firstName}",
                                            inviteCode = config.inviteCode
                                        ) { success ->
                                            isLinking = false
                                            if (success) {
                                                android.widget.Toast.makeText(context, "Успешно связано!", android.widget.Toast.LENGTH_SHORT).show()
                                            } else {
                                                android.widget.Toast.makeText(context, "Ошибка привязки", android.widget.Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${student.lastName} ${student.firstName}",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Icon(
                                        imageVector = Icons.Default.ChevronRight,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Кнопка добавления нового ученика в группу напрямую родителем
                Button(
                    onClick = { showAddStudentDialog = true },
                    enabled = !isLinking,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Добавить нового ученика", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Назад к первому этапу ввода
                TextButton(
                    onClick = {
                        viewModel.saveState(state.copy(studentConfig = null))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Назад к вводу кода", color = Color.LightGray)
                }
            }
        }

        // Диалог добавления нового ученика
        if (showAddStudentDialog) {
            AlertDialog(
                onDismissRequest = { showAddStudentDialog = false },
                title = { Text("Добавить ученика", color = Color.White) },
                containerColor = Color(0xFF1E293B),
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = newStudentLastName,
                            onValueChange = { newStudentLastName = it },
                            label = { Text("Фамилия ученика") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                        OutlinedTextField(
                            value = newStudentFirstName,
                            onValueChange = { newStudentFirstName = it },
                            label = { Text("Имя ученика") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newStudentFirstName.isNotBlank() && newStudentLastName.isNotBlank()) {
                                showAddStudentDialog = false
                                isLinking = true
                                viewModel.addNewStudentFromParent(
                                    coachId = config.coachId,
                                    cityId = config.cityId,
                                    groupId = config.groupId,
                                    firstName = newStudentFirstName.trim(),
                                    lastName = newStudentLastName.trim()
                                ) { success, newStudent ->
                                    if (success && newStudent != null) {
                                        viewModel.linkStudentToParent(
                                            coachId = config.coachId,
                                            cityId = config.cityId,
                                            cityName = config.cityName,
                                            groupId = config.groupId,
                                            groupName = config.groupName,
                                            studentId = newStudent.id,
                                            studentName = "${newStudent.lastName} ${newStudent.firstName}",
                                            inviteCode = config.inviteCode
                                        ) { successLink ->
                                            isLinking = false
                                            if (successLink) {
                                                android.widget.Toast.makeText(context, "Ученик добавлен и привязан!", android.widget.Toast.LENGTH_SHORT).show()
                                            } else {
                                                android.widget.Toast.makeText(context, "Ошибка привязки", android.widget.Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    } else {
                                        isLinking = false
                                        android.widget.Toast.makeText(context, "Ошибка добавления", android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                }
                            } else {
                                android.widget.Toast.makeText(context, "Заполните имя и фамилию", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        }
                    ) {
                        Text("Добавить", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddStudentDialog = false }) {
                        Text("Отмена", color = Color.LightGray)
                    }
                }
            )
        }
    } else {
        // --- ГЛАВНЫЙ ИНТЕРФЕЙС УЧЕНИКА С ТАБАМИ ---
        var selectedTab by remember { mutableIntStateOf(0) }

        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            Card(
                shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "${config.lastName} ${config.firstName}",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Группа: ${config.groupName} (${config.cityName})",
                        fontSize = 14.sp,
                        color = Color.LightGray
                    )
                }
            }

            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color(0xFF0F172A),
                contentColor = MaterialTheme.colorScheme.primary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Оплаты", fontWeight = FontWeight.Bold) },
                    icon = { Icon(imageVector = Icons.Default.Payments, contentDescription = null) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Расписание", fontWeight = FontWeight.Bold) },
                    icon = { Icon(imageVector = Icons.Default.DateRange, contentDescription = null) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Профиль", fontWeight = FontWeight.Bold) },
                    icon = { Icon(imageVector = Icons.Default.Person, contentDescription = null) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Запись", fontWeight = FontWeight.Bold) },
                    icon = { Icon(imageVector = Icons.Default.Event, contentDescription = null) }
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                when (selectedTab) {
                    0 -> {
                        // Таб оплат
                        val isRecentPayment = remember {
                            { payment: ru.oburec.coachpay.model.Payment ->
                                val confirmedTime = payment.confirmedAt
                                confirmedTime != null && (System.currentTimeMillis() - confirmedTime) < 24 * 60 * 60 * 1000L
                            }
                        }
                        // Показываем в основном списке: либо неоплаченные, либо оплаченные за последние 24 часа
                        val activeCabinetPayments = remember(config.payments) {
                            config.payments.filter { it.state != PaymentState.PAID || isRecentPayment(it) }
                        }
                        // В архиве показываем только оплаченные более 24 часов назад
                        val archivedCabinetPayments = remember(config.payments) {
                            config.payments.filter { it.state == PaymentState.PAID && !isRecentPayment(it) }
                        }

                        Column(modifier = Modifier.fillMaxSize()) {
                            Text(
                                text = "Неоплаченные счета (нажмите для отметки):",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            if (activeCabinetPayments.isEmpty()) {
                                Text(
                                    text = "Все счета оплачены! 👍",
                                    fontSize = 14.sp,
                                    color = Color.LightGray,
                                    modifier = Modifier.padding(vertical = 12.dp)
                                )
                            } else {
                                LazyColumn(
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    items(activeCabinetPayments) { payment ->
                                        var isUpdating by remember { mutableStateOf(false) }
                                        val isPending = payment.state == PaymentState.PENDING_APPROVAL
                                        val isPaid = payment.state == PaymentState.PAID

                                        Card(
                                            shape = RoundedCornerShape(12.dp),
                                            colors = CardDefaults.cardColors(
                                                containerColor = when {
                                                    isPaid -> Color(0xFF10B981).copy(alpha = 0.12f)
                                                    isPending -> Color(0xFFF59E0B).copy(alpha = 0.15f)
                                                    else -> Color(0xFFEF4444).copy(alpha = 0.12f)
                                                }
                                            ),
                                            border = BorderStroke(
                                                width = 1.dp,
                                                color = when {
                                                    isPaid -> Color(0xFF10B981)
                                                    isPending -> Color(0xFFF59E0B)
                                                    else -> Color(0xFFEF4444)
                                                }
                                            ),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable(enabled = !isPaid && !isPending && !isUpdating) {
                                                    isUpdating = true
                                                    viewModel.studentMarkAsPaid(payment.id) { success ->
                                                        isUpdating = false
                                                        if (success) {
                                                            android.widget.Toast.makeText(context, "Отправлено тренеру на проверку!", android.widget.Toast.LENGTH_SHORT).show()
                                                        }
                                                    }
                                                }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(16.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = payment.title,
                                                        fontSize = 16.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color.White
                                                    )
                                                    if (payment.month.isNotEmpty()) {
                                                        Text(
                                                            text = MonthUtils.formatMonthDisplay(payment.month),
                                                            fontSize = 12.sp,
                                                            color = Color.LightGray
                                                        )
                                                    }
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Text(
                                                        text = "${payment.amount.toInt()} ₽",
                                                        fontSize = 18.sp,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        color = when {
                                                            isPaid -> Color(0xFF10B981)
                                                            isPending -> Color(0xFFF59E0B)
                                                            else -> Color(0xFFEF4444)
                                                        }
                                                    )
                                                }
                                                
                                                when {
                                                    isPaid -> {
                                                        Surface(
                                                            color = Color(0xFF10B981).copy(alpha = 0.2f),
                                                            contentColor = Color(0xFF10B981),
                                                            shape = RoundedCornerShape(8.dp)
                                                        ) {
                                                            Text(
                                                                text = "Оплачено",
                                                                fontSize = 11.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                            )
                                                        }
                                                    }
                                                    isPending -> {
                                                        Surface(
                                                            color = Color(0xFFF59E0B).copy(alpha = 0.2f),
                                                            contentColor = Color(0xFFF59E0B),
                                                            shape = RoundedCornerShape(8.dp)
                                                        ) {
                                                            Text(
                                                                text = "Проверяется",
                                                                fontSize = 11.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                            )
                                                        }
                                                    }
                                                    else -> {
                                                        Button(
                                                            onClick = {
                                                                isUpdating = true
                                                                viewModel.studentMarkAsPaid(payment.id) { success ->
                                                                    isUpdating = false
                                                                    if (success) {
                                                                        android.widget.Toast.makeText(context, "Отправлено тренеру на проверку!", android.widget.Toast.LENGTH_SHORT).show()
                                                                    }
                                                                }
                                                            },
                                                            enabled = !isUpdating,
                                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                                            shape = RoundedCornerShape(8.dp)
                                                        ) {
                                                            if (isUpdating) {
                                                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp))
                                                            } else {
                                                                Text("Оплатить", fontSize = 12.sp, color = Color.White)
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Архив подтвержденных оплат
                            if (archivedCabinetPayments.isNotEmpty()) {
                                var showHistory by remember { mutableStateOf(false) }
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { showHistory = !showHistory }
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "История оплат (${archivedCabinetPayments.size})",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.Green,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Icon(
                                        imageVector = if (showHistory) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                        contentDescription = null,
                                        tint = Color.Green
                                    )
                                }
                                
                                if (showHistory) {
                                    LazyColumn(
                                        verticalArrangement = Arrangement.spacedBy(6.dp),
                                        modifier = Modifier.weight(0.8f)
                                    ) {
                                        items(archivedCabinetPayments) { payment ->
                                            Card(
                                                shape = RoundedCornerShape(8.dp),
                                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(12.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column {
                                                        Text(payment.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                                        if (payment.month.isNotEmpty()) {
                                                            Text(MonthUtils.formatMonthDisplay(payment.month), fontSize = 11.sp, color = Color.LightGray)
                                                        }
                                                    }
                                                    Text("${payment.amount.toInt()} ₽", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.Green)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        // Таб расписания занятий
                        val weekly = config.weeklySchedule
                        val events = config.oneOffEvents

                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Text(
                                text = "Постоянные тренировки в неделю:",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )

                            if (weekly.isEmpty()) {
                                Text("Постоянное расписание пока не заполнено тренером.", fontSize = 14.sp, color = Color.Gray)
                            } else {
                                val daysOrder = listOf("Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье")
                                val groupedSchedule = remember(weekly) {
                                    weekly.groupBy { it.dayOfWeek }
                                        .toList()
                                        .sortedBy { (day, _) ->
                                            val idx = daysOrder.indexOf(day)
                                            if (idx != -1) idx else Int.MAX_VALUE
                                        }
                                }

                                groupedSchedule.forEach { (day, classes) ->
                                    Card(
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Text(
                                                text = day,
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.padding(bottom = 6.dp)
                                            )
                                            classes.forEach { cls ->
                                                val timeStr = if (cls.startTime.isNotEmpty() && cls.endTime.isNotEmpty()) {
                                                    "${cls.startTime}..${cls.endTime}"
                                                } else {
                                                    cls.time
                                                }
                                                val details = buildString {
                                                    if (cls.location.isNotEmpty()) {
                                                        append("${cls.location}; ")
                                                    }
                                                    append(timeStr)
                                                }
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(vertical = 4.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Schedule,
                                                        contentDescription = null,
                                                        tint = Color.LightGray,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text(
                                                        text = details,
                                                        fontSize = 14.sp,
                                                        color = Color.White
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            HorizontalDivider(color = Color.Gray.copy(alpha = 0.2f), thickness = 1.dp)

                            Text(
                                text = "Разовые мероприятия / События:",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )

                            if (events.isEmpty()) {
                                Text("Дополнительных мероприятий не запланировано.", fontSize = 14.sp, color = Color.Gray)
                            } else {
                                events.forEach { ev ->
                                    Card(
                                        shape = RoundedCornerShape(8.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Text(ev.title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = Icons.Default.DateRange,
                                                    contentDescription = null,
                                                    tint = Color.LightGray,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("${ev.date} в ${ev.time}", fontSize = 13.sp, color = Color.LightGray)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    2 -> {
                        // Таб редактирования профиля
                        var birthDate by remember { mutableStateOf(config.birthDate) }
                        var height by remember { mutableStateOf(config.height) }
                        var weight by remember { mutableStateOf(config.weight) }
                        var phone by remember { mutableStateOf(config.phone) }
                        var isSaving by remember { mutableStateOf(false) }

                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Text(
                                text = "Личные данные ученика",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )

                            OutlinedTextField(
                                value = birthDate,
                                onValueChange = { birthDate = MonthUtils.formatDateWithMask(it) },
                                label = { Text("Дата рождения (ДД.ММ.ГГ)") },
                                placeholder = { Text("Пример: 01.06.26") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = height,
                                onValueChange = { height = it.filter { c -> c.isDigit() }.take(3) },
                                label = { Text("Рост (см)") },
                                placeholder = { Text("175") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = phone,
                                onValueChange = { phone = it },
                                label = { Text("Телефон") },
                                placeholder = { Text("+79991234567") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = weight,
                                onValueChange = { weight = it.filter { c -> c.isDigit() || c == '.' }.take(5) },
                                label = { Text("Вес (кг)") },
                                placeholder = { Text("70") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Button(
                                onClick = {
                                    isSaving = true
                                    viewModel.updateStudentProfile(birthDate, height, weight, phone) { success ->
                                        isSaving = false
                                        if (success) {
                                            android.widget.Toast.makeText(context, "Профиль сохранен!", android.widget.Toast.LENGTH_SHORT).show()
                                        } else {
                                            android.widget.Toast.makeText(context, "Ошибка сохранения", android.widget.Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                enabled = !isSaving,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                if (isSaving) {
                                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                                } else {
                                    Text("Сохранить изменения", fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }
                    }
                    3 -> {
                        BookingsScreen(
                            cityId = config.cityId,
                            groupId = config.groupId,
                            groupName = config.groupName,
                            viewModel = viewModel,
                            isCoach = false
                        )
                    }
                }
            }
        }
    }
}


