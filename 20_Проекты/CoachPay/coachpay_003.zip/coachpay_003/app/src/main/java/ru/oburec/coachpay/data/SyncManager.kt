package ru.oburec.coachpay.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import ru.oburec.coachpay.model.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * Класс данных (data class), описывающий информацию по инвайт-коду.
 * Связывает сгенерированный инвайт-код с конкретным тренером, городом, группой и учеником.
 *
 * @property coachId Идентификатор тренера.
 * @property cityId Идентификатор города.
 * @property cityName Название города.
 * @property groupId Идентификатор группы.
 * @property groupName Название группы.
 * @property studentId Идентификатор ученика.
 * @property studentName Имя и фамилия ученика.
 */
@Serializable
data class InviteInfo(
    val coachId: String,
    val cityId: String,
    val cityName: String,
    val groupId: String,
    val groupName: String,
    val studentId: String,
    val studentName: String
)

/**
 * Объект SyncManager отвечает за сетевое взаимодействие с Firebase Realtime Database.
 * Выполняет GET, PUT, POST и DELETE HTTP-запросы для синхронизации локальных данных с облаком.
 * Также управляет аутентификацией (через Google Sign-In и Firebase Auth REST API) 
 * и обновлением сессионных токенов авторизации.
 */
object SyncManager {
    
    // URL-адрес базы данных Firebase Realtime Database
    var BASE_URL = "https://coachpay-6307c-default-rtdb.firebaseio.com"
    
    // URL-адрес для авторизации через провайдера Google ID Token в Firebase Auth
    var IDENTITY_URL = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp"
    
    // URL-адрес для обновления сессионного токена (Firebase Auth Refresh Token API)
    var SECURE_TOKEN_URL = "https://securetoken.googleapis.com/v1/token"
    
    // Конфигурация парсера JSON (игнорирует поля, которые есть на сервере, но не описаны в коде)
    private val jsonHelper = Json { ignoreUnknownKeys = true }

    // Текущий активный токен авторизации (ID Token) для подписи запросов к Firebase Realtime Database
    var currentAuthToken: String? = null
    
    // Сообщение о последней сетевой ошибке (удобно для логирования и отображения Toast)
    var lastError: String? = null

    /**
     * Вспомогательный метод для выполнения HTTP-запросов к Firebase.
     * Запускается асинхронно в фоновом пуле потоков (Dispatchers.IO).
     * Содержит встроенную защиту, блокирующую запросы к реальной базе данных во время тестов (JUnit).
     *
     * @param urlStr URL-адрес запроса.
     * @param method Метод HTTP ("GET", "PUT", "POST", "DELETE").
     * @param body Тело запроса в формате строки (по умолчанию null).
     * @return Возвращает ответ сервера в виде строки, либо null, если произошла сетевая ошибка.
     */
    private suspend fun makeHttpRequest(
        urlStr: String,
        method: String,
        body: String? = null
    ): String? = withContext(Dispatchers.IO) {
        
        // --- ЗАЩИТА БАЗЫ ДАННЫХ В ЮНИТ-ТЕСТАХ ---
        // Проверяем стек вызовов потока: если вызов инициирован JUnit, блокируем запросы к серверу
        val isJUnitTest = Thread.currentThread().stackTrace.any { 
            it.className.contains("junit") || it.className.contains("org.junit") 
        }
        val isRealDatabaseTest = Thread.currentThread().stackTrace.any {
            it.className.contains("RealDatabaseConnectionTest")
        }
        if (isJUnitTest && !isRealDatabaseTest) {
            val isLocal = urlStr.contains("127.0.0.1") || urlStr.contains("localhost")
            if (!isLocal) {
                val errorMsg = "CRITICAL SAFETY BLOCKED: Юнит-тест попытался сделать запрос к боевой БД: $urlStr"
                println(errorMsg)
                lastError = errorMsg
                return@withContext null
            }
        }

        var connection: HttpURLConnection? = null
        try {
            // Если токен авторизации задан, добавляем его в параметры URL: ?auth=TOKEN
            val finalUrlStr = if (!currentAuthToken.isNullOrEmpty() && !urlStr.contains("identitytoolkit") && !urlStr.contains("securetoken")) {
                if (urlStr.contains("?")) "$urlStr&auth=$currentAuthToken" else "$urlStr?auth=$currentAuthToken"
            } else {
                urlStr
            }
            val url = URL(finalUrlStr)
            
            // Настройка локального прокси для эмуляторов/тестов при необходимости
            val isLocal = finalUrlStr.contains("127.0.0.1") || finalUrlStr.contains("localhost")
            println("makeHttpRequest URL: $finalUrlStr, isLocal: $isLocal")
            
            connection = if (isLocal) {
                url.openConnection(java.net.Proxy.NO_PROXY) as HttpURLConnection
            } else {
                url.openConnection() as HttpURLConnection
            }
            
            connection.requestMethod = method
            connection.connectTimeout = 5000 // Лимит ожидания соединения - 5 секунд
            connection.readTimeout = 5000    // Лимит ожидания ответа - 5 секунд
            connection.setRequestProperty("Content-Type", "application/json")
            
            // Если передан body, пишем его в исходящий поток запроса
            if (body != null) {
                connection.doOutput = true
                val writer = OutputStreamWriter(connection.outputStream, "UTF-8")
                writer.write(body)
                writer.flush()
                writer.close()
            }

            // Проверяем HTTP-код ответа
            val responseCode = connection.responseCode
            if (responseCode == HttpURLConnection.HTTP_OK || responseCode == HttpURLConnection.HTTP_NO_CONTENT) {
                val stream = connection.inputStream ?: return@withContext ""
                val reader = BufferedReader(InputStreamReader(stream, "UTF-8"))
                val response = StringBuilder()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    response.append(line)
                }
                reader.close()
                lastError = null
                response.toString()
            } else {
                lastError = "HTTP $responseCode"
                null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            lastError = e.localizedMessage ?: e.message ?: "Unknown Exception"
            null
        } finally {
            connection?.disconnect() // Обязательно закрываем соединение
        }
    }

    /**
     * Создает (записывает) информацию о связывании (инвайт) в базу данных.
     * Вызывается тренером при генерации QR-кода.
     *
     * @param inviteCode Сам код привязки (например, "CP-A1B2C3").
     * @param coachId ID тренера.
     * @param cityId ID города.
     * @param cityName Название города.
     * @param groupId ID группы.
     * @param groupName Название группы.
     * @param studentId ID ученика.
     * @param studentName Имя и фамилия ученика.
     * @return true, если запись прошла успешно.
     */
    suspend fun createInvite(
        inviteCode: String,
        coachId: String,
        cityId: String,
        cityName: String,
        groupId: String,
        groupName: String,
        studentId: String,
        studentName: String
    ): Boolean {
        val info = InviteInfo(coachId, cityId, cityName, groupId, groupName, studentId, studentName)
        val body = jsonHelper.encodeToString(info)
        val url = "$BASE_URL/invites/$inviteCode.json"
        val response = makeHttpRequest(url, "PUT", body)
        return response != null
    }

    /**
     * Считывает с сервера информацию об инвайте по его коду привязки.
     * Вызывается учеником на экране ввода инвайт-кода для поиска своего тренера и группы.
     *
     * @param inviteCode Код привязки ("CP-XXXXXX").
     * @return Объект [InviteInfo] или null, если код не найден.
     */
    suspend fun getInvite(inviteCode: String): InviteInfo? {
        val url = "$BASE_URL/invites/$inviteCode.json"
        val response = makeHttpRequest(url, "GET") ?: return null
        if (response.isBlank() || response == "null") return null
        return try {
            jsonHelper.decodeFromString<InviteInfo>(response)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Отправляет (перезаписывает) список платежей конкретного ученика на сервер.
     *
     * @param coachId ID тренера.
     * @param studentId ID ученика.
     * @param payments Полный список платежей ученика.
     * @return true при успехе.
     */
    suspend fun pushPayments(
        coachId: String,
        studentId: String,
        payments: List<Payment>
    ): Boolean {
        val body = jsonHelper.encodeToString(payments)
        val url = "$BASE_URL/coaches/$coachId/students/$studentId/payments.json"
        val response = makeHttpRequest(url, "PUT", body)
        return response != null
    }

    /**
     * Загружает с сервера список платежей конкретного ученика.
     *
     * @param coachId ID тренера.
     * @param studentId ID ученика.
     * @return Список платежей [Payment] или null, если данные отсутствуют.
     */
    suspend fun pullPayments(
        coachId: String,
        studentId: String
    ): List<Payment>? {
        val url = "$BASE_URL/coaches/$coachId/students/$studentId/payments.json"
        val response = makeHttpRequest(url, "GET") ?: return null
        if (response.isBlank() || response == "null") return null
        return try {
            jsonHelper.decodeFromString<List<Payment>>(response)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Отправляет анкетные данные профиля ученика на сервер.
     *
     * @param coachId ID тренера.
     * @param studentId ID ученика.
     * @param birthDate Дата рождения ("YYYY-MM-DD").
     * @param height Рост.
     * @param weight Вес.
     * @param phone Номер телефона.
     * @return true при успехе.
     */
    suspend fun pushProfile(
        coachId: String,
        studentId: String,
        birthDate: String,
        height: String,
        weight: String,
        phone: String
    ): Boolean {
        @Serializable
        data class ProfileData(val birthDate: String, val height: String, val weight: String, val phone: String)
        val profile = ProfileData(birthDate, height, weight, phone)
        val body = jsonHelper.encodeToString(profile)
        val url = "$BASE_URL/coaches/$coachId/students/$studentId/profile.json"
        val response = makeHttpRequest(url, "PUT", body)
        return response != null
     }

    /**
     * Скачивает анкетные данные профиля ученика с сервера.
     *
     * @param coachId ID тренера.
     * @param studentId ID ученика.
     * @return Объект ответа [ProfileResponse].
     */
    suspend fun pullProfile(
        coachId: String,
        studentId: String
    ): ProfileResponse? {
        val url = "$BASE_URL/coaches/$coachId/students/$studentId/profile.json"
        val response = makeHttpRequest(url, "GET") ?: return null
        if (response.isBlank() || response == "null") return ProfileResponse("", "", "")
        return try {
            jsonHelper.decodeFromString<ProfileResponse>(response)
        } catch (e: Exception) {
            ProfileResponse("", "", "")
        }
    }

    /**
     * Отправляет расписание учебной группы на сервер.
     * Поддерживает как глобальное расписание, так и расписание на конкретную календарную неделю.
     *
     * @param coachId ID тренера.
     * @param groupId ID группы.
     * @param schedule Объект расписания [GroupSchedule] (список тренировок и разовых событий).
     * @param weekMonday Дата понедельника недели ("yyyy-MM-dd"), если сохраняется расписание конкретной недели.
     * @return true при успехе.
     */
    suspend fun pushSchedule(
        coachId: String,
        groupId: String,
        schedule: GroupSchedule,
        weekMonday: String? = null
    ): Boolean {
        val body = jsonHelper.encodeToString(schedule)
        val url = if (weekMonday == null) {
            "$BASE_URL/coaches/$coachId/groups/$groupId/schedule.json"
        } else {
            "$BASE_URL/coaches/$coachId/groups/$groupId/schedule_weeks/$weekMonday.json"
        }
        val response = makeHttpRequest(url, "PUT", body)
        return response != null
    }

    /**
     * Скачивает расписание учебной группы с сервера.
     *
     * @param coachId ID тренера.
     * @param groupId ID группы.
     * @param weekMonday Дата понедельника недели ("yyyy-MM-dd"), если скачивается расписание конкретной недели.
     * @return Расписание [GroupSchedule] или пустой объект, если расписания нет.
     */
    suspend fun pullSchedule(
        coachId: String,
        groupId: String,
        weekMonday: String? = null
    ): GroupSchedule? {
        val url = if (weekMonday == null) {
            "$BASE_URL/coaches/$coachId/groups/$groupId/schedule.json"
        } else {
            "$BASE_URL/coaches/$coachId/groups/$groupId/schedule_weeks/$weekMonday.json"
        }
        val response = makeHttpRequest(url, "GET") ?: return null
        if (response.isBlank() || response == "null") return GroupSchedule()
        return try {
            jsonHelper.decodeFromString<GroupSchedule>(response)
        } catch (e: Exception) {
            GroupSchedule()
        }
    }

    /**
     * Отправляет список активных тренировок для записи (букинга) в облако.
     */
    suspend fun pushBookings(coachId: String, groupId: String, bookings: List<BookingClass>): Boolean {
        val body = jsonHelper.encodeToString(bookings)
        val url = "$BASE_URL/coaches/$coachId/groups/$groupId/bookings.json"
        val response = makeHttpRequest(url, "PUT", body)
        return response != null
    }

    /**
     * Загружает список активных тренировок для записи (букинга) из облака.
     */
    suspend fun pullBookings(coachId: String, groupId: String): List<BookingClass>? {
        val url = "$BASE_URL/coaches/$coachId/groups/$groupId/bookings.json"
        val response = makeHttpRequest(url, "GET") ?: return null
        if (response.isBlank() || response == "null") return emptyList()
        return try {
            jsonHelper.decodeFromString<List<BookingClass>>(response)
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * Записывает в облако маппинг номера телефона на параметры привязки ученика.
     * Это позволяет связать телефон ученика с его карточкой в базе данных тренера без ввода инвайт-кода.
     *
     * @param phoneNumber Номер телефона (строка, отформатированная без лишних символов).
     */
    suspend fun createPhoneLink(
        phoneNumber: String,
        coachId: String,
        cityId: String,
        cityName: String,
        groupId: String,
        groupName: String,
        studentId: String,
        studentName: String
    ): Boolean {
        val info = InviteInfo(coachId, cityId, cityName, groupId, groupName, studentId, studentName)
        val body = jsonHelper.encodeToString(info)
        val url = "$BASE_URL/phones/$phoneNumber.json"
        val response = makeHttpRequest(url, "PUT", body)
        return response != null
    }

    /**
     * Ищет в облаке параметры привязки по номеру телефона.
     *
     * @param phoneNumber Номер телефона ученика/родителя.
     * @return Данные привязки [InviteInfo] или null, если телефон не привязан.
     */
    suspend fun getPhoneLink(phoneNumber: String): InviteInfo? {
        val url = "$BASE_URL/phones/$phoneNumber.json"
        val response = makeHttpRequest(url, "GET") ?: return null
        if (response.isBlank() || response == "null") return null
        return try {
            jsonHelper.decodeFromString<InviteInfo>(response)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Удаляет телефонную привязку с сервера.
     */
    suspend fun deletePhoneLink(phoneNumber: String): Boolean {
        val url = "$BASE_URL/phones/$phoneNumber.json"
        val response = makeHttpRequest(url, "DELETE")
        return response != null
    }

    /**
     * Выполняет авторизацию в Firebase Auth по токену Google ID Token.
     * Обменивает токен Google на пару: сессионный токен Firebase (idToken) и токен обновления (refreshToken).
     *
     * @param apiKey API-ключ проекта Firebase (вкладка Settings в консоли Firebase).
     * @param googleIdToken ID токен, полученный от Google Sign-In SDK.
     * @return Объект ответа [FirebaseAuthResponse] при успехе.
     */
    suspend fun signInWithFirebaseOAuth(
        apiKey: String,
        googleIdToken: String
    ): FirebaseAuthResponse? = withContext(Dispatchers.IO) {
        val url = "$IDENTITY_URL?key=$apiKey"
        val payload = """
            {
                "postBody": "id_token=$googleIdToken&providerId=google.com",
                "requestUri": "http://localhost",
                "returnIdpCredential": true,
                "returnSecureToken": true
            }
        """.trimIndent()
        
        val response = makeHttpRequest(url, "POST", payload) ?: return@withContext null
        try {
            jsonHelper.decodeFromString<FirebaseAuthResponse>(response)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Обновляет истекший сессионный токен Firebase (срок его жизни - 1 час) по Refresh токену.
     * Запрос посылается в формате x-www-form-urlencoded.
     *
     * @param apiKey API-ключ проекта Firebase.
     * @param refreshToken Токен обновления сессии.
     * @return Декодированный ответ [FirebaseRefreshTokenResponse] или null.
     */
    suspend fun refreshFirebaseToken(
        apiKey: String,
        refreshToken: String
    ): FirebaseRefreshTokenResponse? = withContext(Dispatchers.IO) {
        val url = "$SECURE_TOKEN_URL?key=$apiKey"
        val payload = "grant_type=refresh_token&refresh_token=$refreshToken"
        
        var connection: HttpURLConnection? = null
        try {
            val u = URL(url)
            connection = u.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.connectTimeout = 5000
            connection.readTimeout = 5000
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            connection.doOutput = true
            
            val writer = OutputStreamWriter(connection.outputStream, "UTF-8")
            writer.write(payload)
            writer.flush()
            writer.close()
            
            val responseCode = connection.responseCode
            if (responseCode == HttpURLConnection.HTTP_OK) {
                val stream = connection.inputStream
                val reader = BufferedReader(InputStreamReader(stream, "UTF-8"))
                val response = StringBuilder()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    response.append(line)
                }
                reader.close()
                jsonHelper.decodeFromString<FirebaseRefreshTokenResponse>(response.toString())
            } else {
                null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        } finally {
            connection?.disconnect()
        }
    }

    /**
     * Считывает глобальный профиль пользователя из таблицы /users/ в Firebase по его UID.
     */
    suspend fun getUserProfile(uid: String): UserProfile? {
        val url = "$BASE_URL/users/$uid.json"
        val response = makeHttpRequest(url, "GET") ?: return null
        if (response.isBlank() || response == "null") return null
        return try {
            jsonHelper.decodeFromString<UserProfile>(response)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Сохраняет или обновляет глобальный профиль пользователя в таблице /users/ в Firebase по его UID.
     */
    suspend fun saveUserProfile(uid: String, profile: UserProfile): Boolean {
        val body = jsonHelper.encodeToString(profile)
        val url = "$BASE_URL/users/$uid.json"
        val response = makeHttpRequest(url, "PUT", body)
        return response != null
    }

    /**
     * Отправляет всю структуру данных тренера (города, группы, ученики, настройки) в облако.
     */
    suspend fun pushCoachData(
        coachId: String,
        coachData: CoachData
    ): Boolean {
        val body = jsonHelper.encodeToString(coachData)
        val url = "$BASE_URL/coaches/$coachId/coachData.json"
        println("[SyncManager] pushCoachData: coachId=$coachId, URL=$url")
        val response = makeHttpRequest(url, "PUT", body)
        println("[SyncManager] pushCoachData response: ${if (response != null) "SUCCESS" else "FAIL"}")
        return response != null
    }

    /**
     * Загружает всю структуру данных тренера из облака.
     */
    suspend fun pullCoachData(
        coachId: String
    ): CoachData? {
        val url = "$BASE_URL/coaches/$coachId/coachData.json"
        println("[SyncManager] pullCoachData: coachId=$coachId, URL=$url")
        val response = makeHttpRequest(url, "GET")
        if (response == null) {
            println("[SyncManager] pullCoachData response: FAIL (null)")
            return null
        }
        if (response.isBlank() || response == "null") {
            println("[SyncManager] pullCoachData response: EMPTY ($response)")
            return null
        }
        return try {
            val data = jsonHelper.decodeFromString<CoachData>(response)
            println("[SyncManager] pullCoachData response: SUCCESS, cities count=${data.cities.size}")
            data
        } catch (e: Exception) {
            println("[SyncManager] pullCoachData response: JSON DECODE ERROR: ${e.message}")
            e.printStackTrace()
            null
        }
    }
}

/**
 * Объект ответа сервера, содержащий скачанные анкетные данные ученика.
 */
@Serializable
data class ProfileResponse(
    val birthDate: String = "",
    val height: String = "",
    val weight: String = "",
    val phone: String = ""
)

/**
 * Объект ответа сервера Firebase Auth REST API при успешном входе.
 */
@Serializable
data class FirebaseAuthResponse(
    val localId: String,       // Уникальный UID пользователя в Firebase Auth
    val email: String? = null, // Email вошедшего Google-аккаунта
    val idToken: String,       // ID Token для подписи запросов к базе данных
    val refreshToken: String,  // Refresh Token для продления сессии
    val expiresIn: String      // Срок жизни idToken в секундах (обычно "3600")
)

/**
 * Объект ответа сервера Firebase Auth REST API при успешном обновлении токена.
 */
@Serializable
data class FirebaseRefreshTokenResponse(
    val id_token: String,      // Новый ID Token
    val refresh_token: String,  // Новый Refresh Token
    val expires_in: String,     // Срок действия нового токена в секундах
    val user_id: String        // UID пользователя
)
