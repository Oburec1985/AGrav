package ru.oburec.coachpay.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Premium UI Colors
val PrimaryDark = Color(0xFF0F172A) // Dark slate
val CardDark = Color(0xFF1E293B) // Dark slate card
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val AccentColor = Color(0xFF38BDF8) // Sky blue
val SuccessGreen = Color(0xFF4ADE80)
val ErrorRed = Color(0xFFF87171)
val WarningYellow = Color(0xFFFBBF24)
val GridBackground = Color(0xFF0F172A)
