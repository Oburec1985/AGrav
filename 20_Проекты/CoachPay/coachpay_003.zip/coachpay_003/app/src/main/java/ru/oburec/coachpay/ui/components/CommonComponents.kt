package ru.oburec.coachpay.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.oburec.coachpay.ui.utils.MonthUtils

/**
 * EmptyStatePlaceholder — компонент-заглушка для пустого состояния.
 * Показывается по центру экрана, когда список элементов (например, городов или учеников) пуст.
 *
 * Пример использования:
 * if (list.isEmpty()) {
 *     EmptyStatePlaceholder("Список городов пуст.\nНажмите '+' для добавления.")
 * }
 *
 * @param text Сообщение, которое будет выведено по центру экрана (например, "Нет учеников").
 */
@Composable
fun EmptyStatePlaceholder(text: String) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            fontSize = 16.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(32.dp)
        )
    }
}

/**
 * ItemCard — стандартная карточка элемента структуры (города или группы).
 * Содержит название, дополнительный текст (описание или количество) и две кнопки действий справа (редактирование и удаление).
 *
 * Пример использования:
 * ItemCard(
 *     title = "Москва",
 *     subtitle = "Групп: 3",
 *     onCardClick = { openCityGroups(city.id) },
 *     onEditClick = { startEdit(city) },
 *     onDeleteClick = { deleteCity(city.id) }
 * )
 *
 * @param title Основной текст (название города или группы).
 * @param subtitle Подзаголовок (например, количество групп или учеников).
 * @param onCardClick Обработчик нажатия на саму карточку.
 * @param onEditClick Обработчик нажатия на иконку «Карандаш» (редактировать).
 * @param onDeleteClick Обработчик нажатия на иконку «Корзина» (удалить).
 */
@Composable
fun ItemCard(
    title: String,
    subtitle: String,
    onCardClick: () -> Unit,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF1E293B) // Темно-серый цвет фона карточки
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onCardClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Левая колонка с текстами
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    fontSize = 14.sp,
                    color = Color.Gray
                )
            }
            
            // Правый контейнер с кнопками действий
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Кнопка редактирования
                IconButton(onClick = onEditClick) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Редактировать",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                // Кнопка удаления
                IconButton(onClick = onDeleteClick) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Удалить",
                        tint = Color(0xFFEF4444) // Красный цвет
                    )
                }
            }
        }
    }
}

/**
 * MonthSelector — горизонтальная панель для переключения текущего выбранного месяца оплат.
 * Содержит кнопку «Назад», название месяца по центру и кнопку «Вперед».
 * Имеет поддержку границ (минимума и максимума) — кнопки будут блокироваться при достижении лимитов.
 *
 * Пример использования:
 * MonthSelector(
 *     selectedMonth = "2026-06",
 *     minMonth = "2026-01",
 *     maxMonth = "2026-07",
 *     onMonthChange = { newMonth -> selectedMonth = newMonth }
 * )
 *
 * @param selectedMonth Текущий выбранный месяц в формате "YYYY-MM" (например, "2026-06").
 * @param minMonth Минимальный доступный месяц для выбора (если пустой — ограничения нет).
 * @param maxMonth Максимальный доступный месяц для выбора (если пустой — ограничения нет).
 * @param onMonthChange Колбек, вызываемый при успешном переключении месяца. Передает новую строку "YYYY-MM".
 */
@Composable
fun MonthSelector(
    selectedMonth: String,
    minMonth: String = "",
    maxMonth: String = "",
    onMonthChange: (String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF1E293B)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Проверка: заблокирована ли кнопка «Назад»
            val isPrevDisabled = minMonth.isNotEmpty() && selectedMonth <= minMonth
            
            // Кнопка переключения на предыдущий месяц
            IconButton(
                onClick = {
                    if (!isPrevDisabled) {
                        onMonthChange(MonthUtils.adjustMonth(selectedMonth, -1))
                    }
                },
                enabled = !isPrevDisabled
            ) {
                Icon(
                    imageVector = Icons.Default.ChevronLeft,
                    contentDescription = "Предыдущий месяц",
                    tint = if (isPrevDisabled) Color.Gray else Color.White
                )
            }

            // Текстовое название месяца (например, "Июнь 2026")
            Text(
                text = MonthUtils.formatMonthDisplay(selectedMonth),
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            // Проверка: заблокирована ли кнопка «Вперед»
            val isNextDisabled = maxMonth.isNotEmpty() && selectedMonth >= maxMonth
            
            // Кнопка переключения на следующий месяц
            IconButton(
                onClick = {
                    if (!isNextDisabled) {
                        onMonthChange(MonthUtils.adjustMonth(selectedMonth, 1))
                    }
                },
                enabled = !isNextDisabled
            ) {
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Следующий месяц",
                    tint = if (isNextDisabled) Color.Gray else Color.White
                )
            }
        }
    }
}
