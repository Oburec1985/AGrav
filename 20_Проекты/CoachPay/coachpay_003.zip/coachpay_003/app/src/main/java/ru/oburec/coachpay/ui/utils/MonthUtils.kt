package ru.oburec.coachpay.ui.utils

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.Date

/**
 * Объект MonthUtils предоставляет набор утилит для работы с календарем, датами и строковыми масками.
 * Помогает приводить даты к единым форматам ("YYYY-MM", "YYYY-MM-DD"), выполнять арифметику над месяцами и неделями,
 * а также подготавливать красивые текстовые представления дат на русском языке для вывода в интерфейсе.
 */
object MonthUtils {

    /**
     * Сдвигает строковое представление месяца "YYYY-MM" на заданную величину месяцев назад или вперед.
     *
     * Пример использования:
     * val nextMonth = MonthUtils.adjustMonth("2026-06", 1) // Результат: "2026-07"
     * val prevMonth = MonthUtils.adjustMonth("2026-06", -1) // Результат: "2026-05"
     *
     * @param currentMonth Строка текущего месяца в формате "YYYY-MM" (например, "2026-06").
     * @param delta Число месяцев, на которое нужно сдвинуть (положительное для будущего, отрицательное для прошлого).
     * @return Новая строка месяца в формате "YYYY-MM".
     */
    fun adjustMonth(currentMonth: String, delta: Int): String {
        try {
            val sdf = SimpleDateFormat("yyyy-MM", Locale.US)
            val date = sdf.parse(currentMonth) ?: Date()
            val cal = Calendar.getInstance()
            cal.time = date
            cal.add(Calendar.MONTH, delta)
            return sdf.format(cal.time)
        } catch (e: Exception) {
            return currentMonth // В случае ошибки парсинга возвращаем исходную строку
        }
    }

    /**
     * Форматирует месяц в сокращенное русское название с заглавной буквы.
     *
     * Пример использования:
     * val label = MonthUtils.formatMonthShort("2026-06") // Результат: "Июн"
     *
     * @param monthStr Строка месяца в формате "YYYY-MM".
     * @return Сокращенное название месяца на русском языке (например, "Янв", "Июн").
     */
    fun formatMonthShort(monthStr: String): String {
        try {
            val sdfInput = SimpleDateFormat("yyyy-MM", Locale.US)
            val sdfOutput = SimpleDateFormat("MMM", Locale("ru"))
            val date = sdfInput.parse(monthStr) ?: return monthStr
            return sdfOutput.format(date).replaceFirstChar { it.uppercase() }
        } catch (e: Exception) {
            return monthStr
        }
    }

    /**
     * Форматирует месяц в полное отображаемое имя на русском языке с указанием года.
     *
     * Пример использования:
     * val label = MonthUtils.formatMonthDisplay("2026-06") // Результат: "Июнь 2026"
     *
     * @param monthStr Строка месяца в формате "YYYY-MM".
     * @return Полное название месяца и года на русском языке (например, "Июнь 2026").
     */
    fun formatMonthDisplay(monthStr: String): String {
        try {
            val sdfInput = SimpleDateFormat("yyyy-MM", Locale.US)
            val sdfOutput = SimpleDateFormat("LLLL yyyy", Locale("ru"))
            val date = sdfInput.parse(monthStr) ?: return monthStr
            return sdfOutput.format(date).replaceFirstChar { it.uppercase() }
        } catch (e: Exception) {
            return monthStr
        }
    }

    /**
     * Форматирует ввод пользователя, добавляя маску точки для месяца и года (MM.YY).
     * Автоматически вставляет точку после первых двух цифр.
     *
     * Пример использования:
     * val display = MonthUtils.formatInputDateWithMask("0626") // Результат: "06.26"
     *
     * @param input Произвольная строка, введенная пользователем (например, "062").
     * @return Отформатированная строка с точкой-разделителем (например, "06.2").
     */
    fun formatInputDateWithMask(input: String): String {
        val digits = input.filter { it.isDigit() }.take(4) // Оставляем только первые 4 цифры
        return when {
            digits.length > 2 -> "${digits.substring(0, 2)}.${digits.substring(2)}"
            else -> digits
        }
    }

    /**
     * Преобразует строковый формат "YYYY-MM" в маску отображения "MM.YY" для сокращенного вывода.
     *
     * Пример использования:
     * val mask = MonthUtils.formatYearMonthToMaskDate("2026-05") // Результат: "05.26"
     *
     * @param ym Строка года и месяца в формате базы данных "YYYY-MM" (например, "2026-05").
     * @return Строка маски в формате "MM.YY" (например, "05.26").
     */
    fun formatYearMonthToMaskDate(ym: String): String {
        if (ym.length != 7 || ym[4] != '-') return ym
        val year = ym.substring(2, 4)
        val month = ym.substring(5, 7)
        return "$month.$year"
    }

    /**
     * Парсит маску ввода "MM.YY" обратно в системный формат сохранения "YYYY-MM".
     *
     * Пример использования:
     * val ym = MonthUtils.parseMaskDateToYearMonth("06.26", "2026-01") // Результат: "2026-06"
     *
     * @param mask Строка маски "MM.YY", введенная пользователем.
     * @param defaultYm Значение по умолчанию, возвращаемое при ошибке парсинга.
     * @return Строка года и месяца в формате "YYYY-MM" (например, "2026-06").
     */
    fun parseMaskDateToYearMonth(mask: String, defaultYm: String): String {
        if (mask.length != 5 || mask[2] != '.') return defaultYm
        val month = mask.substring(0, 2)
        val year = "20" + mask.substring(3, 5)
        return "$year-$month"
    }

    /**
     * Форматирует ввод пользователя для даты, добавляя точки-разделители ДД.ММ.ГГ.
     *
     * Пример использования:
     * val mask = MonthUtils.formatDateWithMask("150626") // Результат: "15.06.26"
     *
     * @param input Сырая строка с цифрами.
     * @return Отформатированная строка с разделителями (например, "15.06.2").
     */
    fun formatDateWithMask(input: String): String {
        val digits = input.filter { it.isDigit() }.take(6)
        return when {
            digits.length > 4 -> "${digits.substring(0, 2)}.${digits.substring(2, 4)}.${digits.substring(4)}"
            digits.length > 2 -> "${digits.substring(0, 2)}.${digits.substring(2)}"
            else -> digits
        }
    }

    /**
     * Форматирует ввод пользователя для времени, добавляя двоеточие ЧЧ:ММ.
     *
     * Пример использования:
     * val time = MonthUtils.formatTimeWithMask("1800") // Результат: "18:00"
     *
     * @param input Вводимые цифры времени.
     * @return Строка времени с двоеточием (например, "18:0").
     */
    fun formatTimeWithMask(input: String): String {
        val digits = input.filter { it.isDigit() }.take(4)
        return when {
            digits.length > 2 -> "${digits.substring(0, 2)}:${digits.substring(2)}"
            else -> digits
        }
    }

    /**
     * Вычисляет время окончания занятия на основе времени начала и длительности в часах.
     *
     * Пример использования:
     * val end = MonthUtils.calculateEndTime("18:30", 1.5) // Результат: "20:00"
     *
     * @param startTime Время начала в формате "HH:MM".
     * @param durationHours Длительность тренировки в часах (например, 1.5 для полутора часов).
     * @return Время окончания в формате "HH:MM".
     */
    fun calculateEndTime(startTime: String, durationHours: Double): String {
        try {
            val parts = startTime.split(":")
            if (parts.size != 2) return startTime
            val hour = parts[0].toIntOrNull() ?: return startTime
            val minute = parts[1].toIntOrNull() ?: return startTime
            
            val totalMinutes = hour * 60 + minute + (durationHours * 60).toInt()
            val endHour = (totalMinutes / 60) % 24
            val endMinute = totalMinutes % 60
            return String.format(Locale.US, "%02d:%02d", endHour, endMinute)
        } catch (e: Exception) {
            return startTime
        }
    }

    /**
     * Вычисляет длительность занятия в часах на основе времени начала и окончания.
     *
     * Пример использования:
     * val duration = MonthUtils.calculateDuration("18:00", "19:30") // Результат: 1.5
     *
     * @param startTime Время начала в формате "HH:MM".
     * @param endTime Время окончания в формате "HH:MM".
     * @return Длительность в часах в виде вещественного числа Double.
     */
    fun calculateDuration(startTime: String, endTime: String): Double {
        try {
            val startParts = startTime.split(":")
            val endParts = endTime.split(":")
            if (startParts.size != 2 || endParts.size != 2) return 1.0
            val startH = startParts[0].toIntOrNull() ?: return 1.0
            val startM = startParts[1].toIntOrNull() ?: return 1.0
            val endH = endParts[0].toIntOrNull() ?: return 1.0
            val endM = endParts[1].toIntOrNull() ?: return 1.0
            
            var diffMinutes = (endH * 60 + endM) - (startH * 60 + startM)
            if (diffMinutes < 0) {
                // Если тренировка заканчивается на следующий день
                diffMinutes += 24 * 60
            }
            return diffMinutes / 60.0
        } catch (e: Exception) {
            return 1.0
        }
    }

    /**
     * Возвращает дату понедельника недели с заданным смещением (delta) от текущей недели.
     * Метод не зависит от локали устройства (всегда считает понедельник первым днем недели).
     *
     * Пример использования:
     * val thisMonday = MonthUtils.getMondayOfWeek(0)   // Получить понедельник текущей недели (например, "2026-06-15")
     * val nextMonday = MonthUtils.getMondayOfWeek(1)   // Получить понедельник следующей недели (например, "2026-06-22")
     * val prevMonday = MonthUtils.getMondayOfWeek(-1)  // Получить понедельник предыдущей недели (например, "2026-06-08")
     *
     * @param delta Смещение в неделях относительно текущей системной даты.
     * @return Дата понедельника в формате базы данных "yyyy-MM-dd".
     */
    fun getMondayOfWeek(delta: Int): String {
        try {
            val cal = Calendar.getInstance()
            val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
            // В Calendar.SUNDAY = 1, MONDAY = 2, ..., SATURDAY = 7
            // Вычисляем, сколько дней нужно вычесть до понедельника текущей недели
            val daysToSubtract = if (dayOfWeek == Calendar.SUNDAY) 6 else dayOfWeek - Calendar.MONDAY
            cal.add(Calendar.DAY_OF_YEAR, -daysToSubtract)
            cal.add(Calendar.WEEK_OF_YEAR, delta)
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            return sdf.format(cal.time)
        } catch (e: Exception) {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            return sdf.format(Date())
        }
    }

    /**
     * Форматирует диапазон недели (с понедельника по воскресенье) для отображения на русском языке.
     *
     * Пример использования:
     * val range = MonthUtils.formatWeekRange("2026-06-15") // Результат: "15.06 - 21.06"
     *
     * @param mondayStr Дата понедельника в формате "yyyy-MM-dd".
     * @return Красивая строка диапазона дат недели (например, "15.06 - 21.06").
     */
    fun formatWeekRange(mondayStr: String): String {
        try {
            val sdfInput = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val date = sdfInput.parse(mondayStr) ?: return mondayStr
            val cal = Calendar.getInstance(Locale.US)
            cal.time = date
            
            val sdfOutput = SimpleDateFormat("dd.MM", Locale("ru"))
            val mondayFormatted = sdfOutput.format(cal.time)
            
            cal.add(Calendar.DAY_OF_YEAR, 6) // Прибавляем 6 дней, чтобы получить воскресенье
            val sundayFormatted = sdfOutput.format(cal.time)
            
            return "$mondayFormatted - $sundayFormatted"
        } catch (e: Exception) {
            return mondayStr
        }
    }
}
