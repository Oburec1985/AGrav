package ru.oburec.coachpay.model

import kotlinx.serialization.Serializable
import java.util.UUID

/**
 * Роли пользователей в приложении.
 */
enum class AppRole {
    COACH,      // Тренер (управляет городами, группами, учениками, подтверждает оплаты)
    STUDENT,    // Ученик / Родитель (видит свои оплаты, расписание, отправляет отчеты об оплате)
    UNDEFINED   // Роль не выбрана (экран первоначального выбора роли при запуске)
}

/**
 * Возможные статусы платежа.
 */
enum class PaymentState {
    PAID,             // Оплачено (подтверждено тренером, зеленая галочка)
    UNPAID,           // Не оплачено (создано автоматически или вручную, долг)
    PENDING_APPROVAL  // Ожидает проверки (ученик отметил «Я оплатил», ожидает действия тренера)
}

/**
 * Модель индивидуального платежа ученика.
 * Это может быть как ежемесячный абонемент, так и разовые целевые сборы (форма, соревнования и др.).
 */
@Serializable
data class Payment(
    val id: String = UUID.randomUUID().toString(), // Уникальный идентификатор платежа
    val amount: Double,                           // Сумма платежа в рублях
    val month: String,                            // Месяц начисления в формате "YYYY-MM" (например, "2026-06")
    val state: PaymentState = PaymentState.UNPAID, // Статус платежа (по умолчанию UNPAID)
    val createdAt: Long = System.currentTimeMillis(), // Таймстамп времени создания (в миллисекундах)
    val confirmedAt: Long? = null,                // Таймстамп времени подтверждения оплаты тренером
    val title: String = "Абонемент"                // Название сбора (например, "Абонемент за июнь" или "Турнир")
)

/**
 * Регулярное занятие в расписании (повторяющееся каждую неделю).
 */
@Serializable
data class WeeklyClass(
    val id: String = UUID.randomUUID().toString(), // Уникальный идентификатор занятия
    val dayOfWeek: String,                         // День недели (например, "Понедельник")
    val time: String,                              // Время начала тренировки (для обратной совместимости, например "18:00")
    val location: String = "",                     // Адрес зала / место проведения
    val startTime: String = "",                    // Точное время начала (например, "18:00")
    val endTime: String = ""                       // Точное время окончания (например, "19:30")
)

/**
 * Разовое событие (например, семинар, аттестация, праздник), не повторяющееся еженедельно.
 */
@Serializable
data class GroupEvent(
    val id: String = UUID.randomUUID().toString(), // Уникальный идентификатор события
    val title: String,                             // Название события
    val date: String,                              // Дата события в формате "YYYY-MM-DD"
    val time: String                               // Время начала события в формате "HH:MM"
)

/**
 * Расписание группы на конкретную календарную неделю.
 * Объединяет еженедельные занятия и разовые события, приходящиеся на эту неделю.
 */
@Serializable
data class GroupSchedule(
    val weeklySchedule: List<WeeklyClass> = emptyList(), // Список регулярных еженедельных тренировок
    val oneOffEvents: List<GroupEvent> = emptyList()      // Список разовых событий на этой неделе
)

/**
 * Модель ученика спортивной секции.
 * Хранит персональные данные, параметры абонемента и всю историю платежей ученика.
 */
@Serializable
data class Student(
    val id: String = UUID.randomUUID().toString(), // Уникальный идентификатор ученика
    val firstName: String,                         // Имя ученика
    val lastName: String,                          // Фамилия ученика
    val payments: List<Payment> = emptyList(),     // Список всех начислений и платежей ученика
    val monthlyFee: Double = 3000.0,               // Стоимость ежемесячного абонемента по умолчанию
    val joinMonth: String = "",                    // Месяц, когда ученик начал посещать секцию ("YYYY-MM")
    val birthDate: String = "",                    // Дата рождения ("YYYY-MM-DD")
    val height: String = "",                       // Рост ученика
    val weight: String = "",                       // Вес ученика
    val phone: String = ""                         // Номер телефона родителя/ученика для связи и авторизации
)

/**
 * Тарифное правило стоимости посещения группового занятия.
 * Используется для расчета стоимости тренировки с записью (bookings) в зависимости от числа записавшихся.
 */
@Serializable
data class BookingPriceRule(
    val attendeesCount: Int,      // Количество записавшихся человек
    val pricePerPerson: Double    // Стоимость посещения для одного человека при таком количестве участников
)

/**
 * Занятие с возможностью записи (букинга) для учеников.
 */
@Serializable
data class BookingClass(
    val id: String = UUID.randomUUID().toString(), // Уникальный идентификатор занятия для записи
    val title: String,                             // Название занятия
    val date: String,                              // Дата занятия ("YYYY-MM-DD")
    val time: String,                              // Время проведения ("HH:MM")
    val maxCapacity: Int,                          // Максимальное количество участников
    val attendees: List<String> = emptyList(),     // Список [studentId] учеников, которые записались на это занятие
    val priceRules: List<BookingPriceRule> = emptyList() // Тарифная сетка для гибкого расчета стоимости
)

/**
 * Модель учебной группы/класса внутри города.
 */
@Serializable
data class StudentGroup(
    val id: String = UUID.randomUUID().toString(),    // Уникальный идентификатор группы
    val name: String,                                 // Название группы (например, "Старшая группа")
    val students: List<Student> = emptyList(),        // Список учеников, входящих в данную группу
    val defaultMonthlyFee: Double = 3000.0,           // Базовый тариф абонемента для новых учеников группы
    val weeklySchedule: List<WeeklyClass> = emptyList(), // Общее недельное расписание группы по умолчанию
    val oneOffEvents: List<GroupEvent> = emptyList(),    // Общие разовые события группы
    val schedulesByWeek: Map<String, GroupSchedule> = emptyMap(), // Индивидуальные расписания, сохраненные по неделям ("YYYY-Wxx")
    val bookings: List<BookingClass> = emptyList()     // Список тренировок с записью (букинг-система)
)

/**
 * Модель города (верхний уровень структуры тренера).
 */
@Serializable
data class City(
    val id: String = UUID.randomUUID().toString(), // Уникальный идентификатор города
    val name: String,                              // Название города (например, "Москва")
    val groups: List<StudentGroup> = emptyList()   // Список групп в этом городе
)

/**
 * Неподтвержденный платеж, пришедший от ученика.
 * Используется в облаке для сбора информации от учеников до того, как тренер подтвердит оплату.
 */
@Serializable
data class PendingPayment(
    val id: String = UUID.randomUUID().toString(), // Уникальный идентификатор платежа
    val studentId: String? = null,                 // Идентификатор ученика
    val studentName: String,                       // Фамилия и Имя ученика
    val cityName: String,                          // Название города
    val groupName: String,                         // Название группы
    val amount: Double,                            // Сумма перевода
    val month: String,                             // За какой месяц ("YYYY-MM")
    val timestamp: Long = System.currentTimeMillis() // Время отправки отчета
)

/**
 * Общая структура данных тренера.
 * Хранит города и накопившиеся неподтвержденные платежи.
 */
@Serializable
data class CoachData(
    val coachId: String = UUID.randomUUID().toString().substring(0, 8).uppercase(), // Короткий уникальный ID тренера (инвайт-код)
    val cities: List<City> = emptyList(),                                          // Список городов
    val pendingPayments: List<PendingPayment> = emptyList()                        // Список заявок на оплату от учеников
)

/**
 * Конфигурация и данные, скачиваемые на устройство ученика (родителя) после привязки.
 */
@Serializable
data class StudentConfig(
    val coachId: String = "",                // ID тренера, к которому привязан ученик
    val cityName: String = "",               // Название города
    val groupName: String = "",              // Название группы
    val firstName: String = "",              // Имя ученика
    val lastName: String = "",               // Фамилия ученика
    val studentId: String? = null,           // Идентификатор ученика в базе тренера
    val payments: List<Payment> = emptyList(), // Список платежей ученика (синхронизируется из базы тренера)
    val inviteCode: String = "",             // Код привязки, по которому выполнена привязка
    val birthDate: String = "",              // Дата рождения
    val height: String = "",                 // Рост
    val weight: String = "",                 // Вес
    val phone: String = "",                  // Телефон
    val cityId: String = "",                 // ID города
    val groupId: String = "",                // ID группы
    val weeklySchedule: List<WeeklyClass> = emptyList(), // Расписание группы по умолчанию
    val oneOffEvents: List<GroupEvent> = emptyList(),    // Разовые события группы
    val schedulesByWeek: Map<String, GroupSchedule> = emptyMap(), // Сетки расписания по неделям
    val bookings: List<BookingClass> = emptyList()     // Записи на занятия
)

/**
 * Корневое состояние всего приложения.
 * Сериализуется в локальный файл app_state.json.
 */
@Serializable
data class AppState(
    val role: AppRole = AppRole.UNDEFINED,            // Текущая роль пользователя
    val coachData: CoachData? = null,                // Данные тренера (null, если роль не COACH)
    val studentConfig: StudentConfig? = null,        // Данные ученика (null, если роль не STUDENT)
    val firebaseToken: String = "",                  // ID Token Firebase Auth для доступа к Realtime DB
    val refreshToken: String = "",                   // Токен обновления сессии Firebase Auth
    val tokenExpiryTime: Long = 0L,                  // Таймстамп окончания действия токена (в миллисекундах)
    val googleEmail: String = "",                    // Email вошедшего Google-аккаунта
    val firebaseApiKey: String = "",                 // API-ключ Firebase проекта тренера
    val googleClientId: String = "",                 // Идентификатор OAuth клиента Google
    val firebaseUid: String = "",                    // Уникальный ID пользователя в Firebase Auth
    val lastSyncTime: Long = 0L                      // Таймстамп последней успешной сетевой синхронизации
)

/**
 * Профиль пользователя для хранения в глобальном индексе пользователей в Firebase.
 * Помогает привязать ученика к тренеру по номеру телефона.
 */
@Serializable
data class UserProfile(
    val uid: String,
    val email: String? = null,
    val role: String,
    val coachId: String = "",
    val cityId: String = "",
    val cityName: String = "",
    val groupId: String = "",
    val groupName: String = "",
    val studentId: String = "",
    val studentName: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
