package ru.oburec.coachpay

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.oburec.coachpay.data.StorageManager
import ru.oburec.coachpay.model.AppRole
import ru.oburec.coachpay.ui.components.*
import ru.oburec.coachpay.ui.screens.*
import ru.oburec.coachpay.ui.theme.CoachPayTheme
import ru.oburec.coachpay.ui.utils.MonthUtils
import ru.oburec.coachpay.viewmodel.AppStateViewModel

/**
 * Главное активити приложения CoachPay.
 * Инициализирует StorageManager для локального хранения в JSON и AppStateViewModel для бизнес-логики.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val storageManager = StorageManager(filesDir)
        val viewModel = AppStateViewModel(storageManager)

        val resIdClientId = resources.getIdentifier("default_web_client_id", "string", packageName)
        val defaultClientId = if (resIdClientId != 0) getString(resIdClientId) else "843242825865-ml3ikgp1t7290mk3vav7hp5h824a1qqr.apps.googleusercontent.com"

        val resIdApiKey = resources.getIdentifier("google_api_key", "string", packageName)
        val defaultApiKey = if (resIdApiKey != 0) getString(resIdApiKey) else "AIzaSyCCy_iHK23qwNeH0J665RmbJ9OO0zwQZwI"

        viewModel.loadState(defaultClientId = defaultClientId, defaultApiKey = defaultApiKey)

        setContent {
            CoachPayTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    CoachPayApp(viewModel)
                }
            }
        }
    }
}

/**
 * Sealed-класс экранов навигации.
 * Обеспечивает простую ручную навигацию без использования громоздких внешних библиотек.
 */
sealed class Screen {
    object RoleSelection : Screen()
    object Cities : Screen()
    data class Groups(val cityId: String, val cityName: String) : Screen()
    data class Students(val cityId: String, val groupId: String, val groupName: String) : Screen()
    data class Bookings(val cityId: String, val groupId: String, val groupName: String) : Screen()
    object StudentCabinet : Screen()
}

/**
 * Главный контейнер приложения, управляющий навигацией, верхней панелью и диалогами.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CoachPayApp(viewModel: AppStateViewModel) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current // Получаем текущий контекст для работы с буфером обмена и Toast
    
    // Переменная текущего открытого экрана
    var currentScreen by remember { mutableStateOf<Screen>(Screen.RoleSelection) }

    // Переменная текущего выбранного месяца в календаре оплат (по умолчанию - текущий реальный месяц)
    val currentYearMonth = remember {
        val sdf = java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.US)
        sdf.format(java.util.Date())
    }
    var selectedMonth by remember { mutableStateOf(currentYearMonth) }

    // Автоматическая навигация в зависимости от роли
    LaunchedEffect(state.role) {
        currentScreen = when (state.role) {
            AppRole.UNDEFINED -> Screen.RoleSelection
            AppRole.COACH -> Screen.Cities
            AppRole.STUDENT -> Screen.StudentCabinet
        }
    }

    // Состояния для диалогов структуры (Город, Группа)
    var showAddCityDialog by remember { mutableStateOf(false) }
    var cityToEdit by remember { mutableStateOf<Pair<String, String>?>(null) } // id, name

    var showAddGroupDialog by remember { mutableStateOf(false) }
    var groupToEdit by remember { mutableStateOf<Triple<String, String, Double>?>(null) } // id, name, defaultFee

    // Состояния для диалогов оплат
    var showAddStudentDialog by remember { mutableStateOf(false) }
    var showGroupPaymentDialog by remember { mutableStateOf(false) } // Флаг диалога групповых сборов
    var showScheduleDialog by remember { mutableStateOf(false) } // Флаг диалога расписания группы
    var showCloudSettingsDialog by remember { mutableStateOf(false) }

    // Информационный диалог QR/инвайт-кода
    var showLinkCodeDialog by remember { mutableStateOf(false) }
    var generatedLinkCode by remember { mutableStateOf("") }
    var linkStudentName by remember { mutableStateOf("") }

    // Настройка Google Sign-In клиента
    val googleSignInClient = remember(state.googleClientId) {
        val gso = com.google.android.gms.auth.api.signin.GoogleSignInOptions.Builder(
            com.google.android.gms.auth.api.signin.GoogleSignInOptions.DEFAULT_SIGN_IN
        )
            .requestIdToken(state.googleClientId.ifEmpty { "123456-dummy.apps.googleusercontent.com" })
            .requestEmail()
            .build()
        com.google.android.gms.auth.api.signin.GoogleSignIn.getClient(context, gso)
    }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val task = com.google.android.gms.auth.api.signin.GoogleSignIn.getSignedInAccountFromIntent(result.data)
            try {
                val account = task.getResult(com.google.android.gms.common.api.ApiException::class.java)
                val idToken = account?.idToken
                val email = account?.email ?: ""
                if (idToken != null) {
                    viewModel.completeGoogleSignIn(idToken, email) { success, error ->
                        if (success) {
                            android.widget.Toast.makeText(context, "Вход выполнен успешно!", android.widget.Toast.LENGTH_SHORT).show()
                        } else {
                            android.widget.Toast.makeText(context, "Ошибка входа: $error", android.widget.Toast.LENGTH_LONG).show()
                        }
                    }
                } else {
                    android.widget.Toast.makeText(context, "Не удалось получить Google ID Token", android.widget.Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                android.widget.Toast.makeText(context, "Ошибка Google Sign-In: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    LaunchedEffect(state.googleClientId) {
        if (state.firebaseToken.isEmpty() && state.googleClientId.isNotEmpty() && !state.googleClientId.contains("dummy")) {
            googleSignInClient.silentSignIn().addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val account = task.result
                    val idToken = account?.idToken
                    val email = account?.email ?: ""
                    if (idToken != null) {
                        viewModel.completeGoogleSignIn(idToken, email) { success, _ ->
                            if (success) {
                                android.widget.Toast.makeText(context, "Автоматический вход выполнен!", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            }
        }
    }

    Scaffold(
        topBar = {
            if (currentScreen != Screen.RoleSelection) {
                val title = when (val screen = currentScreen) {
                    is Screen.Cities -> "Города"
                    is Screen.Groups -> "Группы в г. ${screen.cityName}"
                    is Screen.Students -> ""
                    is Screen.StudentCabinet -> "Личный кабинет"
                    else -> "CoachPay"
                }

                TopAppBar(
                    title = {
                        Text(
                            text = title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = Color.White
                        )
                    },
                    navigationIcon = {
                        if (currentScreen !is Screen.Cities && currentScreen !is Screen.StudentCabinet) {
                            IconButton(onClick = {
                                currentScreen = when (val screen = currentScreen) {
                                    is Screen.Bookings -> Screen.Students(screen.cityId, screen.groupId, screen.groupName)
                                    is Screen.Students -> Screen.Groups(screen.cityId, "")
                                    is Screen.Groups -> Screen.Cities
                                    else -> Screen.Cities
                                }
                            }) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Назад",
                                    tint = Color.White
                                )
                            }
                        }
                    },
                    actions = {
                        // Если мы на экране оплат внутри группы, показываем меню действий
                        if (currentScreen is Screen.Students) {
                            val screen = currentScreen as Screen.Students

                            // Синхронизация с Firebase Realtime Database
                            IconButton(onClick = {
                                viewModel.syncCoachDataAndGroup(screen.cityId, screen.groupId) { success, errorMsg ->
                                    if (success) {
                                        android.widget.Toast.makeText(context, "Данные обновлены из облака!", android.widget.Toast.LENGTH_SHORT).show()
                                    } else {
                                        android.widget.Toast.makeText(context, "Ошибка синхронизации: ${errorMsg ?: "ошибка сети"}", android.widget.Toast.LENGTH_LONG).show()
                                    }
                                }
                            }) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Синхронизировать",
                                    tint = Color.White
                                )
                            }

                            // Скопировать долги в текстовом формате в буфер обмена
                            IconButton(onClick = {
                                val textToCopy = viewModel.getGroupDebtsFormattedText(screen.cityId, screen.groupId, selectedMonth)
                                try {
                                    val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                    val clip = android.content.ClipData.newPlainText("Долги группы", textToCopy)
                                    clipboard.setPrimaryClip(clip)
                                    android.widget.Toast.makeText(context, "Список долгов скопирован!", android.widget.Toast.LENGTH_SHORT).show()
                                } catch (e: Exception) {
                                    android.widget.Toast.makeText(context, "Ошибка копирования", android.widget.Toast.LENGTH_SHORT).show()
                                }
                            }) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Скопировать должников",
                                    tint = Color.White
                                )
                            }

                            // Вызов группового платежа
                            IconButton(onClick = {
                                showGroupPaymentDialog = true
                            }) {
                                Icon(
                                    imageVector = Icons.Default.Payments,
                                    contentDescription = "Групповой сбор",
                                    tint = Color.White
                                )
                            }

                            // Вызов диалога расписания группы
                            IconButton(onClick = {
                                showScheduleDialog = true
                            }) {
                                Icon(
                                    imageVector = Icons.Default.DateRange,
                                    contentDescription = "Расписание группы",
                                    tint = Color.White
                                )
                            }

                            // Переход на экран занятий с записью
                            IconButton(onClick = {
                                currentScreen = Screen.Bookings(screen.cityId, screen.groupId, screen.groupName)
                            }) {
                                Icon(
                                    imageVector = Icons.Default.Assignment,
                                    contentDescription = "Запись на занятия",
                                    tint = Color.White
                                )
                            }

                            // Генерация общего QR/инвайт-кода группы
                            IconButton(onClick = {
                                viewModel.generateGroupInviteCode(screen.cityId, screen.groupId) { code ->
                                    generatedLinkCode = code
                                    linkStudentName = "Группа: ${screen.groupName}"
                                    showLinkCodeDialog = true
                                }
                            }) {
                                Icon(
                                    imageVector = Icons.Default.QrCode,
                                    contentDescription = "Связать группу (QR)",
                                    tint = Color.White
                                )
                            }
                        }

                        if (currentScreen is Screen.StudentCabinet) {
                            IconButton(onClick = {
                                viewModel.pullPaymentsForStudent { success ->
                                    if (success) {
                                        android.widget.Toast.makeText(context, "Оплаты обновлены!", android.widget.Toast.LENGTH_SHORT).show()
                                    } else {
                                        android.widget.Toast.makeText(context, "Ошибка сети", android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Обновить оплаты",
                                    tint = Color.White
                                )
                            }
                        }

                        // Кнопка выхода в меню выбора ролей
                        IconButton(onClick = {
                            viewModel.setRole(AppRole.UNDEFINED)
                        }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                                contentDescription = "Выйти из режима",
                                tint = Color.White
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF1E293B)
                    )
                )
            }
        },
        floatingActionButton = {
            // Кнопка добавления элемента структуры (города, группы, ученика)
            if (currentScreen != Screen.RoleSelection && currentScreen != Screen.StudentCabinet && currentScreen !is Screen.Bookings) {
                FloatingActionButton(
                    onClick = {
                        when (currentScreen) {
                            is Screen.Cities -> showAddCityDialog = true
                            is Screen.Groups -> showAddGroupDialog = true
                            is Screen.Students -> showAddStudentDialog = true
                            else -> {}
                        }
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Добавить")
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Image(
                painter = painterResource(id = R.drawable.bg_dojo),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0F172A).copy(alpha = 0.88f))
            )
            Column(modifier = Modifier.fillMaxSize()) {
                Box(modifier = Modifier.weight(1f)) {
                    when (val screen = currentScreen) {
                        is Screen.RoleSelection -> {
                            RoleSelectionScreen(onRoleSelected = { role ->
                                viewModel.setRole(role)
                            })
                        }
                        is Screen.Cities -> {
                            CitiesScreen(
                                viewModel = viewModel,
                                onCitySelected = { cityId, cityName ->
                                    currentScreen = Screen.Groups(cityId, cityName)
                                },
                                onEditCityClick = { cityId, cityName ->
                                    cityToEdit = cityId to cityName
                                },
                                onOpenCloudSettings = {
                                    showCloudSettingsDialog = true
                                },
                                onGoogleLoginClick = {
                                    if (state.firebaseApiKey.isEmpty() || state.googleClientId.isEmpty()) {
                                        android.widget.Toast.makeText(context, "Сначала укажите ключи Firebase в настройках облака!", android.widget.Toast.LENGTH_LONG).show()
                                        showCloudSettingsDialog = true
                                    } else {
                                        launcher.launch(googleSignInClient.signInIntent)
                                    }
                                },
                                onGoogleLogoutClick = {
                                    googleSignInClient.signOut().addOnCompleteListener {
                                        viewModel.signOutGoogle()
                                        android.widget.Toast.makeText(context, "Выход из аккаунта выполнен", android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                        }
                        is Screen.Groups -> {
                            GroupsScreen(
                                cityId = screen.cityId,
                                cityName = screen.cityName,
                                viewModel = viewModel,
                                onGroupSelected = { groupId, groupName ->
                                    currentScreen = Screen.Students(screen.cityId, groupId, groupName)
                                },
                                onEditGroupClick = { groupId, groupName, defaultFee ->
                                    groupToEdit = Triple(groupId, groupName, defaultFee)
                                }
                            )
                        }
                        is Screen.Students -> {
                            StudentsScreen(
                                cityId = screen.cityId,
                                groupId = screen.groupId,
                                groupName = screen.groupName,
                                viewModel = viewModel,
                                selectedMonth = selectedMonth
                            )
                        }
                        is Screen.Bookings -> {
                            BookingsScreen(
                                cityId = screen.cityId,
                                groupId = screen.groupId,
                                groupName = screen.groupName,
                                viewModel = viewModel,
                                isCoach = true
                            )
                        }
                        is Screen.StudentCabinet -> {
                            StudentCabinetScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }

        // --- ДИАЛОГИ ВЕРХНЕГО УРОВНЯ (ГОРОДА И ГРУППЫ) ---
        if (showAddCityDialog) {
            AddCityDialog(
                onDismiss = { showAddCityDialog = false },
                onConfirm = { name ->
                    viewModel.addCity(name)
                    showAddCityDialog = false
                }
            )
        }

        cityToEdit?.let { (cityId, name) ->
            EditCityDialog(
                currentName = name,
                onDismiss = { cityToEdit = null },
                onConfirm = { newName ->
                    viewModel.editCity(cityId, newName)
                    cityToEdit = null
                }
            )
        }

        if (showAddGroupDialog) {
            val scr = currentScreen as? Screen.Groups
            if (scr != null) {
                AddGroupDialog(
                    onDismiss = { showAddGroupDialog = false },
                    onConfirm = { name, defaultFee ->
                        viewModel.addGroup(scr.cityId, name, defaultFee)
                        showAddGroupDialog = false
                    }
                )
            }
        }

        groupToEdit?.let { (groupId, name, fee) ->
            val scr = currentScreen as? Screen.Groups
            if (scr != null) {
                EditGroupDialog(
                    currentName = name,
                    currentFee = fee,
                    onDismiss = { groupToEdit = null },
                    onConfirm = { newName, newFee ->
                        viewModel.editGroup(scr.cityId, groupId, newName, newFee)
                        groupToEdit = null
                    }
                )
            }
        }

        // --- ДИАЛОГИ ДОБАВЛЕНИЯ УЧЕНИКА И СВЯЗАННЫХ С ГРУППОЙ СБОРОВ ---
        if (showAddStudentDialog) {
            val scr = currentScreen as? Screen.Students
            if (scr != null) {
                AddStudentDialog(
                    defaultJoinMonth = selectedMonth,
                    onDismiss = { showAddStudentDialog = false },
                    onConfirm = { firstName, lastName, joinMonth, phone ->
                        viewModel.addStudent(scr.cityId, scr.groupId, firstName, lastName, joinMonth, phone)
                        showAddStudentDialog = false
                    }
                )
            }
        }

        if (showGroupPaymentDialog) {
            val scr = currentScreen as? Screen.Students
            if (scr != null) {
                val city = state.coachData?.cities?.find { it.id == scr.cityId }
                val group = city?.groups?.find { it.id == scr.groupId }
                val students = group?.students ?: emptyList()

                GroupPaymentDialog(
                    students = students,
                    defaultMonth = selectedMonth,
                    onDismiss = { showGroupPaymentDialog = false },
                    onConfirm = { selectedIds, title, amount, monthParam ->
                        viewModel.addGroupPayment(scr.cityId, scr.groupId, selectedIds, title, amount, monthParam)
                        showGroupPaymentDialog = false
                    }
                )
            }
        }

        if (showScheduleDialog) {
            val scr = currentScreen as? Screen.Students
            if (scr != null) {
                ScheduleEditDialog(
                    cityId = scr.cityId,
                    groupId = scr.groupId,
                    viewModel = viewModel,
                    onDismiss = { showScheduleDialog = false }
                )
            }
        }

        if (showLinkCodeDialog) {
            LinkCodeDialog(
                studentName = linkStudentName,
                linkCode = generatedLinkCode,
                onDismiss = { showLinkCodeDialog = false }
            )
        }

        if (showCloudSettingsDialog) {
            CloudSettingsDialog(
                currentApiKey = state.firebaseApiKey,
                currentClientId = state.googleClientId,
                onSave = { apiKey, clientId ->
                    viewModel.updateCloudSettings(apiKey, clientId)
                },
                onRestoreBackup = {
                    viewModel.restoreFromBackup { success ->
                        if (success) {
                            android.widget.Toast.makeText(context, "Данные восстановлены из бэкапа!", android.widget.Toast.LENGTH_LONG).show()
                        } else {
                            android.widget.Toast.makeText(context, "Резервная копия не найдена или повреждена", android.widget.Toast.LENGTH_LONG).show()
                        }
                    }
                },
                onDismiss = { showCloudSettingsDialog = false }
            )
        }
    }
}
