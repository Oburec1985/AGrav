package ru.oburec.coachpay.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.oburec.coachpay.model.AppRole
import ru.oburec.coachpay.ui.components.EmptyStatePlaceholder
import ru.oburec.coachpay.ui.components.ItemCard
import ru.oburec.coachpay.viewmodel.AppStateViewModel
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Date

/**
 * Экран списка городов тренера.
 * Содержит в верхней части панель статуса Google Auth синхронизации и кнопки входа/настроек,
 * а ниже — список обслуживаемых тренером городов.
 */
@Composable
fun CitiesScreen(
    viewModel: AppStateViewModel,
    onCitySelected: (cityId: String, cityName: String) -> Unit,
    onEditCityClick: (cityId: String, cityName: String) -> Unit,
    onOpenCloudSettings: () -> Unit,
    onGoogleLoginClick: () -> Unit,
    onGoogleLogoutClick: () -> Unit
) {
    val state by viewModel.state.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        // Карточка Google Auth вверху списка городов
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    val isDefaultOwner = state.firebaseUid == "default_coach_owner"
                    if (state.firebaseToken.isEmpty() && !isDefaultOwner) {
                        Text(
                            text = "Облако Google не подключено",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color.White
                        )
                        Text(
                            text = "База работает локально. Войдите в Google аккаунт.",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    } else {
                        Text(
                            text = "Облако подключено",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = if (isDefaultOwner) "Общая база данных" else "Аккаунт: ${state.googleEmail}",
                            fontSize = 12.sp,
                            color = Color.LightGray
                        )
                        val activeId = state.coachData?.coachId ?: state.firebaseUid
                        Text(
                            text = "ID базы: $activeId",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                        Text(
                            text = "Путь БД: /coaches/$activeId",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                        if (state.lastSyncTime > 0L) {
                            val sdf = SimpleDateFormat("dd.MM HH:mm:ss", Locale.getDefault())
                            val dateStr = sdf.format(Date(state.lastSyncTime))
                            Text(
                                text = "Синхронизировано: $dateStr",
                                fontSize = 11.sp,
                                color = Color.Green.copy(alpha = 0.8f)
                            )
                        } else {
                            Text(
                                text = "Не синхронизировано",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.width(8.dp))
                
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Кнопка перехода к настройкам ключей Firebase
                    IconButton(onClick = onOpenCloudSettings) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Настройки облака",
                            tint = Color.LightGray
                        )
                    }
                    
                    val isDefaultOwner = state.firebaseUid == "default_coach_owner"
                    if (!isDefaultOwner) {
                        if (state.firebaseToken.isEmpty()) {
                            Button(
                                onClick = onGoogleLoginClick,
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Text("Войти", color = Color.White, fontSize = 13.sp)
                            }
                        } else {
                            Button(
                                onClick = onGoogleLogoutClick,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Text("Выйти", color = Color.White, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }

        // Список городов
        val cities = state.coachData?.cities ?: emptyList()
        if (cities.isEmpty()) {
            Box(modifier = Modifier.weight(1f)) {
                EmptyStatePlaceholder("Нет добавленных городов.\nНажмите '+' чтобы добавить.")
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 16.dp, start = 16.dp, end = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(cities) { city ->
                    ItemCard(
                        title = city.name,
                        subtitle = "Групп: ${city.groups.size}",
                        onCardClick = {
                            onCitySelected(city.id, city.name)
                        },
                        onEditClick = {
                            onEditCityClick(city.id, city.name)
                        },
                        onDeleteClick = {
                            viewModel.deleteCity(city.id)
                        }
                    )
                }
            }
        }
    }
}
