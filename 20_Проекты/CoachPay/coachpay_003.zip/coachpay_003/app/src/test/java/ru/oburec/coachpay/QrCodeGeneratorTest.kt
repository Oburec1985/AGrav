package ru.oburec.coachpay

import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import org.junit.Assert.*
import org.junit.Test

class QrCodeGeneratorTest {

    @Test
    fun testQrCodeMatrixEncoding() {
        // 1. Исходные данные для кодирования (пример использования кода)
        val inviteCode = "123456"
        val size = 200

        // 2. Генерация матрицы QR-кода с помощью библиотеки ZXing
        val writer = QRCodeWriter()
        val bitMatrix = writer.encode(inviteCode, BarcodeFormat.QR_CODE, size, size)

        // 3. Тест корректности работы:
        // Проверяем, что матрица успешно создалась и размеры соответствуют
        assertNotNull("Матрица QR-кода не должна быть null", bitMatrix)
        assertEquals("Ширина матрицы должна соответствовать заданной", size, bitMatrix.width)
        assertEquals("Высота матрицы должна соответствовать заданной", size, bitMatrix.height)

        // Проверяем, что в матрице есть как черные (true), так и белые (false) пиксели
        var hasBlackPixels = false
        var hasWhitePixels = false
        for (x in 0 until size) {
            for (y in 0 until size) {
                if (bitMatrix.get(x, y)) {
                    hasBlackPixels = true
                } else {
                    hasWhitePixels = true
                }
            }
        }

        assertTrue("Матрица должна содержать черные пиксели", hasBlackPixels)
        assertTrue("Матрица должна содержать белые пиксели", hasWhitePixels)
    }
}
