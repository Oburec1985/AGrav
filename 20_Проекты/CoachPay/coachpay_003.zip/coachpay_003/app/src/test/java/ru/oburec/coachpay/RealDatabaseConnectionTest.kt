package ru.oburec.coachpay

import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.net.HttpURLConnection
import java.net.URL

/**
 * Интеграционный тест для проверки подключения к Firebase Realtime Database и Firebase Auth API.
 */
class RealDatabaseConnectionTest {

    private val firebaseApiKey = "AIzaSyCCy_iHK23qwNeH0J665RmbJ9OO0zwQZwI"
    private val databaseUrl = "https://coachpay-6307c-default-rtdb.firebaseio.com/test_connection.json"
    private val authUrl = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$firebaseApiKey"

    @Test
    fun testDatabaseReachability() {
        println("Тестирование доступности базы данных...")
        try {
            val url = URL(databaseUrl)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 5000
            connection.readTimeout = 5000
            
            val responseCode = connection.responseCode
            println("Ответ базы данных: $responseCode")
            
            // Если база публичная - 200, если защищенная - 401, если пустая - 200/404. Любой из них подтверждает связь с Firebase.
            assertTrue(responseCode == 200 || responseCode == 401 || responseCode == 404)
        } catch (e: java.io.IOException) {
            println("Пропуск теста: Отсутствует подключение к интернету / таймаут (${e.message})")
        } catch (e: Exception) {
            e.printStackTrace()
            fail("Не удалось подключиться к базе данных: ${e.message}")
        }
    }

    @Test
    fun testFirebaseAuthApiConnection() {
        println("Тестирование подключения к Firebase Auth API...")
        try {
            val url = URL(authUrl)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.connectTimeout = 5000
            connection.readTimeout = 5000
            connection.setRequestProperty("Content-Type", "application/json")
            connection.doOutput = true
            
            val payload = "{\"returnSecureToken\":true}"
            connection.outputStream.use { os ->
                os.write(payload.toByteArray())
            }

            val responseCode = connection.responseCode
            println("Ответ Firebase Auth API: $responseCode")
            
            // Если API-ключ валидный - возвращается 200. Если анонимный вход отключен в консоли - 400, но соединение установлено!
            assertTrue(responseCode == 200 || responseCode == 400)
        } catch (e: java.io.IOException) {
            println("Пропуск теста: Отсутствует подключение к интернету / таймаут (${e.message})")
        } catch (e: Exception) {
            e.printStackTrace()
            fail("Не удалось подключиться к Firebase Auth API: ${e.message}")
        }
    }
}
