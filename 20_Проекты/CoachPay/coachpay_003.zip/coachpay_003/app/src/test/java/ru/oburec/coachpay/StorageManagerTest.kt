package ru.oburec.coachpay

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import ru.oburec.coachpay.data.StorageManager
import ru.oburec.coachpay.model.*
import java.io.File

class StorageManagerTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    @Test
    fun testStorageManagerSaveLoadAndBackup() {
        // 1. Инициализация менеджера во временной директории
        val testDir = tempFolder.newFolder()
        val storageManager = StorageManager(testDir)

        // 2. Создание тестового состояния (пример использования кода)
        val initialAppState = AppState(
            role = AppRole.COACH,
            coachData = CoachData(
                coachId = "TESTID1",
                cities = listOf(
                    City(
                        name = "Москва",
                        groups = listOf(
                            StudentGroup(
                                name = "Авангард",
                                students = listOf(
                                    Student(firstName = "Иван", lastName = "Иванов")
                                )
                            )
                        )
                    )
                )
            )
        )

        // 3. Тест корректности работы: Сохранение
        val saveSuccess = storageManager.saveState(initialAppState)
        assertTrue("Сохранение должно быть успешным", saveSuccess)

        // Проверяем физическое существование файла
        val stateFile = File(testDir, "app_state.json")
        assertTrue("Файл состояния должен существовать", stateFile.exists())

        // 4. Тест корректности работы: Загрузка
        val loadedState = storageManager.loadState()
        assertEquals(AppRole.COACH, loadedState.role)
        assertNotNull(loadedState.coachData)
        assertEquals("TESTID1", loadedState.coachData?.coachId)
        assertEquals(1, loadedState.coachData?.cities?.size)
        
        val city = loadedState.coachData?.cities?.first()
        assertEquals("Москва", city?.name)
        assertEquals("Авангард", city?.groups?.first()?.name)
        assertEquals("Иван", city?.groups?.first()?.students?.first()?.firstName)

        // 5. Тест корректности работы: Восстановление из бэкапа при повреждении основного файла
        
        // Делаем второе сохранение, чтобы создался бэкап
        val updatedAppState = initialAppState.copy(
            coachData = initialAppState.coachData?.copy(coachId = "TESTID2")
        )
        storageManager.saveState(updatedAppState)

        val backupFile = File(testDir, "app_state.json.bak")
        assertTrue("Файл бэкапа должен существовать", backupFile.exists())

        // Повреждаем основной файл (делаем его невалидным JSON)
        stateFile.writeText("{ invalid json }", Charsets.UTF_8)

        // Загружаем состояние - должно автоматически восстановиться из бэкапа
        val restoredState = storageManager.loadState()
        assertEquals("TESTID1", restoredState.coachData?.coachId)
        
        // Проверяем, что основной файл автоматически восстановился из бэкапа и теперь валиден
        val contentAfterRestore = stateFile.readText(Charsets.UTF_8)
        assertFalse("Основной файл должен быть восстановлен и не содержать ошибку", contentAfterRestore.contains("invalid json"))
    }
}
