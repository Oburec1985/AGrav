package ru.oburec.coachpay

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import ru.oburec.coachpay.data.StorageManager
import ru.oburec.coachpay.model.AppRole
import ru.oburec.coachpay.model.PaymentState
import ru.oburec.coachpay.model.UserProfile
import ru.oburec.coachpay.viewmodel.AppStateViewModel

/**
 * Юнит-тесты для AppStateViewModel.
 * Проверяют корректность операций с деревом данных и логику календаря/оплат.
 */
class AppStateViewModelTest {

    private var originalBaseUrl: String = ""
    private var originalIdentityUrl: String = ""

    @org.junit.Before
    fun setUp() {
        originalBaseUrl = ru.oburec.coachpay.data.SyncManager.BASE_URL
        originalIdentityUrl = ru.oburec.coachpay.data.SyncManager.IDENTITY_URL
        ru.oburec.coachpay.data.SyncManager.BASE_URL = "http://127.0.0.1:9999"
        ru.oburec.coachpay.data.SyncManager.IDENTITY_URL = "http://127.0.0.1:9999"
    }

    @org.junit.After
    fun tearDown() {
        ru.oburec.coachpay.data.SyncManager.BASE_URL = originalBaseUrl
        ru.oburec.coachpay.data.SyncManager.IDENTITY_URL = originalIdentityUrl
    }

    @get:Rule
    val tempFolder = TemporaryFolder()

    /**
     * Тест базовых CRUD операций (Добавление, редактирование, удаление городов, групп и учеников).
     */
    @Test
    fun testTreeOperations() {
        val testDir = tempFolder.newFolder()
        val storageManager = StorageManager(testDir)
        val viewModel = AppStateViewModel(storageManager, kotlinx.coroutines.Dispatchers.Unconfined)

        // 1. По умолчанию состояние пустое
        assertEquals(AppRole.UNDEFINED, viewModel.state.value.role)
        assertNull(viewModel.state.value.coachData)

        // 2. Установка роли Тренер (автоматически создаются тестовые данные: Мытищи, Основная группа, Марк Скрипник)
        viewModel.setRole(AppRole.COACH)
        assertEquals(AppRole.COACH, viewModel.state.value.role)
        assertNotNull(viewModel.state.value.coachData)

        val coachDataInit = viewModel.state.value.coachData!!
        assertEquals(1, coachDataInit.cities.size)
        val cityInit = coachDataInit.cities.first()
        assertEquals("Мытищи", cityInit.name)
        val studentsInit = cityInit.groups.first().students
        assertEquals(2, studentsInit.size)
        val mark = studentsInit.find { it.firstName == "Марк" }!!
        val bruce = studentsInit.find { it.firstName == "Брюс" }!!
        assertEquals("2026-05", mark.joinMonth)
        assertEquals("2026-03", bruce.joinMonth)

        // 3. Тест корректности работы: добавление нового города
        viewModel.addCity("Королев")
        val coachData1 = viewModel.state.value.coachData!!
        assertEquals(2, coachData1.cities.size)
        val city = coachData1.cities.find { it.name == "Королев" }!!

        // 4. Тест корректности работы: добавление группы
        viewModel.addGroup(city.id, "Авангард")
        val coachData2 = viewModel.state.value.coachData!!
        val updatedCity = coachData2.cities.find { it.id == city.id }!!
        val group = updatedCity.groups.first()
        assertEquals("Авангард", group.name)

        // 5. Тест корректности работы: добавление ученика
        viewModel.addStudent(city.id, group.id, "Петр", "Петров", "2026-06")
        val coachData3 = viewModel.state.value.coachData!!
        val student = coachData3.cities.find { it.id == city.id }!!.groups.first().students.first()
        assertEquals("Петр", student.firstName)
        assertEquals("Петров", student.lastName)

        // 6. Тест корректности работы: редактирование
        viewModel.editCity(city.id, "Королев-Плюс")
        viewModel.editGroup(city.id, group.id, "Лидер", 3000.0)
        viewModel.editStudent(city.id, group.id, student.id, "Сидор", "Сидоров", "2026-06")

        val coachData4 = viewModel.state.value.coachData!!
        val editedCity = coachData4.cities.find { it.id == city.id }!!
        assertEquals("Королев-Плюс", editedCity.name)
        val editedGroup = editedCity.groups.first()
        assertEquals("Лидер", editedGroup.name)
        val editedStudent = editedGroup.students.first()
        assertEquals("Сидор", editedStudent.firstName)
        assertEquals("Сидоров", editedStudent.lastName)

        // 7. Тест корректности работы: удаление
        viewModel.deleteStudent(city.id, group.id, student.id)
        assertTrue(viewModel.state.value.coachData!!.cities.find { it.id == city.id }!!.groups.first().students.isEmpty())

        viewModel.deleteGroup(city.id, group.id)
        assertTrue(viewModel.state.value.coachData!!.cities.find { it.id == city.id }!!.groups.isEmpty())

        viewModel.deleteCity(city.id)
        assertEquals(1, viewModel.state.value.coachData!!.cities.size) // Остались только начальные Мытищи
    }

    /**
     * Тест логики работы календаря оплат (абонементы, изменение цены без изменения истории, разовые внемесячные платежи).
     */
    @Test
    fun testPaymentOperations() {
        val testDir = tempFolder.newFolder()
        val storageManager = StorageManager(testDir)
        val viewModel = AppStateViewModel(storageManager, kotlinx.coroutines.Dispatchers.Unconfined)

        // Инициализируем БД
        viewModel.setRole(AppRole.COACH)
        val coachData = viewModel.state.value.coachData!!
        val city = coachData.cities.first()
        val group = city.groups.first()
        val student = group.students.first() // Марк Скрипник

        // 1. Автогенерация абонементов от joinMonth (май 2026) до июня 2026
        viewModel.generateMonthlyPaymentsIfNeeded(city.id, group.id, "2026-06")
        
        var currentStudent = viewModel.state.value.coachData!!.cities.first().groups.first().students.first()
        assertEquals(2, currentStudent.payments.size) // май 2026 + июнь 2026
        val junePayment = currentStudent.payments.find { it.month == "2026-06" }!!
        assertEquals("Абонемент", junePayment.title)
        assertEquals(3000.0, junePayment.amount, 0.01)
        assertEquals("2026-06", junePayment.month)
        assertEquals(PaymentState.UNPAID, junePayment.state)

        // 2. Отметка о сдаче (toggle)
        viewModel.togglePaymentState(city.id, group.id, student.id, junePayment.id, "2026-06")
        currentStudent = viewModel.state.value.coachData!!.cities.first().groups.first().students.first()
        assertEquals(PaymentState.PAID, currentStudent.payments.find { it.month == "2026-06" }!!.state)

        // 3. Изменение тарифа ученика
        viewModel.changeMonthlyFee(city.id, group.id, student.id, 3500.0)

        // 4. Генерация абонемента за июль 2026 (должна примениться новая цена 3500.0, а в июне остаться 3000.0)
        viewModel.generateMonthlyPaymentsIfNeeded(city.id, group.id, "2026-07")
        currentStudent = viewModel.state.value.coachData!!.cities.first().groups.first().students.first()
        assertEquals(3, currentStudent.payments.size) // май, июнь, июль

        val paymentJune = currentStudent.payments.find { it.month == "2026-06" }!!
        val paymentJuly = currentStudent.payments.find { it.month == "2026-07" }!!
        
        assertEquals(3000.0, paymentJune.amount, 0.01) // Прежний платеж не изменился
        assertEquals(3500.0, paymentJuly.amount, 0.01) // Новый платеж сгенерирован по новой ставке

        // 5. Создание разового группового сбора без привязки к месяцу (внемесячный долг)
        viewModel.addGroupPayment(city.id, group.id, listOf(student.id), "Форма", 1500.0, "")
        currentStudent = viewModel.state.value.coachData!!.cities.first().groups.first().students.first()
        assertEquals(4, currentStudent.payments.size)

        val customPayment = currentStudent.payments.find { it.title == "Форма" }!!
        assertEquals("", customPayment.month) // Пустой месяц означает внемесячный платеж
        assertEquals(PaymentState.UNPAID, customPayment.state)

        // 6. Оплата внемесячного долга в июле (должна привязаться к июлю)
        viewModel.togglePaymentState(city.id, group.id, student.id, customPayment.id, "2026-07")
        currentStudent = viewModel.state.value.coachData!!.cities.first().groups.first().students.first()
        val updatedCustomPayment = currentStudent.payments.find { it.title == "Форма" }!!
        assertEquals(PaymentState.PAID, updatedCustomPayment.state)
        assertEquals("2026-07", updatedCustomPayment.month) // Привязался к июлю при оплате

        // 7. Снятие оплаты (должна вернуться пустая привязка к месяцу, чтобы долг снова висел везде)
        viewModel.togglePaymentState(city.id, group.id, student.id, customPayment.id, "2026-07")
        currentStudent = viewModel.state.value.coachData!!.cities.first().groups.first().students.first()
        val canceledCustomPayment = currentStudent.payments.find { it.title == "Форма" }!!
        assertEquals(PaymentState.UNPAID, canceledCustomPayment.state)
        assertEquals("", canceledCustomPayment.month) // Привязка сброшена
    }

    /**
     * Тест новых функций:joinMonth, defaultMonthlyFee группы и форматирования текста долгов.
     */
    @Test
    fun testNewFeatures() {
        val testDir = tempFolder.newFolder()
        val storageManager = StorageManager(testDir)
        val viewModel = AppStateViewModel(storageManager, kotlinx.coroutines.Dispatchers.Unconfined)

        viewModel.setRole(AppRole.COACH)
        val coachData = viewModel.state.value.coachData!!
        val city = coachData.cities.first()

        // 1. Создаем группу с тарифом 4000.0 по умолчанию
        viewModel.addGroup(city.id, "Спецгруппа", 4000.0)
        val group = viewModel.state.value.coachData!!.cities.first().groups.find { it.name == "Спецгруппа" }!!
        assertEquals(4000.0, group.defaultMonthlyFee, 0.01)

        // 2. Добавляем ученика, пришедшего в "2026-05"
        viewModel.addStudent(city.id, group.id, "Иван", "Иванов", "2026-05")
        val student = viewModel.state.value.coachData!!.cities.first().groups.find { it.id == group.id }!!.students.first()
        
        // Проверяем, что тариф ученика скопировался из тарифа группы, а также joinMonth равен 2026-05
        assertEquals(4000.0, student.monthlyFee, 0.01)
        assertEquals("2026-05", student.joinMonth)

        // 3. Пытаемся сгенерировать абонемент за "2026-04" (до прихода ученика)
        viewModel.generateMonthlyPaymentsIfNeeded(city.id, group.id, "2026-04")
        var updatedStudent = viewModel.state.value.coachData!!.cities.first().groups.find { it.id == group.id }!!.students.first()
        assertTrue("Не должно быть платежей до даты прихода", updatedStudent.payments.isEmpty())

        // 4. Генерируем абонемент за "2026-05" (месяц прихода)
        viewModel.generateMonthlyPaymentsIfNeeded(city.id, group.id, "2026-05")
        updatedStudent = viewModel.state.value.coachData!!.cities.first().groups.find { it.id == group.id }!!.students.first()
        assertEquals(1, updatedStudent.payments.size)
        assertEquals("Абонемент", updatedStudent.payments.first().title)
        assertEquals(4000.0, updatedStudent.payments.first().amount, 0.01)
        assertEquals("2026-05", updatedStudent.payments.first().month)

        // 5. Добавляем еще один неоплаченный платеж (внемесячный)
        viewModel.addGroupPayment(city.id, group.id, listOf(student.id), "Форма", 1500.0, "")
        
        // 6. Проверяем генерацию форматированного текста долгов группы
        val debtsText = viewModel.getGroupDebtsFormattedText(city.id, group.id, "2026-05")
        val expected = "Иванов Иван: май 4000; Форма 1500;"
        assertEquals(expected, debtsText)
    }

    /**
     * Тест проверки генерации долгов предустановленных учеников с учетом joinMonth:
     * - Марк Скрипник (май 2026)
     * - Брюс Ли (март 2026)
     */
    @Test
    fun testMockDebtsGeneration() {
        val testDir = tempFolder.newFolder()
        val storageManager = StorageManager(testDir)
        val viewModel = AppStateViewModel(storageManager, kotlinx.coroutines.Dispatchers.Unconfined)

        viewModel.setRole(AppRole.COACH)
        val city = viewModel.state.value.coachData!!.cities.first()
        val group = city.groups.first()

        val debtsText = viewModel.getGroupDebtsFormattedText(city.id, group.id, "2026-06")
        
        // Проверяем, что долги Марка Скрипника включают Май и Июнь, но не включают Март и Апрель
        assertTrue(debtsText.contains("Скрипник Марк: май 3000; июнь 3000;") || debtsText.contains("Скрипник Марк: июнь 3000; май 3000;"))
        assertFalse(debtsText.contains("Скрипник Марк: март"))
        assertFalse(debtsText.contains("Скрипник Марк: апрель"))

        // Проверяем, что долги Брюса Ли включают Март, Апрель, Май и Июнь
        assertTrue(debtsText.contains("Ли Брюс: март 3000; апрель 3000; май 3000; июнь 3000;"))
    }

    /**
     * Тест проверки локальных переходов состояний при облачной синхронизации.
     * Проверяет перевод ролей, заполнение StudentConfig и локальное обновление статусов до PENDING_APPROVAL.
     */
    @Test
    fun testCloudStateTransitions() {
        val testDir = tempFolder.newFolder()
        val storageManager = StorageManager(testDir)
        val viewModel = AppStateViewModel(storageManager, kotlinx.coroutines.Dispatchers.Unconfined)

        // 1. По умолчанию роль UNDEFINED
        assertEquals(AppRole.UNDEFINED, viewModel.state.value.role)
        assertNull(viewModel.state.value.studentConfig)

        // 2. Имитируем успешную привязку ученика (по сути ручной запуск перехода роли)
        val testConfig = ru.oburec.coachpay.model.StudentConfig(
            coachId = "test_coach",
            cityName = "Мытищи",
            groupName = "Основная группа",
            firstName = "Марк",
            lastName = "Скрипник",
            studentId = "student_123",
            payments = listOf(
                ru.oburec.coachpay.model.Payment(
                    id = "payment_999",
                    amount = 3000.0,
                    month = "2026-06",
                    state = PaymentState.UNPAID,
                    title = "Абонемент"
                )
            ),
            inviteCode = "123456"
        )
        
        // Сохраняем стейт с ролью STUDENT
        viewModel.saveState(viewModel.state.value.copy(
            role = AppRole.STUDENT,
            studentConfig = testConfig
        ))

        assertEquals(AppRole.STUDENT, viewModel.state.value.role)
        assertNotNull(viewModel.state.value.studentConfig)
        assertEquals("student_123", viewModel.state.value.studentConfig?.studentId)
        assertEquals(1, viewModel.state.value.studentConfig?.payments?.size)
        assertEquals(PaymentState.UNPAID, viewModel.state.value.studentConfig?.payments?.first()?.state)

        // 3. Ученик отмечает платеж как оплаченный
        viewModel.studentMarkAsPaid("payment_999") { /* no-op callback */ }

        // Проверяем, что локально статус перешел в PENDING_APPROVAL
        val updatedConfig = viewModel.state.value.studentConfig!!
        assertEquals(PaymentState.PENDING_APPROVAL, updatedConfig.payments.first().state)
    }
    @Test
    fun testStudentProfileSync() {
        val testDir = tempFolder.newFolder()
        val storageManager = StorageManager(testDir)
        val viewModel = AppStateViewModel(storageManager, kotlinx.coroutines.Dispatchers.Unconfined)

        val testConfig = ru.oburec.coachpay.model.StudentConfig(
            coachId = "test_coach",
            cityName = "Мытищи",
            groupName = "Основная группа",
            firstName = "Марк",
            lastName = "Скрипник",
            studentId = "student_123",
            payments = emptyList(),
            inviteCode = "123456",
            birthDate = "",
            height = "",
            weight = ""
        )

        viewModel.saveState(viewModel.state.value.copy(
            role = AppRole.STUDENT,
            studentConfig = testConfig
        ))

        // Изначально профиль пустой
        assertEquals("", viewModel.state.value.studentConfig?.birthDate)
        assertEquals("", viewModel.state.value.studentConfig?.height)
        assertEquals("", viewModel.state.value.studentConfig?.weight)

        // Обновляем профиль ученика
        viewModel.updateStudentProfile("25.12.2014", "150", "42.5")

        // Проверяем, что локальный конфиг обновился
        val updatedConfig = viewModel.state.value.studentConfig!!
        assertEquals("25.12.2014", updatedConfig.birthDate)
        assertEquals("150", updatedConfig.height)
        assertEquals("42.5", updatedConfig.weight)
    }

    /**
     * Тест проверки нормализации состояния при загрузке и при редактировании даты прихода ученика.
     */
    @Test
    fun testNormalizeStateAndEditStudentCleanup() {
        val testDir = tempFolder.newFolder()
        val storageManager = StorageManager(testDir)
        val viewModel = AppStateViewModel(storageManager, kotlinx.coroutines.Dispatchers.Unconfined)

        viewModel.setRole(AppRole.COACH)
        val city = viewModel.state.value.coachData!!.cities.first()
        val group = city.groups.first()

        // Добавляем ученика без joinMonth
        viewModel.addStudent(city.id, group.id, "Василий", "Васильев", "")
        var student = viewModel.state.value.coachData!!.cities.first().groups.first().students.find { it.firstName == "Василий" }!!

        // Генерируем платежи для него за 2024-01 и 2024-02
        viewModel.generateMonthlyPaymentsIfNeeded(city.id, group.id, "2024-01")
        viewModel.generateMonthlyPaymentsIfNeeded(city.id, group.id, "2024-02")
        
        student = viewModel.state.value.coachData!!.cities.first().groups.first().students.find { it.firstName == "Василий" }!!
        assertEquals(2, student.payments.size)
        assertTrue(student.payments.any { it.month == "2024-01" })
        assertTrue(student.payments.any { it.month == "2024-02" })

        // Редактируем ученика и задаем joinMonth = "2024-02"
        // Платеж за 2024-01 должен удалиться, а за 2024-02 остаться
        viewModel.editStudent(city.id, group.id, student.id, "Василий", "Васильев", "2024-02")
        
        student = viewModel.state.value.coachData!!.cities.first().groups.first().students.find { it.firstName == "Василий" }!!
        assertEquals(1, student.payments.size)
        assertFalse(student.payments.any { it.month == "2024-01" })
        assertTrue(student.payments.any { it.month == "2024-02" })

        // Теперь вручную засунем "грязный" платеж обратно для проверки normalizeState
        val dirtyPayment = ru.oburec.coachpay.model.Payment(
            amount = 3000.0,
            month = "2023-12",
            state = PaymentState.UNPAID,
            title = "Абонемент"
        )
        val studentWithDirty = student.copy(payments = student.payments + dirtyPayment)
        
        // Сохраняем "грязное" состояние напрямую в файл
        val dirtyCoachData = viewModel.state.value.coachData!!.copy(
            cities = viewModel.state.value.coachData!!.cities.map { c ->
                if (c.id == city.id) {
                    c.copy(groups = c.groups.map { g ->
                        if (g.id == group.id) {
                            g.copy(students = g.students.map { s ->
                                if (s.id == student.id) studentWithDirty else s
                            })
                        } else g
                    })
                } else c
            }
        )
        val dirtyState = viewModel.state.value.copy(coachData = dirtyCoachData)
        storageManager.saveState(dirtyState)

        // Загружаем состояние и проверяем, что normalizeState отфильтровал грязный платеж
        viewModel.loadState()
        
        student = viewModel.state.value.coachData!!.cities.first().groups.first().students.find { it.firstName == "Василий" }!!
        assertEquals(1, student.payments.size)
        assertFalse(student.payments.any { it.month == "2023-12" })
    }

    /**
     * Тест проверки добавления/редактирования телефона ученика, его очистки и обновления в профиле.
     */
    @Test
    fun testStudentPhoneAndLinking() {
        val testDir = tempFolder.newFolder()
        val storageManager = StorageManager(testDir)
        val viewModel = AppStateViewModel(storageManager, kotlinx.coroutines.Dispatchers.Unconfined)

        viewModel.setRole(AppRole.COACH)
        val city = viewModel.state.value.coachData!!.cities.first()
        val group = city.groups.first()

        // 1. Проверяем добавление ученика с номером телефона
        viewModel.addStudent(city.id, group.id, "Иван", "Петров", "2026-06", "+7 (999) 123-45-67")
        var student = viewModel.state.value.coachData!!.cities.first().groups.first().students.find { it.firstName == "Иван" }!!
        assertEquals("+7 (999) 123-45-67", student.phone)

        // 2. Проверяем редактирование номера телефона
        viewModel.editStudent(city.id, group.id, student.id, "Иван", "Петров", "2026-06", "+7 (999) 765-43-21")
        student = viewModel.state.value.coachData!!.cities.first().groups.first().students.find { it.firstName == "Иван" }!!
        assertEquals("+7 (999) 765-43-21", student.phone)

        // 3. Проверяем очистку телефонных номеров в хелпере cleanPhoneNumber
        assertEquals("79991234567", viewModel.cleanPhoneNumber("+7 (999) 123-45-67"))
        assertEquals("79991234567", viewModel.cleanPhoneNumber("8 (999) 123-45-67"))
        assertEquals("79991234567", viewModel.cleanPhoneNumber("79991234567"))

        // 4. Проверяем обновление телефона в профиле со стороны личного кабинета ученика
        val testConfig = ru.oburec.coachpay.model.StudentConfig(
            coachId = "test_coach",
            cityName = "Мытищи",
            groupName = "Основная группа",
            firstName = "Марк",
            lastName = "Скрипник",
            studentId = "student_123",
            payments = emptyList(),
            inviteCode = "123456",
            birthDate = "",
            height = "",
            weight = "",
            phone = ""
        )
        viewModel.saveState(viewModel.state.value.copy(
            role = AppRole.STUDENT,
            studentConfig = testConfig
        ))

        // Обновляем профиль ученика, включая номер телефона
        viewModel.updateStudentProfile("25.12.2014", "150", "42.5", "+79991234567")

        // Проверяем, что в конфигурации ученика сохранился телефон
        val updatedConfig = viewModel.state.value.studentConfig!!
        assertEquals("+79991234567", updatedConfig.phone)
        assertEquals("25.12.2014", updatedConfig.birthDate)

        // 5. Проверяем безопасный merge профиля у тренера
        // Если пришел профиль из облака, но в нем пустой телефон, а у тренера локально телефон заполнен, он не должен затереться
        viewModel.setRole(AppRole.COACH)
        val coachCity = viewModel.state.value.coachData!!.cities.first()
        val coachGroup = coachCity.groups.first()
        val coachStudent = coachGroup.students.find { it.firstName == "Иван" }!!
        assertEquals("+7 (999) 765-43-21", coachStudent.phone) // локально заполнен

        // Моделируем merge профиля
        val mockProfileResponse = ru.oburec.coachpay.data.ProfileResponse(birthDate = "25.12.2014", height = "150", weight = "42.5", phone = "")
        // Безопасный merge должен обновить birthDate, height, weight, но оставить локальный телефон
        val mergedBirthDate = if (mockProfileResponse.birthDate.isNotEmpty()) mockProfileResponse.birthDate else coachStudent.birthDate
        val mergedHeight = if (mockProfileResponse.height.isNotEmpty()) mockProfileResponse.height else coachStudent.height
        val mergedWeight = if (mockProfileResponse.weight.isNotEmpty()) mockProfileResponse.weight else coachStudent.weight
        val mergedPhone = if (mockProfileResponse.phone.isNotEmpty()) mockProfileResponse.phone else coachStudent.phone

        val updatedMockStudent = coachStudent.copy(
            birthDate = mergedBirthDate,
            height = mergedHeight,
            weight = mergedWeight,
            phone = mergedPhone
        )

        assertEquals("25.12.2014", updatedMockStudent.birthDate)
        assertEquals("150", updatedMockStudent.height)
        assertEquals("+7 (999) 765-43-21", updatedMockStudent.phone) // телефон остался прежним!

        // 6. Проверяем удаление ученика с телефоном (что не падает)
        viewModel.deleteStudent(coachCity.id, coachGroup.id, coachStudent.id)
        assertNull(viewModel.state.value.coachData!!.cities.first().groups.first().students.find { it.firstName == "Иван" })
    }

    @Test
    fun testGoogleAuthFlow() {
        val testDir = tempFolder.newFolder()
        val storageManager = StorageManager(testDir)
        val viewModel = AppStateViewModel(storageManager, kotlinx.coroutines.Dispatchers.Unconfined)

        // Проверяем начальные настройки
        assertEquals("AIzaSyCCy_iHK23qwNeH0J665RmbJ9OO0zwQZwI", viewModel.state.value.firebaseApiKey)
        assertEquals("", viewModel.state.value.googleClientId)

        // Обновляем настройки
        viewModel.updateCloudSettings("apiKey123", "clientId123")
        assertEquals("apiKey123", viewModel.state.value.firebaseApiKey)
        assertEquals("clientId123", viewModel.state.value.googleClientId)

        // Выходим из Google (хотя не входили)
        viewModel.signOutGoogle()
        assertEquals("", viewModel.state.value.firebaseToken)

        // Проверяем, что вход без API ключа выдает ошибку
        viewModel.updateCloudSettings("", "")
        var callSuccess = false
        var callError: String? = null
        viewModel.completeGoogleSignIn("token", "test@gmail.com") { success, error ->
            callSuccess = success
            callError = error
        }
        assertFalse(callSuccess)
        assertEquals("Firebase API Key не задан в настройках", callError)
    }

    @Test
    fun testSelfProvisioningFlow() {
        val originalProxySelector = java.net.ProxySelector.getDefault()
        java.net.ProxySelector.setDefault(object : java.net.ProxySelector() {
            override fun select(uri: java.net.URI?): MutableList<java.net.Proxy> {
                return mutableListOf(java.net.Proxy.NO_PROXY)
            }
            override fun connectFailed(uri: java.net.URI?, sa: java.net.SocketAddress?, ioe: java.io.IOException?) {}
        })

        val server = com.sun.net.httpserver.HttpServer.create(java.net.InetSocketAddress("127.0.0.1", 0), 0)
        val port = server.address.port
        
        val originalBaseUrl = ru.oburec.coachpay.data.SyncManager.BASE_URL
        val originalIdentityUrl = ru.oburec.coachpay.data.SyncManager.IDENTITY_URL
        
        ru.oburec.coachpay.data.SyncManager.BASE_URL = "http://127.0.0.1:$port"
        ru.oburec.coachpay.data.SyncManager.IDENTITY_URL = "http://127.0.0.1:$port/signIn"
        
        var identityCalled = false
        var getUserProfileCalled = false
        var saveUserProfileCalled = false
        var lastSavedProfile: String? = null

        server.createContext("/") { exchange ->
            val path = exchange.requestURI.path
            val method = exchange.requestMethod
            
            if (path == "/signIn" && method == "POST") {
                identityCalled = true
                val response = """
                    {
                        "localId": "test_uid_123",
                        "idToken": "test_token_jwt",
                        "refreshToken": "refresh_token_123",
                        "expiresIn": "3600"
                    }
                """.trimIndent()
                exchange.sendResponseHeaders(200, response.toByteArray().size.toLong())
                val os = exchange.responseBody
                os.write(response.toByteArray())
                os.close()
            } else if (path == "/users/test_uid_123.json" && method == "GET") {
                getUserProfileCalled = true
                val response = "null"
                exchange.sendResponseHeaders(200, response.toByteArray().size.toLong())
                val os = exchange.responseBody
                os.write(response.toByteArray())
                os.close()
            } else if (path == "/users/test_uid_123.json" && method == "PUT") {
                saveUserProfileCalled = true
                val reader = java.io.BufferedReader(java.io.InputStreamReader(exchange.requestBody, "UTF-8"))
                lastSavedProfile = reader.readLine()
                reader.close()
                
                val response = lastSavedProfile ?: "null"
                exchange.sendResponseHeaders(200, response.toByteArray().size.toLong())
                val os = exchange.responseBody
                os.write(response.toByteArray())
                os.close()
            } else {
                exchange.sendResponseHeaders(404, 0)
                exchange.close()
            }
        }
        
        server.start()
        
        try {
            val testDir = tempFolder.newFolder()
            val storageManager = StorageManager(testDir)
            val viewModel = AppStateViewModel(
                storageManager = storageManager,
                ioDispatcher = kotlinx.coroutines.Dispatchers.Unconfined,
                mainDispatcher = kotlinx.coroutines.Dispatchers.Unconfined
            )
            
            viewModel.updateCloudSettings("apiKey123", "clientId123")
            
            val latch = java.util.concurrent.CountDownLatch(1)
            var signInSuccess = false
            var signInError: String? = null
            
            viewModel.completeGoogleSignIn("googleToken", "newuser@gmail.com") { success, error ->
                signInSuccess = success
                signInError = error
                latch.countDown()
            }
            
            assertTrue("Таймаут ожидания входа", latch.await(5, java.util.concurrent.TimeUnit.SECONDS))
            assertTrue("Вход должен быть успешным", signInSuccess)
            assertNull(signInError)
            
            assertTrue("Должен вызваться signInWithFirebaseOAuth", identityCalled)
            assertTrue("Должен провериться профиль пользователя", getUserProfileCalled)
            assertTrue("Должен создаться новый профиль пользователя", saveUserProfileCalled)
            
            assertNotNull(lastSavedProfile)
            assertTrue(lastSavedProfile!!.contains("test_uid_123"))
            assertTrue(lastSavedProfile!!.contains("newuser@gmail.com"))
            assertTrue(lastSavedProfile!!.contains("UNDEFINED"))
            
            val state = viewModel.state.value
            assertEquals(AppRole.UNDEFINED, state.role)
            assertEquals("test_token_jwt", state.firebaseToken)
            assertEquals("newuser@gmail.com", state.googleEmail)
            assertEquals("test_uid_123", state.firebaseUid)
            
        } finally {
            java.net.ProxySelector.setDefault(originalProxySelector)
            server.stop(0)
            ru.oburec.coachpay.data.SyncManager.BASE_URL = originalBaseUrl
            ru.oburec.coachpay.data.SyncManager.IDENTITY_URL = originalIdentityUrl
        }
    }

    @Test
    fun testSelfProvisioningRestoreFlow() {
        val originalProxySelector = java.net.ProxySelector.getDefault()
        java.net.ProxySelector.setDefault(object : java.net.ProxySelector() {
            override fun select(uri: java.net.URI?): MutableList<java.net.Proxy> {
                return mutableListOf(java.net.Proxy.NO_PROXY)
            }
            override fun connectFailed(uri: java.net.URI?, sa: java.net.SocketAddress?, ioe: java.io.IOException?) {}
        })

        val server = com.sun.net.httpserver.HttpServer.create(java.net.InetSocketAddress("127.0.0.1", 0), 0)
        val port = server.address.port
        
        val originalBaseUrl = ru.oburec.coachpay.data.SyncManager.BASE_URL
        val originalIdentityUrl = ru.oburec.coachpay.data.SyncManager.IDENTITY_URL
        
        ru.oburec.coachpay.data.SyncManager.BASE_URL = "http://127.0.0.1:$port"
        ru.oburec.coachpay.data.SyncManager.IDENTITY_URL = "http://127.0.0.1:$port/signIn"
        
        var profileFetched = false

        server.createContext("/") { exchange ->
            val path = exchange.requestURI.path
            val method = exchange.requestMethod
            
            if (path == "/signIn" && method == "POST") {
                val response = """
                    {
                        "localId": "existing_coach_uid",
                        "idToken": "test_token_jwt",
                        "refreshToken": "refresh_token_123",
                        "expiresIn": "3600"
                    }
                """.trimIndent()
                exchange.sendResponseHeaders(200, response.toByteArray().size.toLong())
                val os = exchange.responseBody
                os.write(response.toByteArray())
                os.close()
            } else if (path == "/users/existing_coach_uid.json" && method == "GET") {
                profileFetched = true
                val response = """
                    {
                        "uid": "existing_coach_uid",
                        "email": "coach@gmail.com",
                        "role": "COACH",
                        "coachId": "existing_coach_uid"
                    }
                """.trimIndent()
                exchange.sendResponseHeaders(200, response.toByteArray().size.toLong())
                val os = exchange.responseBody
                os.write(response.toByteArray())
                os.close()
            } else if (path == "/coaches/existing_coach_uid/coachData.json") {
                if (method == "GET") {
                    val response = "null"
                    exchange.sendResponseHeaders(200, response.toByteArray().size.toLong())
                    val os = exchange.responseBody
                    os.write(response.toByteArray())
                    os.close()
                } else if (method == "PUT") {
                    exchange.sendResponseHeaders(200, 0)
                    exchange.close()
                }
            } else {
                exchange.sendResponseHeaders(404, 0)
                exchange.close()
            }
        }
        
        server.start()
        
        try {
            val testDir = tempFolder.newFolder()
            val storageManager = StorageManager(testDir)
            val viewModel = AppStateViewModel(
                storageManager = storageManager,
                ioDispatcher = kotlinx.coroutines.Dispatchers.Unconfined,
                mainDispatcher = kotlinx.coroutines.Dispatchers.Unconfined
            )
            
            viewModel.updateCloudSettings("apiKey123", "clientId123")
            
            val latch = java.util.concurrent.CountDownLatch(1)
            var signInSuccess = false
            viewModel.completeGoogleSignIn("googleToken", "coach@gmail.com") { success, _ ->
                signInSuccess = success
                latch.countDown()
            }
            
            assertTrue("Таймаут ожидания входа", latch.await(5, java.util.concurrent.TimeUnit.SECONDS))
            assertTrue(signInSuccess)
            assertTrue(profileFetched)
            
            val state = viewModel.state.value
            assertEquals(AppRole.COACH, state.role)
            assertEquals("existing_coach_uid", state.coachData?.coachId)
            
        } finally {
            java.net.ProxySelector.setDefault(originalProxySelector)
            server.stop(0)
            ru.oburec.coachpay.data.SyncManager.BASE_URL = originalBaseUrl
            ru.oburec.coachpay.data.SyncManager.IDENTITY_URL = originalIdentityUrl
        }
    }

    @Test
    fun testGoogleSignInAutoConfiguresAndRestoresCoachData() {
        val originalProxySelector = java.net.ProxySelector.getDefault()
        java.net.ProxySelector.setDefault(object : java.net.ProxySelector() {
            override fun select(uri: java.net.URI?): MutableList<java.net.Proxy> {
                return mutableListOf(java.net.Proxy.NO_PROXY)
            }
            override fun connectFailed(uri: java.net.URI?, sa: java.net.SocketAddress?, ioe: java.io.IOException?) {}
        })

        val server = com.sun.net.httpserver.HttpServer.create(java.net.InetSocketAddress("127.0.0.1", 0), 0)
        val port = server.address.port
        
        val originalBaseUrl = ru.oburec.coachpay.data.SyncManager.BASE_URL
        val originalIdentityUrl = ru.oburec.coachpay.data.SyncManager.IDENTITY_URL
        
        ru.oburec.coachpay.data.SyncManager.BASE_URL = "http://127.0.0.1:$port"
        ru.oburec.coachpay.data.SyncManager.IDENTITY_URL = "http://127.0.0.1:$port/signIn"
        
        var coachDataFetched = false
        val mockCoachDataJson = """
            {
                "coachId": "existing_coach_uid",
                "cities": [
                    {
                        "id": "city_123",
                        "name": "Новосибирск",
                        "groups": []
                    }
                ]
            }
        """.trimIndent()

        server.createContext("/") { exchange ->
            val path = exchange.requestURI.path
            val method = exchange.requestMethod
            
            if (path == "/signIn" && method == "POST") {
                val response = """
                    {
                        "localId": "existing_coach_uid",
                        "idToken": "test_token_jwt",
                        "refreshToken": "refresh_token_123",
                        "expiresIn": "3600"
                    }
                """.trimIndent()
                exchange.sendResponseHeaders(200, response.toByteArray().size.toLong())
                val os = exchange.responseBody
                os.write(response.toByteArray())
                os.close()
            } else if (path == "/users/existing_coach_uid.json" && method == "GET") {
                val response = """
                    {
                        "uid": "existing_coach_uid",
                        "email": "coach@gmail.com",
                        "role": "COACH",
                        "coachId": "existing_coach_uid"
                    }
                """.trimIndent()
                exchange.sendResponseHeaders(200, response.toByteArray().size.toLong())
                val os = exchange.responseBody
                os.write(response.toByteArray())
                os.close()
            } else if (path == "/coaches/existing_coach_uid/coachData.json" && method == "GET") {
                coachDataFetched = true
                exchange.sendResponseHeaders(200, mockCoachDataJson.toByteArray().size.toLong())
                val os = exchange.responseBody
                os.write(mockCoachDataJson.toByteArray())
                os.close()
            } else {
                exchange.sendResponseHeaders(404, 0)
                exchange.close()
            }
        }
        
        server.start()
        
        try {
            val testDir = tempFolder.newFolder()
            val storageManager = StorageManager(testDir)
            val viewModel = AppStateViewModel(
                storageManager = storageManager,
                ioDispatcher = kotlinx.coroutines.Dispatchers.Unconfined,
                mainDispatcher = kotlinx.coroutines.Dispatchers.Unconfined
            )
            
            viewModel.updateCloudSettings("apiKey123", "clientId123")
            
            val latch = java.util.concurrent.CountDownLatch(1)
            var signInSuccess = false
            viewModel.completeGoogleSignIn("googleToken", "coach@gmail.com") { success, _ ->
                signInSuccess = success
                latch.countDown()
            }
            
            assertTrue("Таймаут ожидания входа", latch.await(5, java.util.concurrent.TimeUnit.SECONDS))
            assertTrue(signInSuccess)
            assertTrue(coachDataFetched)
            
            val state = viewModel.state.value
            assertEquals(AppRole.COACH, state.role)
            assertEquals("existing_coach_uid", state.coachData?.coachId)
            assertEquals(1, state.coachData?.cities?.size)
            assertEquals("Новосибирск", state.coachData?.cities?.firstOrNull()?.name)
            
        } finally {
            java.net.ProxySelector.setDefault(originalProxySelector)
            server.stop(0)
            ru.oburec.coachpay.data.SyncManager.BASE_URL = originalBaseUrl
            ru.oburec.coachpay.data.SyncManager.IDENTITY_URL = originalIdentityUrl
        }
    }

    @Test
    fun testParentOnboardingFlow() {
        val originalProxySelector = java.net.ProxySelector.getDefault()
        java.net.ProxySelector.setDefault(object : java.net.ProxySelector() {
            override fun select(uri: java.net.URI?): MutableList<java.net.Proxy> {
                return mutableListOf(java.net.Proxy.NO_PROXY)
            }
            override fun connectFailed(uri: java.net.URI?, sa: java.net.SocketAddress?, ioe: java.io.IOException?) {}
        })

        val server = com.sun.net.httpserver.HttpServer.create(java.net.InetSocketAddress("127.0.0.1", 0), 0)
        val port = server.address.port

        val originalBaseUrl = ru.oburec.coachpay.data.SyncManager.BASE_URL
        val originalIdentityUrl = ru.oburec.coachpay.data.SyncManager.IDENTITY_URL

        ru.oburec.coachpay.data.SyncManager.BASE_URL = "http://127.0.0.1:$port"
        ru.oburec.coachpay.data.SyncManager.IDENTITY_URL = "http://127.0.0.1:$port/signIn"

        var getCoachDataCalled = false
        var putCoachDataCalled = false
        var pullPaymentsCalled = false
        var saveUserProfileCalled = false

        server.createContext("/") { exchange ->
            val path = exchange.requestURI.path
            val method = exchange.requestMethod

            if (path == "/coaches/test_coach_id/coachData.json" && method == "GET") {
                getCoachDataCalled = true
                val response = """
                    {
                        "coachId": "test_coach_id",
                        "cities": [
                            {
                                "id": "city_1",
                                "name": "Мытищи",
                                "groups": [
                                    {
                                        "id": "group_1",
                                        "name": "Основная группа",
                                        "defaultMonthlyFee": 3000.0,
                                        "students": []
                                    }
                                ]
                            }
                        ]
                    }
                """.trimIndent()
                exchange.sendResponseHeaders(200, response.toByteArray().size.toLong())
                val os = exchange.responseBody
                os.write(response.toByteArray())
                os.close()
            } else if (path == "/coaches/test_coach_id/coachData.json" && method == "PUT") {
                putCoachDataCalled = true
                val response = "{}"
                exchange.sendResponseHeaders(200, response.toByteArray().size.toLong())
                val os = exchange.responseBody
                os.write(response.toByteArray())
                os.close()
            } else if (path.startsWith("/coaches/test_coach_id/students/") && path.endsWith("/payments.json") && method == "GET") {
                pullPaymentsCalled = true
                val response = "[]"
                exchange.sendResponseHeaders(200, response.toByteArray().size.toLong())
                val os = exchange.responseBody
                os.write(response.toByteArray())
                os.close()
            } else if (path.startsWith("/coaches/test_coach_id/students/") && path.endsWith("/profile.json") && method == "GET") {
                val response = "null"
                exchange.sendResponseHeaders(200, response.toByteArray().size.toLong())
                val os = exchange.responseBody
                os.write(response.toByteArray())
                os.close()
            } else if (path.startsWith("/coaches/test_coach_id/schedules/") && method == "GET") {
                val response = "null"
                exchange.sendResponseHeaders(200, response.toByteArray().size.toLong())
                val os = exchange.responseBody
                os.write(response.toByteArray())
                os.close()
            } else if (path == "/users/parent_uid.json" && method == "PUT") {
                saveUserProfileCalled = true
                val response = "{}"
                exchange.sendResponseHeaders(200, response.toByteArray().size.toLong())
                val os = exchange.responseBody
                os.write(response.toByteArray())
                os.close()
            } else {
                exchange.sendResponseHeaders(404, 0)
                exchange.close()
            }
        }

        server.start()

        try {
            val testDir = tempFolder.newFolder()
            val storageManager = StorageManager(testDir)
            val viewModel = AppStateViewModel(
                storageManager = storageManager,
                ioDispatcher = kotlinx.coroutines.Dispatchers.Unconfined,
                mainDispatcher = kotlinx.coroutines.Dispatchers.Unconfined
            )

            // Устанавливаем пользователя с UID (для привязки UserProfile в Firebase)
            viewModel.saveState(viewModel.state.value.copy(
                firebaseUid = "parent_uid",
                googleEmail = "parent@gmail.com"
            ))

            // 1. Стягиваем список учеников
            val latch1 = java.util.concurrent.CountDownLatch(1)
            var fetchedStudents: List<ru.oburec.coachpay.model.Student>? = null
            viewModel.fetchGroupStudents("test_coach_id", "city_1", "group_1") { list ->
                fetchedStudents = list
                latch1.countDown()
            }
            assertTrue(latch1.await(5, java.util.concurrent.TimeUnit.SECONDS))
            assertTrue(getCoachDataCalled)
            assertNotNull(fetchedStudents)
            assertTrue(fetchedStudents!!.isEmpty())

            // 2. Добавляем ученика
            val latch2 = java.util.concurrent.CountDownLatch(1)
            var addedStudent: ru.oburec.coachpay.model.Student? = null
            var addSuccess = false
            viewModel.addNewStudentFromParent("test_coach_id", "city_1", "group_1", "Степан", "Иванов") { success, student ->
                addSuccess = success
                addedStudent = student
                latch2.countDown()
            }
            assertTrue(latch2.await(5, java.util.concurrent.TimeUnit.SECONDS))
            assertTrue(addSuccess)
            
            val currentStudent = addedStudent ?: throw AssertionError("addedStudent should not be null")
            assertEquals("Степан", currentStudent.firstName)
            assertEquals("Иванов", currentStudent.lastName)
            assertTrue(putCoachDataCalled)

            // 3. Связываем добавленного ученика
            val latch3 = java.util.concurrent.CountDownLatch(1)
            var linkSuccess = false
            viewModel.linkStudentToParent(
                coachId = "test_coach_id",
                cityId = "city_1",
                cityName = "Мытищи",
                groupId = "group_1",
                groupName = "Основная группа",
                studentId = currentStudent.id,
                studentName = "Иванов Степан",
                inviteCode = "123456"
            ) { success ->
                linkSuccess = success
                latch3.countDown()
            }
            assertTrue(latch3.await(5, java.util.concurrent.TimeUnit.SECONDS))
            assertTrue(linkSuccess)
            assertTrue(pullPaymentsCalled)
            assertTrue(saveUserProfileCalled)

            // Проверяем стейт
            val state = viewModel.state.value
            assertEquals(AppRole.STUDENT, state.role)
            assertEquals(currentStudent.id, state.studentConfig?.studentId)
            assertEquals("Иванов", state.studentConfig?.lastName)
            assertEquals("Степан", state.studentConfig?.firstName)

        } finally {
            java.net.ProxySelector.setDefault(originalProxySelector)
            server.stop(0)
            ru.oburec.coachpay.data.SyncManager.BASE_URL = originalBaseUrl
            ru.oburec.coachpay.data.SyncManager.IDENTITY_URL = originalIdentityUrl
        }
    }

    @Test
    fun testWeeklyScheduleNavigationAndStorage() {
        val tempFile = tempFolder.newFile("test_state_weekly.json")
        val storageManager = StorageManager(tempFile)
        val viewModel = AppStateViewModel(
            storageManager = storageManager,
            ioDispatcher = kotlinx.coroutines.Dispatchers.Unconfined,
            mainDispatcher = kotlinx.coroutines.Dispatchers.Unconfined
        )
        
        val coachData = ru.oburec.coachpay.model.CoachData(
            coachId = "test_coach_id",
            cities = listOf(
                ru.oburec.coachpay.model.City(
                    id = "city_1",
                    name = "Мытищи",
                    groups = listOf(
                        ru.oburec.coachpay.model.StudentGroup(
                            id = "group_1",
                            name = "Группа А"
                        )
                    )
                )
            )
        )
        viewModel.saveState(viewModel.state.value.copy(coachData = coachData, firebaseUid = "test_coach_id"))
        
        val testWeekly = listOf(
            ru.oburec.coachpay.model.WeeklyClass(
                id = "class_1",
                dayOfWeek = "Понедельник",
                time = "18:00",
                startTime = "18:00",
                endTime = "19:30",
                location = "Зал 1"
            )
        )
        val testEvents = listOf(
            ru.oburec.coachpay.model.GroupEvent(
                id = "event_1",
                title = "Мастер-класс",
                date = "22.06.26",
                time = "12:00"
            )
        )
        
        val targetWeekMonday = "2026-06-22"
        viewModel.updateGroupSchedule(
            cityId = "city_1",
            groupId = "group_1",
            weeklySchedule = testWeekly,
            oneOffEvents = testEvents,
            weekMonday = targetWeekMonday
        )
        
        val updatedGroup = viewModel.state.value.coachData?.cities
            ?.find { it.id == "city_1" }
            ?.groups?.find { it.id == "group_1" }
            
        assertNotNull(updatedGroup)
        val weekSchedule = updatedGroup?.schedulesByWeek?.get(targetWeekMonday)
        assertNotNull(weekSchedule)
        assertEquals(1, weekSchedule?.weeklySchedule?.size)
        assertEquals("class_1", weekSchedule?.weeklySchedule?.first()?.id)
        assertEquals(1, weekSchedule?.oneOffEvents?.size)
        assertEquals("event_1", weekSchedule?.oneOffEvents?.first()?.id)
    }

    @Test
    fun testBookingSystemAndTieredPricing() {
        val originalProxySelector = java.net.ProxySelector.getDefault()
        java.net.ProxySelector.setDefault(object : java.net.ProxySelector() {
            override fun select(uri: java.net.URI?): MutableList<java.net.Proxy> {
                return mutableListOf(java.net.Proxy.NO_PROXY)
            }
            override fun connectFailed(uri: java.net.URI?, sa: java.net.SocketAddress?, ioe: java.io.IOException?) {}
        })

        val server = com.sun.net.httpserver.HttpServer.create(java.net.InetSocketAddress("127.0.0.1", 0), 0)
        val port = server.address.port

        val originalBaseUrl = ru.oburec.coachpay.data.SyncManager.BASE_URL
        ru.oburec.coachpay.data.SyncManager.BASE_URL = "http://127.0.0.1:$port"

        var savedBookingsJson = "[]"

        server.createContext("/") { exchange ->
            val path = exchange.requestURI.path
            val method = exchange.requestMethod

            if (path == "/coaches/test_coach_id/groups/group_1/bookings.json") {
                if (method == "GET") {
                    val response = savedBookingsJson
                    exchange.sendResponseHeaders(200, response.toByteArray().size.toLong())
                    val os = exchange.responseBody
                    os.write(response.toByteArray())
                    os.close()
                } else if (method == "PUT") {
                    val body = exchange.requestBody.bufferedReader().readText()
                    savedBookingsJson = body
                    val response = "{}"
                    exchange.sendResponseHeaders(200, response.toByteArray().size.toLong())
                    val os = exchange.responseBody
                    os.write(response.toByteArray())
                    os.close()
                }
            } else {
                exchange.sendResponseHeaders(404, 0)
                exchange.close()
            }
        }
        server.start()

        try {
            val tempFile = tempFolder.newFile("test_state_bookings.json")
            val storageManager = StorageManager(tempFile)
            val viewModel = AppStateViewModel(
                storageManager = storageManager,
                ioDispatcher = kotlinx.coroutines.Dispatchers.Unconfined,
                mainDispatcher = kotlinx.coroutines.Dispatchers.Unconfined
            )

            val coachData = ru.oburec.coachpay.model.CoachData(
                coachId = "test_coach_id",
                cities = listOf(
                    ru.oburec.coachpay.model.City(
                        id = "city_1",
                        name = "Мытищи",
                        groups = listOf(
                            ru.oburec.coachpay.model.StudentGroup(
                                id = "group_1",
                                name = "Группа А",
                                students = listOf(
                                    ru.oburec.coachpay.model.Student(id = "stud_1", firstName = "Иван", lastName = "Иванов"),
                                    ru.oburec.coachpay.model.Student(id = "stud_2", firstName = "Петр", lastName = "Петров"),
                                    ru.oburec.coachpay.model.Student(id = "stud_3", firstName = "Сидор", lastName = "Сидоров")
                                )
                            )
                        )
                    )
                )
            )
            viewModel.saveState(viewModel.state.value.copy(coachData = coachData, role = ru.oburec.coachpay.model.AppRole.COACH))

            // 1. Создаем занятие с лимитом 2 человека и сеткой цен
            val booking = ru.oburec.coachpay.model.BookingClass(
                id = "booking_1",
                title = "Мини-группа",
                date = "2026-06-22",
                time = "10:00",
                maxCapacity = 2,
                priceRules = listOf(
                    ru.oburec.coachpay.model.BookingPriceRule(attendeesCount = 1, pricePerPerson = 2000.0),
                    ru.oburec.coachpay.model.BookingPriceRule(attendeesCount = 2, pricePerPerson = 1500.0)
                )
            )

            // 2. Добавляем занятие
            val latch1 = java.util.concurrent.CountDownLatch(1)
            var addSuccess = false
            viewModel.addOrUpdateBookingClass("city_1", "group_1", booking) { success ->
                addSuccess = success
                latch1.countDown()
            }
            assertTrue(latch1.await(5, java.util.concurrent.TimeUnit.SECONDS))
            assertTrue(addSuccess)

            val groupAfterAdd = viewModel.state.value.coachData?.cities
                ?.find { it.id == "city_1" }
                ?.groups?.find { it.id == "group_1" }
            assertNotNull(groupAfterAdd)
            assertEquals(1, groupAfterAdd?.bookings?.size)
            assertEquals("booking_1", groupAfterAdd?.bookings?.first()?.id)

            // 3. Записываем первого ученика
            val latch2 = java.util.concurrent.CountDownLatch(1)
            var toggle1Success = false
            viewModel.toggleStudentBooking("test_coach_id", "group_1", "booking_1", "stud_1", register = true) { success ->
                toggle1Success = success
                latch2.countDown()
            }
            assertTrue(latch2.await(5, java.util.concurrent.TimeUnit.SECONDS))
            assertTrue(toggle1Success)
            
            var updatedBooking = viewModel.state.value.coachData?.cities
                ?.find { it.id == "city_1" }
                ?.groups?.find { it.id == "group_1" }
                ?.bookings?.first()
            
            assertNotNull(updatedBooking)
            assertEquals(1, updatedBooking?.attendees?.size)
            assertTrue(updatedBooking?.attendees?.contains("stud_1") == true)

            // 4. Записываем второго ученика
            val latch3 = java.util.concurrent.CountDownLatch(1)
            var toggle2Success = false
            viewModel.toggleStudentBooking("test_coach_id", "group_1", "booking_1", "stud_2", register = true) { success ->
                toggle2Success = success
                latch3.countDown()
            }
            assertTrue(latch3.await(5, java.util.concurrent.TimeUnit.SECONDS))
            assertTrue(toggle2Success)

            updatedBooking = viewModel.state.value.coachData?.cities
                ?.find { it.id == "city_1" }
                ?.groups?.find { it.id == "group_1" }
                ?.bookings?.first()

            assertEquals(2, updatedBooking?.attendees?.size)
            assertTrue(updatedBooking?.attendees?.contains("stud_2") == true)

            // 5. Попытка записать третьего (превышение лимита maxCapacity = 2)
            val latch4 = java.util.concurrent.CountDownLatch(1)
            var toggle3Success = false
            viewModel.toggleStudentBooking("test_coach_id", "group_1", "booking_1", "stud_3", register = true) { success ->
                toggle3Success = success
                latch4.countDown()
            }
            assertTrue(latch4.await(5, java.util.concurrent.TimeUnit.SECONDS))
            assertTrue(toggle3Success)

            updatedBooking = viewModel.state.value.coachData?.cities
                ?.find { it.id == "city_1" }
                ?.groups?.find { it.id == "group_1" }
                ?.bookings?.first()

            // Число записавшихся должно остаться 2, так как лимит 2 человека
            assertEquals(2, updatedBooking?.attendees?.size)
            assertFalse(updatedBooking?.attendees?.contains("stud_3") == true)
        } finally {
            java.net.ProxySelector.setDefault(originalProxySelector)
            server.stop(0)
            ru.oburec.coachpay.data.SyncManager.BASE_URL = originalBaseUrl
        }
    }

    @Test
    fun testAddBookingClassesBatchCloning() {
        val originalProxySelector = java.net.ProxySelector.getDefault()
        java.net.ProxySelector.setDefault(null)
        val originalBaseUrl = ru.oburec.coachpay.data.SyncManager.BASE_URL

        val server = com.sun.net.httpserver.HttpServer.create(java.net.InetSocketAddress(0), 0)
        val port = server.address.port
        ru.oburec.coachpay.data.SyncManager.BASE_URL = "http://localhost:$port"

        server.createContext("/") { exchange ->
            val path = exchange.requestURI.path
            if (path == "/coaches/test_coach_id/groups/group_1/bookings.json") {
                val response = "{}"
                exchange.sendResponseHeaders(200, response.toByteArray().size.toLong())
                val os = exchange.responseBody
                os.write(response.toByteArray())
                os.close()
            } else {
                exchange.sendResponseHeaders(404, 0)
                exchange.close()
            }
        }
        server.start()

        try {
            val tempFile = tempFolder.newFile("test_state_bookings_cloning.json")
            val storageManager = StorageManager(tempFile)
            val viewModel = AppStateViewModel(
                storageManager = storageManager,
                ioDispatcher = kotlinx.coroutines.Dispatchers.Unconfined,
                mainDispatcher = kotlinx.coroutines.Dispatchers.Unconfined
            )

            val coachData = ru.oburec.coachpay.model.CoachData(
                coachId = "test_coach_id",
                cities = listOf(
                    ru.oburec.coachpay.model.City(
                        id = "city_1",
                        name = "Мытищи",
                        groups = listOf(
                            ru.oburec.coachpay.model.StudentGroup(
                                id = "group_1",
                                name = "Группа А",
                                bookings = listOf(
                                    ru.oburec.coachpay.model.BookingClass(
                                        id = "booking_existing",
                                        title = "Existing Booking",
                                        date = "2026-06-22",
                                        time = "18:00",
                                        maxCapacity = 5
                                    )
                                )
                            )
                        )
                    )
                )
            )
            viewModel.saveState(viewModel.state.value.copy(coachData = coachData, role = ru.oburec.coachpay.model.AppRole.COACH))

            val batch = listOf(
                ru.oburec.coachpay.model.BookingClass(
                    id = "cloned_1",
                    title = "Cloned Day 1",
                    date = "2026-06-29",
                    time = "12:00",
                    maxCapacity = 5
                ),
                ru.oburec.coachpay.model.BookingClass(
                    id = "cloned_2",
                    title = "Cloned Day 2",
                    date = "2026-06-30",
                    time = "10:00",
                    maxCapacity = 5
                )
            )

            val latch = java.util.concurrent.CountDownLatch(1)
            var addSuccess = false
            viewModel.addBookingClasses("city_1", "group_1", batch) { success ->
                addSuccess = success
                latch.countDown()
            }
            assertTrue(latch.await(5, java.util.concurrent.TimeUnit.SECONDS))
            assertTrue(addSuccess)

            val groupAfterAdd = viewModel.state.value.coachData?.cities
                ?.find { it.id == "city_1" }
                ?.groups?.find { it.id == "group_1" }
            assertNotNull(groupAfterAdd)
            assertEquals(3, groupAfterAdd?.bookings?.size)

            val sortedList = groupAfterAdd?.bookings ?: emptyList()
            assertEquals("booking_existing", sortedList[0].id)
            assertEquals("cloned_1", sortedList[1].id)
            assertEquals("cloned_2", sortedList[2].id)
        } finally {
            java.net.ProxySelector.setDefault(originalProxySelector)
            server.stop(0)
            ru.oburec.coachpay.data.SyncManager.BASE_URL = originalBaseUrl
        }
    }

    @Test
    fun testMonthUtilsGetMondayOfWeek() {
        val monday = ru.oburec.coachpay.ui.utils.MonthUtils.getMondayOfWeek(0)
        println("DEBUG: monday is $monday")
        assertNotNull(monday)
        
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        val date = sdf.parse(monday)
        assertNotNull(date)
        
        val cal = java.util.Calendar.getInstance()
        cal.time = date!!
        assertEquals(java.util.Calendar.MONDAY, cal.get(java.util.Calendar.DAY_OF_WEEK))
        
        val nextMonday = ru.oburec.coachpay.ui.utils.MonthUtils.getMondayOfWeek(1)
        val prevMonday = ru.oburec.coachpay.ui.utils.MonthUtils.getMondayOfWeek(-1)
        
        val calNext = java.util.Calendar.getInstance()
        calNext.time = sdf.parse(nextMonday)!!
        assertEquals(java.util.Calendar.MONDAY, calNext.get(java.util.Calendar.DAY_OF_WEEK))
        
        val calPrev = java.util.Calendar.getInstance()
        calPrev.time = sdf.parse(prevMonday)!!
        assertEquals(java.util.Calendar.MONDAY, calPrev.get(java.util.Calendar.DAY_OF_WEEK))
        
        val diffMs = calNext.timeInMillis - cal.timeInMillis
        assertEquals(7 * 24 * 60 * 60 * 1000L, diffMs)
    }
}
